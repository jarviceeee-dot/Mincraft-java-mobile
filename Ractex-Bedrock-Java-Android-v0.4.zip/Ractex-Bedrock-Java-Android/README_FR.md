# Ractex Bedrock Java — Prototype 0.4

Moteur voxel Android indépendant expérimental, en Java 17 et OpenGL ES 2.0.

## Nouveautés 0.4
- Gravité verticale et chute.
- Bouton SAUT avec saut lorsque le joueur touche le sol.
- Collisions simples avec les blocs : le joueur ne traverse plus les murs et le sol.
- Déplacement horizontal avec test de collision par axe.
- Caméra en hauteur par rapport aux pieds du joueur.
- Les fonctions 3D, hotbar, inventaire simplifié et sauvegarde de la 0.3 sont conservées.

## Compiler
Ouvrir le dossier dans Android Studio avec JDK 17 et Android SDK 35, synchroniser Gradle puis lancer sur un appareil Android. Ce ZIP contient le code source et non un APK compilé.

## Limites
Physique prototype : pas encore de sprint, nage, échelles, escaliers optimisés, synchronisation multijoueur ou compatibilité avec les mods Fabric/Forge. La physique est encore mise à jour par image et pourra être améliorée avec un pas de temps fixe.
