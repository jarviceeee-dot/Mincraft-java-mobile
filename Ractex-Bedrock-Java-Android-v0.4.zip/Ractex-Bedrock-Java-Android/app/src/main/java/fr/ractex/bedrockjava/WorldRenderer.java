package fr.ractex.bedrockjava;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import java.io.File;
import java.nio.*;
import java.util.ArrayList;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** OpenGL ES renderer: independent 3D cubes, first-person camera and simple block editing. */
public final class WorldRenderer implements GLSurfaceView.Renderer {
    private final World world = new World();
    private int program,aPosition,aColor,uMvp,vertexCount;
    private FloatBuffer vertices;
    private final float[] projection=new float[16],view=new float[16],vp=new float[16];
    private volatile float yaw=0f,pitch=.25f,forwardInput,strafeInput;
    private float playerX=16.5f,playerZ=16.5f,playerY=6f,verticalVelocity=0f;\n    private boolean grounded=false;
    private volatile boolean meshDirty=true;
    private int selectedBlock=World.GRASS;
    private File saveFile;

    private static final String VS="uniform mat4 uMvp; attribute vec3 aPosition; attribute vec4 aColor; varying vec4 vColor; void main(){gl_Position=uMvp*vec4(aPosition,1.0);vColor=aColor;}";
    private static final String FS="precision mediump float; varying vec4 vColor; void main(){gl_FragColor=vColor;}";
    public void setSaveFile(File f){saveFile=f;if(f!=null&&world.load(f))meshDirty=true;playerY=world.surfaceAt((int)playerX,(int)playerZ)+1;}
    public boolean saveWorld(){try{if(saveFile==null)return false;world.save(saveFile);return true;}catch(Exception e){return false;}}
    public void selectBlock(int id){selectedBlock=id;}
    public int getSelectedBlock(){return selectedBlock;}
    public void rotate(float dx,float dy){yaw+=dx;pitch=Math.max(-.8f,Math.min(1f,pitch+dy));}
    public void setMovement(float f,float s){forwardInput=f;strafeInput=s;}\n    public void jump(){if(grounded){verticalVelocity=.235f;grounded=false;}}
    public void breakBlock(){editTarget(-1);}
    public void placeBlock(){editTarget(1);}
    private void editTarget(int delta){
        float dx=(float)Math.sin(yaw),dz=(float)Math.cos(yaw);
        float eyeY=playerY+1.55f;
        float dy=-(float)Math.sin(pitch);
        for(float d=1.3f;d<5.5f;d+=.2f){
            int x=(int)Math.floor(playerX+dx*d),z=(int)Math.floor(playerZ+dz*d);
            int y=(int)Math.floor(eyeY+dy*d);
            if(world.get(x,y,z)!=World.AIR){
                if(delta<0)world.set(x,y,z,World.AIR);
                else {int px=(int)Math.floor(playerX+dx*(d-.25f));int pz=(int)Math.floor(playerZ+dz*(d-.25f));int py=(int)Math.floor(eyeY+dy*(d-.25f));if(world.get(px,py,pz)==World.AIR)world.set(px,py,pz,(byte)selectedBlock);}
                meshDirty=true;return;
            }
        }
    }
    @Override public void onSurfaceCreated(GL10 gl,EGLConfig c){
        GLES20.glClearColor(.48f,.72f,.92f,1);GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        program=createProgram(VS,FS);aPosition=GLES20.glGetAttribLocation(program,"aPosition");
        aColor=GLES20.glGetAttribLocation(program,"aColor");uMvp=GLES20.glGetUniformLocation(program,"uMvp");buildMesh();
    }
    @Override public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,68f,(float)w/Math.max(1,h),.1f,100f);}
    @Override public void onDrawFrame(GL10 gl){
        updatePlayer();if(meshDirty)buildMesh();GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        float ex=playerX,ey=playerY+1.62f,ez=playerZ;
        float dx=(float)(Math.sin(yaw)*Math.cos(pitch)),dy=-(float)Math.sin(pitch),dz=(float)(Math.cos(yaw)*Math.cos(pitch));
        Matrix.setLookAtM(view,0,ex,ey,ez,ex+dx,ey+dy,ez+dz,0,1,0);Matrix.multiplyMM(vp,0,projection,0,view,0);
        GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(uMvp,1,false,vp,0);
        vertices.position(0);GLES20.glEnableVertexAttribArray(aPosition);GLES20.glEnableVertexAttribArray(aColor);
        GLES20.glVertexAttribPointer(aPosition,3,GLES20.GL_FLOAT,false,7*4,vertices);vertices.position(3);
        GLES20.glVertexAttribPointer(aColor,4,GLES20.GL_FLOAT,false,7*4,vertices);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertexCount);GLES20.glDisableVertexAttribArray(aPosition);GLES20.glDisableVertexAttribArray(aColor);
    }
    private void updatePlayer(){
        // Horizontal movement with a small player hitbox; each axis is tested separately.
        float f=forwardInput*.105f,s=strafeInput*.105f;
        float mx=(float)Math.sin(yaw)*f+(float)Math.cos(yaw)*s;
        float mz=(float)Math.cos(yaw)*f-(float)Math.sin(yaw)*s;
        if(!collides(playerX+mx,playerY,playerZ))playerX+=mx;
        if(!collides(playerX,playerY,playerZ+mz))playerZ+=mz;

        // Gravity and vertical collision. The player is 1.8 blocks tall.
        verticalVelocity=Math.max(-.32f,verticalVelocity-.012f);
        float nextY=playerY+verticalVelocity;
        if(verticalVelocity<=0 && collides(playerX,nextY,playerZ)){
            int floor=(int)Math.floor(playerY);
            playerY=floor; verticalVelocity=0; grounded=true;
        }else if(verticalVelocity>0 && collides(playerX,nextY,playerZ)){
            verticalVelocity=0; grounded=false;
        }else{
            playerY=nextY;
            grounded=false;
        }
        // Keep the player inside the generated world and prevent falling forever.
        playerX=Math.max(.35f,Math.min(World.WIDTH-.35f,playerX));
        playerZ=Math.max(.35f,Math.min(World.DEPTH-.35f,playerZ));
        if(playerY < -8){playerY=world.surfaceAt((int)playerX,(int)playerZ)+1;verticalVelocity=0;}
    }
    private boolean collides(float x,float feetY,float z){
        float radius=.27f, height=1.8f;
        int minX=(int)Math.floor(x-radius),maxX=(int)Math.floor(x+radius);
        int minZ=(int)Math.floor(z-radius),maxZ=(int)Math.floor(z+radius);
        int minY=(int)Math.floor(feetY+.03f),maxY=(int)Math.floor(feetY+height-.03f);
        for(int bx=minX;bx<=maxX;bx++)for(int bz=minZ;bz<=maxZ;bz++)for(int by=minY;by<=maxY;by++){
            if(bx<0||bx>=World.WIDTH||bz<0||bz>=World.DEPTH||by<0)return true;
            if(by<World.HEIGHT && world.get(bx,by,bz)!=World.AIR)return true;
        }
        return false;
    }
    private void buildMesh(){
        ArrayList<Float> out=new ArrayList<>();
        for(int x=0;x<World.WIDTH;x++)for(int y=0;y<World.HEIGHT;y++)for(int z=0;z<World.DEPTH;z++){
            byte id=world.get(x,y,z);if(id==World.AIR)continue;
            float[] c=color(id);
            if(world.get(x,y+1,z)==World.AIR)face(out,x,y+1,z,x+1,y+1,z,x+1,y+1,z+1,x,y+1,z+1,c);
            if(world.get(x,y-1,z)==World.AIR)face(out,x,y,z+1,x+1,y,z+1,x+1,y,z,x,y,z,c);
            if(world.get(x-1,y,z)==World.AIR)face(out,x,y,z,x,y,z+1,x,y+1,z+1,x,y+1,z,c);
            if(world.get(x+1,y,z)==World.AIR)face(out,x+1,y,z+1,x+1,y,z,x+1,y+1,z,x+1,y+1,z+1,c);
            if(world.get(x,y,z-1)==World.AIR)face(out,x+1,y,z,x,y,z,x,y+1,z,x+1,y+1,z,c);
            if(world.get(x,y,z+1)==World.AIR)face(out,x,y,z+1,x+1,y,z+1,x+1,y+1,z+1,x,y+1,z+1,c);
        }
        float[] raw=new float[out.size()];for(int i=0;i<raw.length;i++)raw[i]=out.get(i);
        ByteBuffer bb=ByteBuffer.allocateDirect(raw.length*4).order(ByteOrder.nativeOrder());vertices=bb.asFloatBuffer();vertices.put(raw).position(0);
        vertexCount=raw.length/7;meshDirty=false;
    }
    private static float[] color(byte id){if(id==World.DIRT)return new float[]{.48f,.29f,.14f,1};if(id==World.STONE)return new float[]{.48f,.49f,.51f,1};if(id==World.WOOD)return new float[]{.48f,.28f,.10f,1};return new float[]{.25f,.62f,.20f,1};}
    private static void face(ArrayList<Float> o,float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float dx,float dy,float dz,float[] c){
        vertex(o,ax,ay,az,c);vertex(o,bx,by,bz,c);vertex(o,cx,cy,cz,c);vertex(o,ax,ay,az,c);vertex(o,cx,cy,cz,c);vertex(o,dx,dy,dz,c);
    }
    private static void vertex(ArrayList<Float> o,float x,float y,float z,float[] c){o.add(x);o.add(y);o.add(z);o.add(c[0]);o.add(c[1]);o.add(c[2]);o.add(c[3]);}
    private static int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);int[] ok={0};GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new RuntimeException(GLES20.glGetShaderInfoLog(s));return s;}
    private static int createProgram(String vs,String fs){int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,vs));GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,fs));GLES20.glLinkProgram(p);int[] ok={0};GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw new RuntimeException(GLES20.glGetProgramInfoLog(p));return p;}
}
