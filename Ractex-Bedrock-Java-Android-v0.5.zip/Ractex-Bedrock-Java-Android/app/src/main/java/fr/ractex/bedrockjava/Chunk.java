package fr.ractex.bedrockjava;

/** 16x16x world column used by the prototype. */
public final class Chunk {
    public static final int SIZE = 16;
    private final int chunkX, chunkZ;
    private final byte[][] heights = new byte[SIZE][SIZE];

    public Chunk(int chunkX, int chunkZ) { this.chunkX = chunkX; this.chunkZ = chunkZ; }
    public int getChunkX() { return chunkX; }
    public int getChunkZ() { return chunkZ; }
    public void setHeight(int x, int z, int h) { heights[x][z] = (byte) Math.max(1, Math.min(32, h)); }
    public int getHeight(int x, int z) { return heights[x][z] & 0xff; }
}
