package fr.ractex.bedrockjava;

import java.io.*;

/** Small true 3D block world. Coordinates are [x][y][z]. */
public final class World {
    public static final int WIDTH = 32, HEIGHT = 16, DEPTH = 32;
    public static final byte AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, WOOD = 4, LEAVES = 5;
    private final byte[][][] blocks = new byte[WIDTH][HEIGHT][DEPTH];

    public World() { generate(); }

    private void generate() {
        for (int x=0;x<WIDTH;x++) for (int z=0;z<DEPTH;z++) {
            double n = Math.sin(x*.24)*1.4 + Math.cos(z*.19)*1.2 + Math.sin((x+z)*.11)*.8;
            int top = Math.max(3, Math.min(8, 5+(int)Math.round(n)));
            for (int y=0;y<=top;y++) blocks[x][y][z] = (byte)(y==top?GRASS:(y>=top-2?DIRT:STONE));
        }
        // A small tree landmark.
        int tx=21,tz=17, ground=topAt(tx,tz);
        for(int y=ground+1;y<=ground+4 && y<HEIGHT;y++) blocks[tx][y][tz]=WOOD;
        for(int x=tx-2;x<=tx+2;x++) for(int z=tz-2;z<=tz+2;z++)
            for(int y=ground+3;y<=ground+5 && y<HEIGHT;y++)
                if(inside(x,y,z) && Math.abs(x-tx)+Math.abs(z-tz)+(y==ground+5?1:0)<=4 && blocks[x][y][z]==AIR)
                    blocks[x][y][z]=LEAVES;
    }
    private int topAt(int x,int z){ for(int y=HEIGHT-1;y>=0;y--)if(blocks[x][y][z]!=AIR)return y;return 0; }
    private boolean inside(int x,int y,int z){return x>=0&&x<WIDTH&&y>=0&&y<HEIGHT&&z>=0&&z<DEPTH;}
    public synchronized byte get(int x,int y,int z){return inside(x,y,z)?blocks[x][y][z]:AIR;}
    public synchronized boolean set(int x,int y,int z,byte id){if(!inside(x,y,z))return false;blocks[x][y][z]=id;return true;}
    public synchronized int surfaceAt(int x,int z){return inside(x,0,z)?topAt(x,z):0;}
    public synchronized boolean editSurface(int x,int z,int delta){
        int y=topAt(x,z); if(!inside(x,y,z))return false;
        if(delta<0){blocks[x][y][z]=AIR;return true;}
        if(y+1>=HEIGHT)return false;
        blocks[x][y+1][z]=GRASS;return true;
    }
    public synchronized void save(File file) throws IOException {
        try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))){
            out.writeInt(0x52425833); out.writeInt(WIDTH);out.writeInt(HEIGHT);out.writeInt(DEPTH);
            for(int x=0;x<WIDTH;x++)for(int y=0;y<HEIGHT;y++)out.write(blocks[x][y]);
        }
    }
    public synchronized boolean load(File file) {
        if(!file.exists())return false;
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(new FileInputStream(file)))){
            if(in.readInt()!=0x52425833||in.readInt()!=WIDTH||in.readInt()!=HEIGHT||in.readInt()!=DEPTH)return false;
            for(int x=0;x<WIDTH;x++)for(int y=0;y<HEIGHT;y++)in.readFully(blocks[x][y]);
            return true;
        }catch(IOException e){return false;}
    }
}
