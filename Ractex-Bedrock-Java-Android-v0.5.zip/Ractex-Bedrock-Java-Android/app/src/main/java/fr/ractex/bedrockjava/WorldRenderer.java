package fr.ractex.bedrockjava;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import java.io.File;
import java.io.InputStream;
import java.nio.*;
import java.util.ArrayList;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** OpenGL ES renderer: independent 3D cubes, first-person camera and simple block editing. */
public final class WorldRenderer implements GLSurfaceView.Renderer {
    private final World world = new World();
    private final Context context;
    private int program,aPosition,aUv,aShade,uMvp,uTex,texture,vertexCount;
    private FloatBuffer vertices;
    private final float[] projection=new float[16],view=new float[16],vp=new float[16];
    private volatile float yaw=0f,pitch=.25f,forwardInput,strafeInput;
    private float playerX=16.5f,playerZ=16.5f,playerY=6f,verticalVelocity=0f;
    private boolean grounded=false;
    private volatile boolean meshDirty=true;
    private int selectedBlock=World.GRASS;
    private File saveFile;

    // Atlas assets/atlas.png : 4x4 tuiles de 16x16 px (64x64).
    private static final int ATLAS_TILES=4;
    private static final int T_GRASS_TOP=0,T_GRASS_SIDE=1,T_DIRT=2,T_STONE=3,T_LOG_SIDE=4,T_LOG_TOP=5,T_LEAVES=6,T_PLANKS=7;
    private static final int STRIDE=6; // x,y,z,u,v,shade

    public WorldRenderer(Context context){this.context=context.getApplicationContext();}

    private static final String VS="uniform mat4 uMvp; attribute vec3 aPosition; attribute vec2 aUv; attribute float aShade; varying vec2 vUv; varying float vShade; void main(){gl_Position=uMvp*vec4(aPosition,1.0);vUv=aUv;vShade=aShade;}";
    private static final String FS="precision mediump float; uniform sampler2D uTex; varying vec2 vUv; varying float vShade; void main(){vec4 t=texture2D(uTex,vUv); if(t.a<0.5) discard; gl_FragColor=vec4(t.rgb*vShade,1.0);}";
    public void setSaveFile(File f){saveFile=f;if(f!=null&&world.load(f))meshDirty=true;playerY=world.surfaceAt((int)playerX,(int)playerZ)+1;}
    public boolean saveWorld(){try{if(saveFile==null)return false;world.save(saveFile);return true;}catch(Exception e){return false;}}
    public void selectBlock(int id){selectedBlock=id;}
    public int getSelectedBlock(){return selectedBlock;}
    public void rotate(float dx,float dy){yaw+=dx;pitch=Math.max(-.8f,Math.min(1f,pitch+dy));}
    public void setMovement(float f,float s){forwardInput=f;strafeInput=s;}
    public void jump(){if(grounded){verticalVelocity=.235f;grounded=false;}}
    public void breakBlock(){editTarget(-1);}
    public void placeBlock(){editTarget(1);}
    private void editTarget(int delta){
        float dx=(float)Math.sin(yaw),dz=(float)Math.cos(yaw);
        float eyeY=playerY+1.55f;
        float dy=-(float)Math.sin(pitch);
        for(float d=1.3f;d<5.5f;d+=.2f){
            int x=(int)Math.floor(playerX+dx*d),z=(int)Math.floor(playerZ+dz*d);
            int y=(int)Math.floor(eyeY+dy*d);
            if(world.get(x,y,z)!=World.AIR){
                if(delta<0)world.set(x,y,z,World.AIR);
                else {int px=(int)Math.floor(playerX+dx*(d-.25f));int pz=(int)Math.floor(playerZ+dz*(d-.25f));int py=(int)Math.floor(eyeY+dy*(d-.25f));if(world.get(px,py,pz)==World.AIR)world.set(px,py,pz,(byte)selectedBlock);}
                meshDirty=true;return;
            }
        }
    }
    @Override public void onSurfaceCreated(GL10 gl,EGLConfig c){
        GLES20.glClearColor(.48f,.72f,.92f,1);GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        program=createProgram(VS,FS);aPosition=GLES20.glGetAttribLocation(program,"aPosition");
        aUv=GLES20.glGetAttribLocation(program,"aUv");aShade=GLES20.glGetAttribLocation(program,"aShade");
        uMvp=GLES20.glGetUniformLocation(program,"uMvp");uTex=GLES20.glGetUniformLocation(program,"uTex");
        texture=loadAtlas();buildMesh();
    }
    @Override public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,68f,(float)w/Math.max(1,h),.1f,100f);}
    @Override public void onDrawFrame(GL10 gl){
        updatePlayer();if(meshDirty)buildMesh();GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);
        float ex=playerX,ey=playerY+1.62f,ez=playerZ;
        float dx=(float)(Math.sin(yaw)*Math.cos(pitch)),dy=-(float)Math.sin(pitch),dz=(float)(Math.cos(yaw)*Math.cos(pitch));
        Matrix.setLookAtM(view,0,ex,ey,ez,ex+dx,ey+dy,ez+dz,0,1,0);Matrix.multiplyMM(vp,0,projection,0,view,0);
        GLES20.glUseProgram(program);GLES20.glUniformMatrix4fv(uMvp,1,false,vp,0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,texture);GLES20.glUniform1i(uTex,0);
        GLES20.glEnableVertexAttribArray(aPosition);GLES20.glEnableVertexAttribArray(aUv);GLES20.glEnableVertexAttribArray(aShade);
        vertices.position(0);GLES20.glVertexAttribPointer(aPosition,3,GLES20.GL_FLOAT,false,STRIDE*4,vertices);
        vertices.position(3);GLES20.glVertexAttribPointer(aUv,2,GLES20.GL_FLOAT,false,STRIDE*4,vertices);
        vertices.position(5);GLES20.glVertexAttribPointer(aShade,1,GLES20.GL_FLOAT,false,STRIDE*4,vertices);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertexCount);
        GLES20.glDisableVertexAttribArray(aPosition);GLES20.glDisableVertexAttribArray(aUv);GLES20.glDisableVertexAttribArray(aShade);
    }
    private void updatePlayer(){
        // Horizontal movement with a small player hitbox; each axis is tested separately.
        float f=forwardInput*.105f,s=strafeInput*.105f;
        float mx=(float)Math.sin(yaw)*f+(float)Math.cos(yaw)*s;
        float mz=(float)Math.cos(yaw)*f-(float)Math.sin(yaw)*s;
        if(!collides(playerX+mx,playerY,playerZ))playerX+=mx;
        if(!collides(playerX,playerY,playerZ+mz))playerZ+=mz;

        // Gravity and vertical collision. The player is 1.8 blocks tall.
        verticalVelocity=Math.max(-.32f,verticalVelocity-.012f);
        float nextY=playerY+verticalVelocity;
        if(verticalVelocity<=0 && collides(playerX,nextY,playerZ)){
            int floor=(int)Math.floor(playerY);
            playerY=floor; verticalVelocity=0; grounded=true;
        }else if(verticalVelocity>0 && collides(playerX,nextY,playerZ)){
            verticalVelocity=0; grounded=false;
        }else{
            playerY=nextY;
            grounded=false;
        }
        // Keep the player inside the generated world and prevent falling forever.
        playerX=Math.max(.35f,Math.min(World.WIDTH-.35f,playerX));
        playerZ=Math.max(.35f,Math.min(World.DEPTH-.35f,playerZ));
        if(playerY < -8){playerY=world.surfaceAt((int)playerX,(int)playerZ)+1;verticalVelocity=0;}
    }
    private boolean collides(float x,float feetY,float z){
        float radius=.27f, height=1.8f;
        int minX=(int)Math.floor(x-radius),maxX=(int)Math.floor(x+radius);
        int minZ=(int)Math.floor(z-radius),maxZ=(int)Math.floor(z+radius);
        int minY=(int)Math.floor(feetY+.03f),maxY=(int)Math.floor(feetY+height-.03f);
        for(int bx=minX;bx<=maxX;bx++)for(int bz=minZ;bz<=maxZ;bz++)for(int by=minY;by<=maxY;by++){
            if(bx<0||bx>=World.WIDTH||bz<0||bz>=World.DEPTH||by<0)return true;
            if(by<World.HEIGHT && world.get(bx,by,bz)!=World.AIR)return true;
        }
        return false;
    }
    /** Charge assets/atlas.png en texture GL, filtrage NEAREST pour des pixels nets. */
    private int loadAtlas(){
        int[] id=new int[1];GLES20.glGenTextures(1,id,0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D,id[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE);
        try(InputStream in=context.getAssets().open("atlas.png")){
            BitmapFactory.Options o=new BitmapFactory.Options();o.inScaled=false;o.inPremultiplied=false;
            Bitmap bmp=BitmapFactory.decodeStream(in,null,o);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D,0,bmp,0);bmp.recycle();
        }catch(Exception e){throw new RuntimeException("atlas.png introuvable dans assets",e);}
        return id[0];
    }
    /** Tuile de la face : face 0=haut, 1=bas, 2..5=côtés. */
    private static int tile(byte id,int face){
        if(id==World.GRASS)return face==0?T_GRASS_TOP:face==1?T_DIRT:T_GRASS_SIDE;
        if(id==World.DIRT)return T_DIRT;
        if(id==World.STONE)return T_STONE;
        if(id==World.WOOD)return face<2?T_LOG_TOP:T_LOG_SIDE;
        if(id==World.LEAVES)return T_LEAVES;
        return T_PLANKS;
    }
    private void buildMesh(){
        ArrayList<Float> out=new ArrayList<>();
        for(int x=0;x<World.WIDTH;x++)for(int y=0;y<World.HEIGHT;y++)for(int z=0;z<World.DEPTH;z++){
            byte id=world.get(x,y,z);if(id==World.AIR)continue;
            if(world.get(x,y+1,z)==World.AIR)face(out,tile(id,0),1.00f,x,y+1,z,x+1,y+1,z,x+1,y+1,z+1,x,y+1,z+1);
            if(world.get(x,y-1,z)==World.AIR)face(out,tile(id,1),.50f,x,y,z+1,x+1,y,z+1,x+1,y,z,x,y,z);
            if(world.get(x-1,y,z)==World.AIR)face(out,tile(id,2),.65f,x,y,z,x,y,z+1,x,y+1,z+1,x,y+1,z);
            if(world.get(x+1,y,z)==World.AIR)face(out,tile(id,3),.65f,x+1,y,z+1,x+1,y,z,x+1,y+1,z,x+1,y+1,z+1);
            if(world.get(x,y,z-1)==World.AIR)face(out,tile(id,4),.80f,x+1,y,z,x,y,z,x,y+1,z,x+1,y+1,z);
            if(world.get(x,y,z+1)==World.AIR)face(out,tile(id,5),.80f,x,y,z+1,x+1,y,z+1,x+1,y+1,z+1,x,y+1,z+1);
        }
        float[] raw=new float[out.size()];for(int i=0;i<raw.length;i++)raw[i]=out.get(i);
        ByteBuffer bb=ByteBuffer.allocateDirect(raw.length*4).order(ByteOrder.nativeOrder());vertices=bb.asFloatBuffer();vertices.put(raw).position(0);
        vertexCount=raw.length/STRIDE;meshDirty=false;
    }
    /** Quad a,b (bas) puis c,d (haut) ; UV dans l'atlas, légèrement rentrés pour éviter tout débordement de tuile. */
    private static void face(ArrayList<Float> o,int tile,float shade,float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz,float dx,float dy,float dz){
        float e=.02f/(ATLAS_TILES*16);
        float u0=(tile%ATLAS_TILES)/(float)ATLAS_TILES+e,u1=(tile%ATLAS_TILES+1)/(float)ATLAS_TILES-e;
        float v0=(tile/ATLAS_TILES)/(float)ATLAS_TILES+e,v1=(tile/ATLAS_TILES+1)/(float)ATLAS_TILES-e;
        vertex(o,ax,ay,az,u0,v1,shade);vertex(o,bx,by,bz,u1,v1,shade);vertex(o,cx,cy,cz,u1,v0,shade);
        vertex(o,ax,ay,az,u0,v1,shade);vertex(o,cx,cy,cz,u1,v0,shade);vertex(o,dx,dy,dz,u0,v0,shade);
    }
    private static void vertex(ArrayList<Float> o,float x,float y,float z,float u,float v,float s){o.add(x);o.add(y);o.add(z);o.add(u);o.add(v);o.add(s);}
    private static int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);int[] ok={0};GLES20.glGetShaderiv(s,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)throw new RuntimeException(GLES20.glGetShaderInfoLog(s));return s;}
    private static int createProgram(String vs,String fs){int p=GLES20.glCreateProgram();GLES20.glAttachShader(p,shader(GLES20.GL_VERTEX_SHADER,vs));GLES20.glAttachShader(p,shader(GLES20.GL_FRAGMENT_SHADER,fs));GLES20.glLinkProgram(p);int[] ok={0};GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw new RuntimeException(GLES20.glGetProgramInfoLog(p));return p;}
}
