package fr.ractex.bedrockjava;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.opengl.GLSurfaceView;
import android.widget.Toast;
import android.graphics.Color;
import java.io.File;

public class MainActivity extends Activity {
    private GameSurface game;
    private float lastX,lastY;
    private boolean rotating;
    private TextView[] slots=new TextView[9];
    private int selected=0;
    private final int[] blockIds={World.GRASS,World.DIRT,World.STONE,World.WOOD,World.LEAVES,World.DIRT,World.STONE,World.WOOD,World.GRASS};
    private final String[] blockNames={"Herbe","Terre","Pierre","Bois","Feuilles","Terre","Pierre","Bois","Herbe"};

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        FrameLayout root=new FrameLayout(this);game=new GameSurface(this);root.addView(game,new FrameLayout.LayoutParams(-1,-1));
        game.renderer.setSaveFile(new File(getFilesDir(),"ractex_world.dat"));
        TextView hud=label("RACTEX BEDROCK JAVA 0.5\nGlisse à droite pour regarder",13);hud.setPadding(16,12,16,12);hud.setBackgroundColor(0x990b1720);
        root.addView(hud,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT));
        addHold(root,"▲",Gravity.BOTTOM|Gravity.LEFT,112,126,()->game.renderer.setMovement(1,0),()->game.renderer.setMovement(0,0));
        addHold(root,"▼",Gravity.BOTTOM|Gravity.LEFT,112,24,()->game.renderer.setMovement(-1,0),()->game.renderer.setMovement(0,0));
        addHold(root,"◀",Gravity.BOTTOM|Gravity.LEFT,164,75,()->game.renderer.setMovement(0,-1),()->game.renderer.setMovement(0,0));
        addHold(root,"▶",Gravity.BOTTOM|Gravity.LEFT,60,75,()->game.renderer.setMovement(0,1),()->game.renderer.setMovement(0,0));
        addTap(root,"CASSER",Gravity.BOTTOM|Gravity.RIGHT,28,34,()->game.renderer.breakBlock());
        addTap(root,"POSER",Gravity.BOTTOM|Gravity.RIGHT,142,34,()->game.renderer.placeBlock());
        addTap(root,"SAUT",Gravity.BOTTOM|Gravity.RIGHT,85,112,()->game.renderer.jump());
        addTap(root,"SAC",Gravity.TOP|Gravity.RIGHT,16,16,()->showInventory());
        addTap(root,"SAUVER",Gravity.TOP|Gravity.RIGHT,104,16,()->Toast.makeText(this,game.renderer.saveWorld()?"Monde sauvegardé":"Erreur de sauvegarde",Toast.LENGTH_SHORT).show());
        LinearLayout hotbar=new LinearLayout(this);hotbar.setOrientation(LinearLayout.HORIZONTAL);hotbar.setGravity(Gravity.CENTER);
        for(int i=0;i<9;i++){final int index=i;TextView slot=label((i+1)+"\n"+blockNames[i],11);slot.setGravity(Gravity.CENTER);slot.setPadding(7,8,7,8);slot.setBackgroundColor(0xcc263746);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,72,1);p.setMargins(2,0,2,12);hotbar.addView(slot,p);slots[i]=slot;slot.setOnClickListener(v->selectSlot(index));}
        FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);bp.leftMargin=250;bp.rightMargin=250;root.addView(hotbar,bp);selectSlot(0);
        game.setOnTouchListener((v,e)->{float x=e.getX(),y=e.getY();if(e.getAction()==MotionEvent.ACTION_DOWN){lastX=x;lastY=y;rotating=x>v.getWidth()*.42f;return rotating;}if(e.getAction()==MotionEvent.ACTION_MOVE&&rotating){game.renderer.rotate((x-lastX)*.006f,(y-lastY)*.004f);lastX=x;lastY=y;return true;}if(e.getAction()==MotionEvent.ACTION_UP){rotating=false;return true;}return rotating;});
        setContentView(root);
    }
    private void selectSlot(int i){selected=i;game.renderer.selectBlock(blockIds[i]);for(int n=0;n<9;n++)slots[n].setBackgroundColor(n==i?0xffd69b32:0xcc263746);}
    private void showInventory(){
        final String[] names={"Herbe","Terre","Pierre","Bois","Feuilles"};
        new android.app.AlertDialog.Builder(this).setTitle("Inventaire").setItems(names,(d,which)->{for(int i=0;i<9;i++)if(blockIds[i]==which+1){selectSlot(i);break;}}).setNegativeButton("Fermer",null).show();
    }
    private void addHold(FrameLayout root,String s,int g,int x,int y,Runnable down,Runnable up){TextView b=button(s);FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(92,82,g);if((g&Gravity.LEFT)==Gravity.LEFT)p.leftMargin=x;p.bottomMargin=y;root.addView(b,p);b.setOnTouchListener((v,e)->{if(e.getAction()==0){down.run();return true;}if(e.getAction()==1||e.getAction()==3){up.run();return true;}return true;});}
    private void addTap(FrameLayout root,String s,int g,int x,int y,Runnable action){TextView b=button(s);FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(94,58,g);if((g&Gravity.RIGHT)==Gravity.RIGHT)p.rightMargin=x;if((g&Gravity.TOP)==Gravity.TOP)p.topMargin=y;else p.bottomMargin=y;root.addView(b,p);b.setOnClickListener(v->action.run());}
    private TextView button(String s){TextView t=label(s,14);t.setGravity(Gravity.CENTER);t.setBackgroundColor(0xaa183344);return t;}
    private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);return t;}
    @Override protected void onPause(){super.onPause();if(game!=null)game.onPause();}
    @Override protected void onResume(){super.onResume();if(game!=null)game.onResume();}
    static class GameSurface extends GLSurfaceView{final WorldRenderer renderer;GameSurface(Activity c){super(c);setEGLContextClientVersion(2);renderer=new WorldRenderer(c);setRenderer(renderer);setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);}}
}
