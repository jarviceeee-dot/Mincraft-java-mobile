# Feuille de route Ractex Bedrock Java

- [x] 0.1 — squelette Android / OpenGL ES
- [x] 0.2 — terrain de démonstration et commandes tactiles
- [x] 0.3 — blocs 3D indépendants, hotbar, inventaire simple, sauvegarde locale
- [x] 0.4 — gravité, saut et collisions de base
- [x] 0.5 — textures (atlas 16x16, pixels nets, ombrage par face)
- [ ] 0.5b — génération de chunks
- [ ] 0.6 — inventaire avec quantités et interactions plus complètes
- [ ] 0.7 — API de mods propre au projet (pas compatibilité Fabric automatique)
