# Compilation iOS avec GitHub Actions

Le workflow `.github/workflows/ios.yml` lance une compilation sur un runner macOS de GitHub et publie une archive `.app` pour le **simulateur iOS**.

## Lancer le workflow
1. Envoie le dépôt sur GitHub.
2. Ouvre l’onglet **Actions**.
3. Choisis **Build iOS (Ractex)** puis **Run workflow**.
4. Indique le nom du scheme Xcode, puis lance le workflow.
5. Quand il réussit, récupère `Ractex-iOS-Simulator` dans **Artifacts**.

## Limite importante pour Ractex 0.12
Cette archive contient actuellement une application Android native : `settings.gradle`, `app/build.gradle`, `AndroidManifest.xml` et du code Java Android. Elle ne contient ni projet Xcode (`.xcodeproj`/`.xcworkspace`), ni cible iOS. Le workflow est donc prêt côté GitHub, mais il s’arrêtera volontairement avec un message clair tant qu’une véritable application iOS n’aura pas été créée dans `ios/`.

Ce workflow produit une application pour **simulateur**, pas un IPA installable sur iPhone. Pour produire un IPA, il faudra ajouter une cible iOS puis configurer la signature Apple (certificat, provisioning profile et secrets GitHub). GitHub Actions ne convertit pas automatiquement le code Android Java en application iOS.
