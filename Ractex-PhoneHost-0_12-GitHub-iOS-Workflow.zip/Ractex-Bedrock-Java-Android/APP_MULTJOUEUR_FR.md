# Ractex 0.12 — hébergement depuis le téléphone

## Comportement intégré
- À l'entrée dans un monde, l'application démarre un serveur WebSocket sur le téléphone (port TCP 28765).
- Un code d'invitation à 6 caractères est créé.
- L'écran affiche le code et les adresses réseau locales.
- Le serveur s'arrête lorsque le joueur quitte le monde ou ferme l'application.
- Un client peut se connecter à l'adresse `ws://IP_DU_TELEPHONE:28765` avec le code affiché.

## Limite réseau importante
Cette version permet le test sur le même réseau local/Wi-Fi. Un code d'invitation ne suffit pas à traverser Internet : pour un ami dans un autre pays, il faut un relais public ou une redirection de port publique. Les réseaux mobiles utilisent souvent le CGNAT, ce qui bloque les connexions entrantes directes. Aucun relais cloud n'est fourni ou hébergé automatiquement dans cette archive.

## Limite de jeu
Le serveur relaie l'entrée dans le salon et des paquets JSON/chat. Il ne synchronise PAS encore les entités, déplacements, chunks, blocs, inventaires, météo ou sauvegardes entre les clients. Les joueurs ne peuvent donc pas encore jouer dans un monde partagé complet. Il s'agit de la couche réseau/hébergement locale à intégrer ensuite au moteur `World` et `WorldRenderer`.

## Compilation
Le ZIP contient le projet Android Studio source. Il n'inclut pas un APK compilé. Il faut compiler le projet avec Android Gradle Plugin/Gradle et Java 17.
