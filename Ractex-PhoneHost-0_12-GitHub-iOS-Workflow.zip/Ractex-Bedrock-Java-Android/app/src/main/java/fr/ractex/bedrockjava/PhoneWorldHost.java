package fr.ractex.bedrockjava;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONObject;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.security.SecureRandom;

public final class PhoneWorldHost {
    public static final int PORT = 28765;
    public interface Listener {
        void onStarted(String code, String addresses);
        void onClientCount(int count);
        void onMessage(String message);
        void onError(String message);
    }
    private final Listener listener;
    private final String inviteCode;
    private final Set<WebSocket> clients = ConcurrentHashMap.newKeySet();
    private volatile boolean running;
    private WebSocketServer server;
    public PhoneWorldHost(Listener listener) {
        this.listener = listener;
        this.inviteCode = makeCode();
    }
    private static String makeCode() {
        final String chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        SecureRandom random = new SecureRandom();
        StringBuilder b = new StringBuilder();
        for (int i=0;i<6;i++) b.append(chars.charAt(random.nextInt(chars.length())));
        return b.toString();
    }
    public String getInviteCode() { return inviteCode; }
    public boolean isRunning() { return running; }
    public String getLocalAddresses() {
        StringBuilder out = new StringBuilder();
        try {
            Enumeration<NetworkInterface> all = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface ni : Collections.list(all)) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        if (out.length() > 0) out.append("\n");
                        out.append("ws://").append(a.getHostAddress()).append(":").append(PORT);
                    }
                }
            }
        } catch (Exception ignored) { }
        return out.length() == 0 ? "Adresse Wi-Fi indisponible" : out.toString();
    }
    public void start() {
        try {
            server = new WebSocketServer(new InetSocketAddress("0.0.0.0", PORT)) {
                @Override public void onOpen(WebSocket conn, ClientHandshake handshake) { }
                @Override public void onClose(WebSocket conn, int code, String reason, boolean remote) {
                    boolean removed = clients.remove(conn);
                    if (removed && listener != null) listener.onClientCount(clients.size());
                }
                @Override public void onMessage(WebSocket conn, String raw) {
                    try {
                        JSONObject msg = new JSONObject(raw);
                        String type = msg.optString("type");
                        if (!clients.contains(conn)) {
                            if (!"join".equals(type) || !inviteCode.equalsIgnoreCase(msg.optString("code"))) {
                                conn.send(new JSONObject().put("type","error").put("message","Code incorrect").toString());
                                conn.close(); return;
                            }
                            if (clients.size() >= 7) {
                                conn.send(new JSONObject().put("type","error").put("message","Serveur complet").toString());
                                conn.close(); return;
                            }
                            clients.add(conn);
                            conn.send(new JSONObject().put("type","joined").put("code",inviteCode).toString());
                            if (listener != null) listener.onClientCount(clients.size());
                            broadcast(new JSONObject().put("type","player_joined").put("name",msg.optString("name","Joueur")));
                            return;
                        }
                        if ("chat".equals(type)) {
                            String message = msg.optString("message","");
                            if (message.length() > 240) message = message.substring(0,240);
                            broadcast(new JSONObject().put("type","chat").put("name",msg.optString("name","Joueur")).put("message",message));
                        } else if ("world".equals(type)) {
                            broadcast(new JSONObject().put("type","world").put("event",msg.optString("event",""))
                                .put("data",msg.optJSONObject("data") == null ? new JSONObject() : msg.optJSONObject("data")));
                        }
                    } catch (Exception e) {
                        try { conn.send(new JSONObject().put("type","error").put("message","Paquet invalide").toString()); } catch (Exception ignored) { }
                    }
                }
                @Override public void onError(WebSocket conn, Exception ex) {
                    if (listener != null && ex != null) listener.onError(ex.getMessage() == null ? "Erreur réseau" : ex.getMessage());
                }
                @Override public void onStart() {
                    running = true;
                    if (listener != null) listener.onStarted(inviteCode, getLocalAddresses());
                }
                private void broadcast(JSONObject packet) {
                    String json = packet.toString();
                    for (WebSocket c : clients) if (c.isOpen()) c.send(json);
                }
            };
            server.setReuseAddr(true);
            server.start();
        } catch (Exception e) {
            if (listener != null) listener.onError("Impossible de démarrer le serveur sur le port " + PORT);
        }
    }
    public void stop() {
        running = false;
        try { if (server != null) server.stop(500); } catch (Exception ignored) { }
        server = null;
        clients.clear();
    }
}
