# Feuille de route Ractex Bedrock Java

- [x] 0.1 — squelette Android / OpenGL ES
- [x] 0.2 — terrain de démonstration et commandes tactiles
- [x] 0.3 — blocs 3D indépendants, hotbar, inventaire simple, sauvegarde locale
- [x] 0.4 — gravité, saut et collisions de base
- [x] 0.5 — textures (atlas 16x16, pixels nets, ombrage par face)
- [x] 0.6 — monde infini par seed, chunks chargés autour du joueur, sauvegarde seed + modifications + position
- [x] 0.7 — menu de départ (Jouer, mondes, création avec seed, paramètres, pause)
- [x] 0.7.1 — correctif du blocage au sol, vraie interface (viseur, hotbar à icônes, inventaire)
- [ ] 0.8 — inventaire avec quantités et interactions plus complètes
- [ ] 0.9 — API de mods propre au projet (pas compatibilité Fabric automatique)
