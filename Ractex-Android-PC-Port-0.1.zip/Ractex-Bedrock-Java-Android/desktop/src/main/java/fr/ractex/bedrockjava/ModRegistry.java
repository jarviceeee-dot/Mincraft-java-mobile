package fr.ractex.bedrockjava;
/** Desktop compatibility bridge; full Android resource-pack loader is not yet ported. */
final class ModRegistry { static final int MISSING_TILE = 0; private ModRegistry() {} }
