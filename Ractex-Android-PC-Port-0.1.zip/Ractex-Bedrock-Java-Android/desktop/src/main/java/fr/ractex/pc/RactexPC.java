package fr.ractex.pc;

import fr.ractex.bedrockjava.World;
import fr.ractex.bedrockjava.Chunk;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;
import java.nio.FloatBuffer;
import java.util.Random;

/** PC port foundation using the same World/Chunk generation and save format as Android. */
public final class RactexPC {
    private long window;
    private final World world = new World(new Random().nextLong());
    private double px=8, py=32, pz=8, yaw=0, pitch=-0.25;
    private boolean mouseCaptured=true;
    private double lastX,lastY; private boolean firstMouse=true;
    private RactexPC() {}
    public static void main(String[] args) { new RactexPC().run(); }
    private void run() {
        if (!GLFW.glfwInit()) throw new IllegalStateException("Impossible d'initialiser GLFW");
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR,2);
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR,1);
        window=GLFW.glfwCreateWindow(1280,720,"Ractex — PC",MemoryUtil.NULL,MemoryUtil.NULL);
        if(window==MemoryUtil.NULL) throw new RuntimeException("Fenêtre Ractex impossible à créer");
        GLFW.glfwMakeContextCurrent(window); GLFW.glfwSwapInterval(1); GL.createCapabilities();
        GLFW.glfwSetInputMode(window,GLFW.GLFW_CURSOR,GLFW.GLFW_CURSOR_DISABLED);
        GLFW.glfwSetCursorPosCallback(window,(w,x,y)->{
            if(firstMouse){lastX=x;lastY=y;firstMouse=false;}
            double dx=x-lastX,dy=y-lastY;lastX=x;lastY=y;
            if(mouseCaptured){yaw+=dx*0.0025;pitch=Math.max(-1.45,Math.min(1.45,pitch-dy*0.0025));}
        });
        GLFW.glfwSetKeyCallback(window,(w,key,sc,action,mods)->{
            if(key==GLFW.GLFW_KEY_ESCAPE && action==GLFW.GLFW_PRESS){mouseCaptured=!mouseCaptured;GLFW.glfwSetInputMode(window,GLFW.GLFW_CURSOR,mouseCaptured?GLFW.GLFW_CURSOR_DISABLED:GLFW.GLFW_CURSOR_NORMAL);firstMouse=true;}
            if(key==GLFW.GLFW_KEY_F5 && action==GLFW.GLFW_PRESS) save();
        });
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        while(!GLFW.glfwWindowShouldClose(window)){
            update(); render(); GLFW.glfwSwapBuffers(window); GLFW.glfwPollEvents();
        }
        save(); GLFW.glfwDestroyWindow(window); GLFW.glfwTerminate();
    }
    private void update(){
        double speed=0.12, fx=Math.sin(yaw), fz=-Math.cos(yaw), rx=Math.cos(yaw), rz=Math.sin(yaw);
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_W)==GLFW.GLFW_PRESS){px+=fx*speed;pz+=fz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_S)==GLFW.GLFW_PRESS){px-=fx*speed;pz-=fz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_A)==GLFW.GLFW_PRESS){px-=rx*speed;pz-=rz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_D)==GLFW.GLFW_PRESS){px+=rx*speed;pz+=rz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_SPACE)==GLFW.GLFW_PRESS)py+=speed;
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_LEFT_SHIFT)==GLFW.GLFW_PRESS)py-=speed;
        world.loadChunk((int)Math.floor(px)>>4,(int)Math.floor(pz)>>4);
    }
    private void render(){
        int[] ww={0},hh={0}; GLFW.glfwGetFramebufferSize(window,ww,hh); int w=Math.max(1,ww[0]),h=Math.max(1,hh[0]);
        GL11.glViewport(0,0,w,h); GL11.glClearColor(0.48f,0.70f,0.94f,1); GL11.glClear(GL11.GL_COLOR_BUFFER_BIT|GL11.GL_DEPTH_BUFFER_BIT);
        GL11.glMatrixMode(GL11.GL_PROJECTION);GL11.glLoadIdentity(); perspective(70,(float)w/h,.1f,180);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);GL11.glLoadIdentity();
        GL11.glRotatef((float)Math.toDegrees(pitch),1,0,0);GL11.glRotatef((float)Math.toDegrees(yaw),0,1,0);GL11.glTranslated(-px,-py,-pz);
        GL11.glBegin(GL11.GL_QUADS);
        int cx=(int)Math.floor(px),cz=(int)Math.floor(pz);
        for(int x=cx-24;x<=cx+24;x++)for(int z=cz-24;z<=cz+24;z++){
            int top=world.heightAt(x,z); float xf=x,zf=z;
            // top surface and simple dirt side walls, derived from the exact shared terrain generator
            colorFor((byte)(top <= World.SAND_LEVEL ? World.SAND : World.GRASS));
            GL11.glVertex3f(xf,top+1,zf); GL11.glVertex3f(xf+1,top+1,zf); GL11.glVertex3f(xf+1,top+1,zf+1); GL11.glVertex3f(xf,top+1,zf+1);
            int below=Math.max(0,top-3); colorFor(World.DIRT);
            if(top>below) { GL11.glVertex3f(xf,below,zf);GL11.glVertex3f(xf+1,below,zf);GL11.glVertex3f(xf+1,top+1,zf);GL11.glVertex3f(xf,top+1,zf); }
        }
        GL11.glEnd();
    }
    private static void quad(float x,float y,float z,float X,float Y,float Z){GL11.glVertex3f(x,y,z);GL11.glVertex3f(X,y,z);GL11.glVertex3f(X,Y,Z);GL11.glVertex3f(x,Y,Z);}
    private static void colorFor(byte id){if(id==World.GRASS)GL11.glColor3f(.28f,.68f,.24f);else if(id==World.SAND)GL11.glColor3f(.78f,.70f,.46f);else GL11.glColor3f(.43f,.31f,.20f);}
    private static void perspective(float fov,float aspect,float near,float far){float top=(float)(near*Math.tan(Math.toRadians(fov)*.5));float right=top*aspect;GL11.glFrustum(-right,right,-top,top,near,far);}
    private void save(){try{world.save(new java.io.File("ractex-world.rwx"),(float)px,(float)py,(float)pz);}catch(Exception e){System.err.println("Sauvegarde impossible: "+e.getMessage());}}
}
