# Textures Minecraft intégrées à Ractex

Cette version embarque les deux archives fournies :
- `app/src/main/assets/resource_packs/minecraft-default-1.20.5-26.2.zip` : pack complet, conservé dans l'application (blocs, objets, entités, GUI et autres ressources).
- `app/src/main/assets/resource_packs/recompleted-gui.zip` : pack GUI Recompleted fourni.

Au premier chargement du registre, Ractex copie le pack Minecraft dans `files/mods/`. Le chargeur de blocs existant tente ensuite de lire les modèles cubiques et leurs textures depuis ce ZIP, comme pour un pack/mod Java importé.

## Limites actuelles importantes

Le fait d'embarquer les fichiers PNG ne signifie pas que tous les blocs et objets sont déjà utilisables en jeu :
- Le moteur actuel utilise des IDs de blocs internes limités à 0–127 et ne peut enregistrer qu'un nombre limité de blocs supplémentaires.
- Le chargeur ne prend en charge qu'un sous-ensemble de modèles de blocs cubiques. Les blocs complexes (escaliers, clôtures, plantes, blocs orientables complexes, etc.) ne sont pas tous rendus correctement.
- Les textures d'objets sont bien présentes dans le pack intégré, mais l'inventaire actuel ne possède pas encore de registre/rendu générique pour afficher tous les objets Minecraft.
- Les fichiers du pack Recompleted GUI sont embarqués pour référence ; l'interface actuelle n'est pas automatiquement remplacée par les 603 textures de ce pack.
- Le pack est issu de Minecraft Java 1.20.5–26.2 : certaines ressources/modèles peuvent ne pas correspondre exactement aux versions Bedrock ou aux versions futures.

Il s'agit d'une intégration des ressources et du chargement partiel des blocs, pas d'une conversion complète de Minecraft ni d'une garantie de compatibilité avec tous les contenus.
