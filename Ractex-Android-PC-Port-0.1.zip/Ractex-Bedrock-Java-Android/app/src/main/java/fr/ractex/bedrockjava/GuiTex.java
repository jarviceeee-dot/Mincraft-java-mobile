package fr.ractex.bedrockjava;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Textures GUI (assets/gui/*.png, pack « Recompleted GUI » de YAPK0) : chargement et dessin en pixels nets. */
final class GuiTex {
    private final Context ctx;
    private final Map<String, Bitmap> cache = new HashMap<>();
    GuiTex(Context c) { ctx = c; }

    /** Texture d'origine, sans aucune mise à l'échelle. */
    Bitmap get(String name) {
        Bitmap b = cache.get(name);
        if (b == null) {
            try (InputStream in = ctx.getAssets().open("gui/" + name + ".png")) {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inScaled = false;
                b = BitmapFactory.decodeStream(in, null, o);
            } catch (Exception e) { b = null; }
            if (b == null) b = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            cache.put(name, b);
        }
        return b;
    }

    /** Texture agrandie d'un facteur entier, pixels nets. */
    Bitmap scaled(String name, int k) {
        Bitmap b = get(name);
        return Bitmap.createScaledBitmap(b, b.getWidth() * k, b.getHeight() * k, false);
    }
    /** Morceau d'une texture (en pixels d'origine), agrandi d'un facteur entier. */
    Bitmap region(String name, int x, int y, int w, int h, int k) {
        return Bitmap.createScaledBitmap(Bitmap.createBitmap(get(name), x, y, w, h), w * k, h * k, false);
    }

    /** Fond étirable (« nine-slice ») : coins fixes, bords et centre étirés. */
    Drawable nine(String name, int border, int scale) { return new NineSlice(get(name), border, scale); }

    /** Bouton Minecraft : normal, et version « highlighted » quand on appuie. */
    Drawable button(int scale) {
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, nine("vanilla_button_highlighted", 2, scale));
        sl.addState(new int[]{-android.R.attr.state_enabled}, nine("vanilla_button_disabled", 2, scale));
        sl.addState(new int[]{}, nine("vanilla_button", 2, scale));
        return sl;
    }

    static final class NineSlice extends Drawable {
        private final Bitmap bmp; private final int border, scale;
        private final Paint paint = new Paint();
        NineSlice(Bitmap b, int border, int scale) {
            bmp = b; this.border = border; this.scale = Math.max(1, scale);
            paint.setFilterBitmap(false); paint.setAntiAlias(false);
        }
        @Override public void draw(Canvas c) {
            Rect r = getBounds(); int w = bmp.getWidth(), h = bmp.getHeight();
            float bw = Math.min(border * scale, r.width() / 2f), bh = Math.min(border * scale, r.height() / 2f);
            int[] sx = {0, border, w - border, w}, sy = {0, border, h - border, h};
            float[] dx = {r.left, r.left + bw, r.right - bw, r.right}, dy = {r.top, r.top + bh, r.bottom - bh, r.bottom};
            Rect s = new Rect(); RectF d = new RectF();
            for (int j = 0; j < 3; j++) for (int i = 0; i < 3; i++) {
                s.set(sx[i], sy[j], sx[i + 1], sy[j + 1]); d.set(dx[i], dy[j], dx[i + 1], dy[j + 1]);
                c.drawBitmap(bmp, s, d, paint);
            }
        }
        @Override public void setAlpha(int a) { paint.setAlpha(a); invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter f) { paint.setColorFilter(f); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Drawable simple d'un bitmap déjà à la bonne taille, sans lissage. */
    static Drawable crisp(Context c, Bitmap b) {
        BitmapDrawable d = new BitmapDrawable(c.getResources(), b); d.setFilterBitmap(false); d.setAntiAlias(false); return d;
    }
}
