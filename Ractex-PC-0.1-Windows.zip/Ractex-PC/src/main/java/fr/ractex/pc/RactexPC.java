package fr.ractex.pc;

import fr.ractex.bedrockjava.World;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.Random;

/** Première base desktop de Ractex. Réutilise le générateur et le format de sauvegarde Java pur. */
public final class RactexPC {
    private static final File SAVES = new File(System.getProperty("user.home"), ".ractex/worlds");
    private JFrame frame; private CardLayout cards; private JPanel root; private World world;
    private String worldName = "Mon monde"; private int px, pz;
    public static void main(String[] args) { SwingUtilities.invokeLater(() -> new RactexPC().show()); }
    private void show() {
        frame=new JFrame("Ractex — édition PC"); frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setMinimumSize(new Dimension(960,600)); frame.setSize(1200,760); frame.setLocationRelativeTo(null);
        cards=new CardLayout(); root=new JPanel(cards); root.add(menu(),"menu"); frame.setContentPane(root); cards.show(root,"menu"); frame.setVisible(true);
    }
    private JPanel menu() {
        JPanel p=new JPanel(new GridBagLayout()) { protected void paintComponent(Graphics gg) { super.paintComponent(gg); Graphics2D g=(Graphics2D)gg.create(); g.setPaint(new GradientPaint(0,0,new Color(80,145,205),0,getHeight(),new Color(35,75,45))); g.fillRect(0,0,getWidth(),getHeight()); g.dispose(); }};
        GridBagConstraints c=new GridBagConstraints(); c.gridx=0;c.insets=new Insets(9,12,9,12);c.fill=GridBagConstraints.HORIZONTAL;
        JLabel title=new JLabel("RACTEX",SwingConstants.CENTER);title.setFont(new Font("Arial",Font.BOLD,64));title.setForeground(Color.WHITE);c.gridy=0;p.add(title,c);
        JLabel sub=new JLabel("ÉDITION PC — prototype 0.1",SwingConstants.CENTER);sub.setForeground(Color.WHITE);sub.setFont(new Font("Arial",Font.BOLD,18));c.gridy++;p.add(sub,c);
        c.gridy++;p.add(button("JOUER",e->createWorld()),c);c.gridy++;p.add(button("CHARGER UN MONDE",e->loadWorld()),c);
        c.gridy++;p.add(button("OPTIONS",e->JOptionPane.showMessageDialog(frame,"Déplacement : ZQSD / WASD / flèches\nÉchap : menu de pause","Options",1)),c);
        c.gridy++;p.add(button("QUITTER",e->frame.dispose()),c);return p;
    }
    private JButton button(String s,ActionListener a){JButton b=new JButton(s);b.setFont(new Font("Arial",Font.BOLD,19));b.setForeground(Color.WHITE);b.setBackground(new Color(75,75,75));b.setFocusPainted(false);b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.BLACK,2),BorderFactory.createEmptyBorder(12,25,12,25)));b.addActionListener(a);return b;}
    private void createWorld(){ JTextField name=new JTextField("Mon monde"),seed=new JTextField(Long.toString(new Random().nextLong()));JPanel form=new JPanel(new GridLayout(0,1,4,4));form.add(new JLabel("Nom du monde"));form.add(name);form.add(new JLabel("Seed"));form.add(seed);if(JOptionPane.showConfirmDialog(frame,form,"Créer un monde",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)return;worldName=name.getText().isBlank()?"Mon monde":name.getText().trim();long s;try{s=Long.parseLong(seed.getText().trim());}catch(Exception ex){s=seed.getText().hashCode();}world=new World(s);px=pz=0;openGame();}
    private void loadWorld(){SAVES.mkdirs();File[] fs=SAVES.listFiles((d,n)->n.endsWith(".rworld"));if(fs==null||fs.length==0){JOptionPane.showMessageDialog(frame,"Aucun monde sauvegardé.");return;}String[] names=new String[fs.length];for(int i=0;i<fs.length;i++)names[i]=fs[i].getName();String chosen=(String)JOptionPane.showInputDialog(frame,"Choisis un monde","Charger",1,null,names,names[0]);if(chosen==null)return;world=new World(0);if(!world.load(new File(SAVES,chosen))){JOptionPane.showMessageDialog(frame,"Sauvegarde illisible.");return;}worldName=chosen.substring(0,chosen.length()-7);float[] pos=world.takeSavedPlayer();if(pos!=null){px=Math.round(pos[0]);pz=Math.round(pos[2]);}openGame();}
    private void openGame(){GamePanel panel=new GamePanel();root.add(panel,"game");cards.show(root,"game");panel.requestFocusInWindow();}
    private void saveAndMenu(){try{SAVES.mkdirs();world.save(new File(SAVES,worldName.replaceAll("[^a-zA-Z0-9_-]","_")+".rworld"),px,world.surfaceAt(px,pz)+2,pz);}catch(Exception ex){JOptionPane.showMessageDialog(frame,"Erreur : "+ex.getMessage());}cards.show(root,"menu");}
    private final class GamePanel extends JPanel {
        private final int tile=23;
        GamePanel(){setFocusable(true);setBackground(new Color(100,170,225));bind(KeyEvent.VK_W,0,-1);bind(KeyEvent.VK_Z,0,-1);bind(KeyEvent.VK_UP,0,-1);bind(KeyEvent.VK_S,0,1);bind(KeyEvent.VK_DOWN,0,1);bind(KeyEvent.VK_A,-1,0);bind(KeyEvent.VK_Q,-1,0);bind(KeyEvent.VK_LEFT,-1,0);bind(KeyEvent.VK_D,1,0);bind(KeyEvent.VK_RIGHT,1,0);getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,0),"pause");getActionMap().put("pause",new AbstractAction(){public void actionPerformed(ActionEvent e){pause();}});}
        void bind(int key,int dx,int dz){String k="move"+key;getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(key,0),k);getActionMap().put(k,new AbstractAction(){public void actionPerformed(ActionEvent e){px+=dx;pz+=dz;repaint();}});}
        protected void paintComponent(Graphics gg){super.paintComponent(gg);Graphics2D g=(Graphics2D)gg.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setPaint(new GradientPaint(0,0,new Color(90,165,225),0,getHeight(),new Color(205,230,245)));g.fillRect(0,0,getWidth(),getHeight());long t=System.currentTimeMillis()/100;for(int i=0;i<8;i++){int x=(int)((i*191+t)%(getWidth()+130))-65,y=45+(i%3)*35;g.setColor(new Color(255,255,255,190));g.fillOval(x,y,82,23);g.fillOval(x+22,y-12,48,30);g.fillOval(x+50,y,58,22);}int cx=getWidth()/2,cy=getHeight()/2+35;int r=17;for(int x=px-r;x<=px+r;x++)for(int z=pz-r;z<=pz+r;z++){world.loadChunk(x>>4,z>>4);int h=world.surfaceAt(x,z),sx=cx+(x-px-z+pz)*tile,sy=cy+(x-px+z-pz)*tile/2-(h-world.surfaceAt(px,pz))*7;Polygon q=new Polygon(new int[]{sx,sx+tile,sx,sx-tile},new int[]{sy-tile/2,sy,sy+tile/2,sy},4);int n=Math.floorMod(x*13+z*29,24);g.setColor(h<=World.SAND_LEVEL?new Color(210,190,125):new Color(60+n/2,130+n,55+n/3));g.fillPolygon(q);g.setColor(new Color(0,0,0,35));g.drawPolygon(q);if(h>World.SAND_LEVEL&&Math.floorMod(x*31+z*17,93)==0){g.setColor(new Color(95,65,38));g.fillRect(sx-3,sy-25,6,28);g.setColor(new Color(40,125,48));g.fillOval(sx-18,sy-50,36,32);}}g.setColor(new Color(35,75,180));g.fillRect(cx-8,cy-41,16,26);g.setColor(new Color(225,185,145));g.fillRect(cx-7,cy-55,14,14);g.setColor(Color.DARK_GRAY);g.fillRect(cx-8,cy-15,6,15);g.fillRect(cx+2,cy-15,6,15);g.setColor(Color.WHITE);g.drawString("X: "+px+"  Z: "+pz+"  |  "+worldName,15,22);g.fillRoundRect(getWidth()/2-145,getHeight()-54,290,38,8,8);g.setColor(Color.BLACK);g.drawString("ZQSD / WASD : bouger   ÉCHAP : pause",getWidth()/2-130,getHeight()-30);g.dispose();}
        private void pause(){Object[] o={"Reprendre","Sauvegarder et menu","Quitter sans sauvegarder"};int v=JOptionPane.showOptionDialog(frame,"Partie en pause","Ractex",-1,1,null,o,o[0]);if(v==1)saveAndMenu();else if(v==2)cards.show(root,"menu");requestFocusInWindow();}
    }
}
