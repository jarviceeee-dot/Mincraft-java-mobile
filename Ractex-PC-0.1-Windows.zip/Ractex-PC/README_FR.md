# Ractex PC — prototype 0.1

Première base desktop Windows du projet Ractex. Elle réutilise directement les classes Java pures `World.java` et `Chunk.java` du projet Android, notamment le générateur de terrain et le format de sauvegarde.

## Inclus
- Application Java desktop avec menu principal.
- Création de monde avec nom et seed, chargement et sauvegarde locale.
- Terrain généré à partir du générateur Ractex, affiché dans une vue isométrique 2D provisoire.
- Ciel et nuages animés, avatar et coordonnées.
- Déplacement ZQSD, WASD ou flèches ; Échap ouvre la pause.
- Packs de ressources fournis copiés dans `src/main/resources` pour leur intégration au rendu PC.

## Ce qui n'est pas encore porté
Ce prototype n'est pas encore le moteur 3D Android complet : rendu voxel 3D, shaders, minage/pose, inventaire complet, mods, skins et multijoueur restent à porter. Les packs de textures sont inclus mais pas encore branchés au rendu PC. L'exécutable Windows est produit par le workflow GitHub Actions, pas déjà compilé ici.

## Lancer depuis un PC avec JDK 17 et Gradle
Dans ce dossier : `gradle run`.
