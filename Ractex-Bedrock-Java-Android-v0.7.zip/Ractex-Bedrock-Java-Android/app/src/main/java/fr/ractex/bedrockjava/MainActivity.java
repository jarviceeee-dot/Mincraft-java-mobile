package fr.ractex.bedrockjava;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String VERSION = "0.7";
    private static final String[] SPLASH = {"Pixels nets !", "Monde infini !", "Même seed, même monde !", "100% Java !", "Creuse, creuse !", "Fait sur téléphone !", "Un chunk à la fois !"};

    private FrameLayout root, gameLayer;
    private View menuLayer;
    private Runnable onBack;
    private GameSurface game;
    private TextView hud;
    private final TextView[] slots = new TextView[9];
    private float lastX, lastY;
    private boolean rotating, inGame;
    private File currentFile;
    private String currentName;
    private SharedPreferences prefs;
    private final int[] blockIds = {World.GRASS, World.DIRT, World.STONE, World.WOOD, World.LEAVES, World.DIRT, World.STONE, World.WOOD, World.GRASS};
    private final String[] blockNames = {"Herbe", "Terre", "Pierre", "Bois", "Feuilles", "Terre", "Pierre", "Bois", "Herbe"};

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs = getSharedPreferences("ractex", MODE_PRIVATE);
        root = new FrameLayout(this);
        setContentView(root);
        migrateLegacySave();
        showTitle();
    }

    // =====================================================================
    //  Menus
    // =====================================================================
    private void setMenu(View v, Runnable back) {
        if (menuLayer != null) root.removeView(menuLayer);
        menuLayer = v; onBack = back;
        if (v != null) { v.setClickable(true); root.addView(v, new FrameLayout.LayoutParams(-1, -1)); }
    }

    /** Écran titre : logo, phrase jaune, Jouer / Paramètres / Quitter. */
    private void showTitle() {
        LinearLayout col = column();
        col.setGravity(Gravity.CENTER);
        TextView logo = text("RACTEX", 46, 0xFFE8E8E8, true);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); logo.setLetterSpacing(.12f);
        logo.setShadowLayer(dp(2), dp(3), dp(3), 0xFF2A2A2A);
        TextView sub = text("BEDROCK JAVA EDITION", 15, 0xFFBDBDBD, true);
        sub.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); sub.setLetterSpacing(.2f);
        TextView splash = text(SPLASH[new Random().nextInt(SPLASH.length)], 15, 0xFFFFFF55, true);
        splash.setRotation(-6f); splash.setShadowLayer(1, 2, 2, 0xFF3F3F00);
        col.addView(logo); col.addView(sub);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2); sp.topMargin = dp(8); sp.bottomMargin = dp(14);
        col.addView(splash, sp);
        col.addView(mcButton("Jouer", true, this::showWorlds), wide());
        col.addView(mcButton("Paramètres", false, () -> showSettings(this::showTitle)), wide());
        col.addView(mcButton("Quitter le jeu", false, this::finish), wide());
        FrameLayout f = background();
        f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        TextView v = text("Ractex " + VERSION, 11, 0xFFFFFFFF, false);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT); vp.leftMargin = dp(10); vp.bottomMargin = dp(6);
        f.addView(v, vp);
        setMenu(f, this::finish);
    }

    /** Liste des mondes + création. */
    private void showWorlds() {
        LinearLayout col = column();
        col.addView(text("Jouer", 22, Color.WHITE, true));
        col.addView(mcButton("Créer un nouveau monde", true, this::showCreate), wide());
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setGravity(Gravity.CENTER_HORIZONTAL);
        ScrollView sv = new ScrollView(this); sv.addView(list, new ScrollView.LayoutParams(-1, -2));
        File[] files = worldsDir().listFiles((d, n) -> n.endsWith(".dat"));
        if (files == null) files = new File[0];
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE);
        int shown = 0;
        for (File f : files) {
            Long seed = World.peekSeed(f);
            if (seed == null) continue;
            final String name = f.getName().substring(0, f.getName().length() - 4);
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView b = mcButton(name + "\nSeed : " + seed + "  ·  " + fmt.format(new Date(f.lastModified())), false, () -> startGame(f, name));
            b.setTextSize(14);
            row.addView(b, new LinearLayout.LayoutParams(dp(300), dp(56)));
            TextView x = mcButton("✕", false, () -> confirmDelete(f, name));
            LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(46), dp(56)); xp.leftMargin = dp(6);
            row.addView(x, xp);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2); rp.topMargin = dp(3); rp.bottomMargin = dp(3);
            list.addView(row, rp); shown++;
        }
        if (shown == 0) { TextView e = text("Aucun monde pour l'instant. Crées-en un !", 14, 0xFFDDDDDD, true); e.setPadding(0, dp(20), 0, 0); list.addView(e); }
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        col.addView(mcButton("Retour", false, this::showTitle), wide());
        FrameLayout f = background(); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showTitle);
    }

    private void confirmDelete(File f, String name) {
        new AlertDialog.Builder(this).setTitle("Supprimer « " + name + " » ?").setMessage("Ce monde sera définitivement effacé.")
            .setPositiveButton("Supprimer", (d, w) -> { f.delete(); showWorlds(); }).setNegativeButton("Annuler", null).show();
    }

    /** Création d'un monde : nom + seed. */
    private void showCreate() {
        LinearLayout col = column();
        col.addView(text("Créer un nouveau monde", 22, Color.WHITE, true));
        col.addView(text("Nom du monde", 13, 0xFFCCCCCC, false));
        final EditText name = field("Nouveau monde"); name.setText("Nouveau monde");
        col.addView(name, new LinearLayout.LayoutParams(dp(300), -2));
        col.addView(text("Seed (vide = aléatoire, nombre ou texte)", 13, 0xFFCCCCCC, false));
        final EditText seed = field("Aléatoire");
        col.addView(seed, new LinearLayout.LayoutParams(dp(300), -2));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(10)); col.addView(new View(this), gap);
        col.addView(mcButton("Créer le monde", true, () -> {
            String n = sanitize(name.getText().toString());
            File f = freeFile(n); String finalName = f.getName().substring(0, f.getName().length() - 4);
            try { new World(parseSeed(seed.getText().toString())).save(f, 8.5f, Float.NaN, 8.5f); }
            catch (Exception e) { Toast.makeText(this, "Impossible de créer le monde", Toast.LENGTH_SHORT).show(); return; }
            startGame(f, finalName);
        }), wide());
        col.addView(mcButton("Annuler", false, this::showWorlds), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showWorlds);
    }

    /** Paramètres : distance d'affichage et sensibilité. */
    private void showSettings(Runnable back) {
        LinearLayout col = column();
        col.addView(text("Paramètres", 22, Color.WHITE, true));
        addSlider(col, "Distance d'affichage", "dist", 2, 8, 5, " chunks");
        col.addView(text("Appliquée à l'entrée dans un monde. Plus haut = plus beau mais plus lent.", 11, 0xFFBBBBBB, false));
        addSlider(col, "Sensibilité de la caméra", "sens", 1, 12, 6, "");
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(12)); col.addView(new View(this), gap);
        col.addView(mcButton("Terminé", true, back), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, back);
    }

    private void addSlider(LinearLayout col, String label, String key, int min, int max, int def, String unit) {
        final TextView t = text(label + " : " + prefs.getInt(key, def) + unit, 14, Color.WHITE, false);
        final SeekBar s = new SeekBar(this); s.setMax(max - min); s.setProgress(prefs.getInt(key, def) - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean user) { t.setText(label + " : " + (p + min) + unit); prefs.edit().putInt(key, p + min).apply(); }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) {}
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(300), -2); tp.topMargin = dp(10);
        col.addView(t, tp); col.addView(s, new LinearLayout.LayoutParams(dp(300), -2));
    }

    /** Menu pause en jeu. */
    private void showPause() {
        game.renderer.setMovement(0, 0);
        LinearLayout col = column(); col.setGravity(Gravity.CENTER);
        col.addView(text("Jeu en pause", 22, Color.WHITE, true));
        col.addView(text(currentName + "  ·  Seed : " + game.renderer.getSeed(), 13, 0xFFDDDDDD, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(10)); col.addView(new View(this), gap);
        col.addView(mcButton("Reprendre", true, this::resume), wide());
        col.addView(mcButton("Sauvegarder", false, () -> Toast.makeText(this, game.renderer.saveWorld() ? "Monde sauvegardé" : "Erreur de sauvegarde", Toast.LENGTH_SHORT).show()), wide());
        col.addView(mcButton("Paramètres", false, () -> showSettings(this::showPause)), wide());
        col.addView(mcButton("Sauvegarder et quitter", false, this::exitToTitle), wide());
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(0xB8000000); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::resume);
    }
    private void resume() { setMenu(null, null); }

    // =====================================================================
    //  Jeu
    // =====================================================================
    private void startGame(File file, String name) {
        currentFile = file; currentName = name;
        setMenu(null, null);
        gameLayer = buildGame(file, name);
        root.addView(gameLayer, 0, new FrameLayout.LayoutParams(-1, -1));
        inGame = true;
    }
    private void exitToTitle() {
        if (inGame) {
            game.renderer.saveWorld(); game.onPause();
            root.removeView(gameLayer); gameLayer = null; game = null; inGame = false;
        }
        showTitle();
    }

    private FrameLayout buildGame(File file, String name) {
        FrameLayout g = new FrameLayout(this);
        game = new GameSurface(this, prefs.getInt("dist", 5));
        g.addView(game, new FrameLayout.LayoutParams(-1, -1));
        game.renderer.setSaveFile(file);
        hud = label("RACTEX BEDROCK JAVA " + VERSION + "\n" + name + "  ·  Seed " + game.renderer.getSeed(), 12); hud.setPadding(16, 12, 16, 12); hud.setBackgroundColor(0x990b1720);
        g.addView(hud, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT));
        addHold(g, "▲", Gravity.BOTTOM | Gravity.LEFT, 112, 126, () -> game.renderer.setMovement(1, 0), () -> game.renderer.setMovement(0, 0));
        addHold(g, "▼", Gravity.BOTTOM | Gravity.LEFT, 112, 24, () -> game.renderer.setMovement(-1, 0), () -> game.renderer.setMovement(0, 0));
        addHold(g, "◀", Gravity.BOTTOM | Gravity.LEFT, 164, 75, () -> game.renderer.setMovement(0, -1), () -> game.renderer.setMovement(0, 0));
        addHold(g, "▶", Gravity.BOTTOM | Gravity.LEFT, 60, 75, () -> game.renderer.setMovement(0, 1), () -> game.renderer.setMovement(0, 0));
        addTap(g, "CASSER", Gravity.BOTTOM | Gravity.RIGHT, 28, 34, () -> game.renderer.breakBlock());
        addTap(g, "POSER", Gravity.BOTTOM | Gravity.RIGHT, 142, 34, () -> game.renderer.placeBlock());
        addTap(g, "SAUT", Gravity.BOTTOM | Gravity.RIGHT, 85, 112, () -> game.renderer.jump());
        addTap(g, "SAC", Gravity.TOP | Gravity.RIGHT, 16, 16, () -> showInventory());
        addTap(g, "MENU", Gravity.TOP | Gravity.RIGHT, 118, 16, () -> showPause());
        LinearLayout hotbar = new LinearLayout(this); hotbar.setOrientation(LinearLayout.HORIZONTAL); hotbar.setGravity(Gravity.CENTER);
        for (int i = 0; i < 9; i++) {
            final int index = i;
            TextView slot = label((i + 1) + "\n" + blockNames[i], 11); slot.setGravity(Gravity.CENTER); slot.setPadding(7, 8, 7, 8); slot.setBackgroundColor(0xcc263746);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 72, 1); p.setMargins(2, 0, 2, 12); hotbar.addView(slot, p); slots[i] = slot;
            slot.setOnClickListener(v -> selectSlot(index));
        }
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); bp.leftMargin = 250; bp.rightMargin = 250; g.addView(hotbar, bp);
        selectSlot(0);
        game.setOnTouchListener((v, e) -> {
            float x = e.getX(), y = e.getY(), k = prefs.getInt("sens", 6) / 6f;
            if (e.getAction() == MotionEvent.ACTION_DOWN) { lastX = x; lastY = y; rotating = x > v.getWidth() * .42f; return rotating; }
            if (e.getAction() == MotionEvent.ACTION_MOVE && rotating) { game.renderer.rotate((x - lastX) * .006f * k, (y - lastY) * .004f * k); lastX = x; lastY = y; return true; }
            if (e.getAction() == MotionEvent.ACTION_UP) { rotating = false; return true; }
            return rotating;
        });
        return g;
    }
    private void selectSlot(int i) { game.renderer.selectBlock(blockIds[i]); for (int n = 0; n < 9; n++) slots[n].setBackgroundColor(n == i ? 0xffd69b32 : 0xcc263746); }
    private void showInventory() {
        final String[] names = {"Herbe", "Terre", "Pierre", "Bois", "Feuilles"};
        new AlertDialog.Builder(this).setTitle("Inventaire").setItems(names, (d, which) -> { for (int i = 0; i < 9; i++) if (blockIds[i] == which + 1) { selectSlot(i); break; } }).setNegativeButton("Fermer", null).show();
    }
    private void addHold(FrameLayout parent, String s, int g, int x, int y, Runnable down, Runnable up) {
        TextView b = button(s); FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(92, 82, g);
        if ((g & Gravity.LEFT) == Gravity.LEFT) p.leftMargin = x; p.bottomMargin = y; parent.addView(b, p);
        b.setOnTouchListener((v, e) -> { if (e.getAction() == 0) { down.run(); return true; } if (e.getAction() == 1 || e.getAction() == 3) { up.run(); return true; } return true; });
    }
    private void addTap(FrameLayout parent, String s, int g, int x, int y, Runnable action) {
        TextView b = button(s); FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(94, 58, g);
        if ((g & Gravity.RIGHT) == Gravity.RIGHT) p.rightMargin = x;
        if ((g & Gravity.TOP) == Gravity.TOP) p.topMargin = y; else p.bottomMargin = y;
        parent.addView(b, p); b.setOnClickListener(v -> action.run());
    }
    private TextView button(String s) { TextView t = label(s, 14); t.setGravity(Gravity.CENTER); t.setBackgroundColor(0xaa183344); return t; }
    private TextView label(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); return t; }

    // =====================================================================
    //  Mondes (fichiers)
    // =====================================================================
    private File worldsDir() { File d = new File(getFilesDir(), "worlds"); d.mkdirs(); return d; }
    private void migrateLegacySave() {
        File old = new File(getFilesDir(), "ractex_world.dat");
        if (old.exists() && World.peekSeed(old) != null) old.renameTo(freeFile("Monde 1"));
    }
    private File freeFile(String base) {
        File f = new File(worldsDir(), base + ".dat"); int n = 2;
        while (f.exists()) f = new File(worldsDir(), base + " (" + n++ + ").dat");
        return f;
    }
    private static String sanitize(String s) {
        s = s.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
        if (s.length() > 40) s = s.substring(0, 40);
        return s.isEmpty() ? "Nouveau monde" : s;
    }
    private static long parseSeed(String t) {
        t = t.trim(); if (t.isEmpty()) return System.nanoTime();
        try { return Long.parseLong(t); } catch (NumberFormatException e) { return t.hashCode(); }
    }

    // =====================================================================
    //  Style « Minecraft »
    // =====================================================================
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams wide() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(300), dp(44)); p.topMargin = dp(3); p.bottomMargin = dp(3); return p; }
    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(12), dp(10), dp(12), dp(10)); return c;
    }
    private TextView text(String s, int sp, int color, boolean shadow) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (shadow) { t.setShadowLayer(1, 2, 2, 0xFF3F3F3F); t.setTypeface(Typeface.DEFAULT_BOLD); }
        t.setPadding(0, dp(3), 0, dp(3)); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF888888);
        e.setInputType(InputType.TYPE_CLASS_TEXT); e.setPadding(dp(10), dp(8), dp(10), dp(8));
        GradientDrawable d = new GradientDrawable(); d.setColor(0xFF1E1E1E); d.setStroke(dp(2), 0xFFA0A0A0); e.setBackground(d); return e;
    }
    private GradientDrawable box(int fill) { GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setStroke(dp(2), 0xFF111111); return d; }
    /** Bouton gris Minecraft ; vert (principal) ou vert clair quand on appuie. */
    private TextView mcButton(String label, boolean green, Runnable action) {
        TextView b = new TextView(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER); b.setShadowLayer(1, 2, 2, 0xFF3F3F3F); b.setPadding(dp(8), 0, dp(8), 0);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[]{android.R.attr.state_pressed}, box(green ? 0xFF6FCB4A : 0xFF4F7FB8));
        sl.addState(new int[]{}, box(green ? 0xFF3C8527 : 0xFF707070));
        b.setBackground(sl); b.setClickable(true); b.setOnClickListener(v -> action.run()); return b;
    }
    /** Fond : texture de terre en pixels nets, assombrie (comme les menus Minecraft). */
    private FrameLayout background() {
        FrameLayout f = new FrameLayout(this);
        try (InputStream in = getAssets().open("atlas.png")) {
            Bitmap atlas = BitmapFactory.decodeStream(in);
            Bitmap tile = Bitmap.createScaledBitmap(Bitmap.createBitmap(atlas, 32, 0, 16, 16), dp(64), dp(64), false);
            BitmapDrawable d = new BitmapDrawable(getResources(), tile);
            d.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT); d.setFilterBitmap(false);
            d.setColorFilter(0xFF606060, PorterDuff.Mode.MULTIPLY);
            f.setBackground(d);
        } catch (Exception e) { f.setBackgroundColor(0xFF3A2A1A); }
        return f;
    }

    @Override public void onBackPressed() {
        if (onBack != null) onBack.run();
        else if (inGame) showPause();
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); if (inGame && game != null) { game.renderer.saveWorld(); game.onPause(); } }
    @Override protected void onResume() { super.onResume(); if (inGame && game != null) game.onResume(); }

    static class GameSurface extends GLSurfaceView {
        final WorldRenderer renderer;
        GameSurface(Activity c, int renderDist) { super(c); setEGLContextClientVersion(2); renderer = new WorldRenderer(c, renderDist); setRenderer(renderer); setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY); }
    }
}
