package fr.ractex.bedrockjava;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.IntConsumer;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String VERSION = "0.7.2";
    private static final String[] SPLASH = {"Pixels nets !", "Monde infini !", "Même seed, même monde !", "100% Java !", "Creuse, creuse !", "Fait sur téléphone !", "Un chunk à la fois !"};

    private FrameLayout root, gameLayer;
    private View menuLayer;
    private Runnable onBack;
    private GameSurface game;
    private TextView hud;
    private final ImageView[] hotItems = new ImageView[9];
    private ImageView hotSel;
    private GuiTex tex;
    private int px1, hotGs = 3;
    private final int[] hotbarIds = {World.GRASS, World.DIRT, World.STONE, World.WOOD, World.LEAVES, 0, 0, 0, 0};
    private final boolean[] dirs = new boolean[4]; // avant, arrière, gauche, droite
    private final Map<Integer, Bitmap> iconCache = new HashMap<>();
    private Bitmap atlasBmp;
    private TextView itemName;
    private int selected = 0;
    private float lastX, lastY;
    private boolean rotating, inGame;
    private File currentFile;
    private String currentName;
    private SharedPreferences prefs;
    private final Runnable hudTick = new Runnable() {
        @Override public void run() {
            if (!inGame || game == null || hud == null) return;
            hud.setText("Ractex Bedrock Java " + VERSION + "\n" + currentName + "  ·  Seed " + game.renderer.getSeed() + "\n"
                + String.format(Locale.US, "XYZ  %.1f / %.1f / %.1f", game.renderer.getPlayerX(), game.renderer.getPlayerY(), game.renderer.getPlayerZ()));
            hud.postDelayed(this, 250);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs = getSharedPreferences("ractex", MODE_PRIVATE);
        tex = new GuiTex(this);
        px1 = Math.max(2, Math.round(getResources().getDisplayMetrics().density * 2f)); // 1 pixel de texture = ~2 dp
        root = new FrameLayout(this);
        setContentView(root);
        migrateLegacySave();
        showTitle();
    }

    // =====================================================================
    //  Menus
    // =====================================================================
    private void setMenu(View v, Runnable back) {
        if (menuLayer != null) root.removeView(menuLayer);
        menuLayer = v; onBack = back;
        if (v != null) { v.setClickable(true); root.addView(v, new FrameLayout.LayoutParams(-1, -1)); }
    }

    /** Écran titre : logo, phrase jaune, Jouer / Paramètres / Quitter. */
    private void showTitle() {
        LinearLayout col = column();
        col.setGravity(Gravity.CENTER);
        TextView logo = text("RACTEX", 46, 0xFFE8E8E8, true);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); logo.setLetterSpacing(.12f);
        logo.setShadowLayer(dp(2), dp(3), dp(3), 0xFF2A2A2A);
        TextView sub = text("BEDROCK JAVA EDITION", 15, 0xFFBDBDBD, true);
        sub.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); sub.setLetterSpacing(.2f);
        TextView splash = text(SPLASH[new Random().nextInt(SPLASH.length)], 15, 0xFFFFFF55, true);
        splash.setRotation(-6f); splash.setShadowLayer(1, 2, 2, 0xFF3F3F00);
        col.addView(logo); col.addView(sub);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2); sp.topMargin = dp(8); sp.bottomMargin = dp(14);
        col.addView(splash, sp);
        col.addView(mcButton("Jouer", true, this::showWorlds), wide());
        col.addView(mcButton("Paramètres", false, () -> showSettings(this::showTitle)), wide());
        col.addView(mcButton("Quitter le jeu", false, this::finish), wide());
        FrameLayout f = background();
        f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        TextView v = text("Ractex " + VERSION, 11, 0xFFFFFFFF, false);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT); vp.leftMargin = dp(10); vp.bottomMargin = dp(6);
        f.addView(v, vp);
        setMenu(f, this::finish);
    }

    /** Liste des mondes + création. */
    private void showWorlds() {
        LinearLayout col = column();
        col.addView(text("Jouer", 22, Color.WHITE, true));
        col.addView(mcButton("Créer un nouveau monde", true, this::showCreate), wide());
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setGravity(Gravity.CENTER_HORIZONTAL);
        ScrollView sv = new ScrollView(this); sv.addView(list, new ScrollView.LayoutParams(-1, -2));
        File[] files = worldsDir().listFiles((d, n) -> n.endsWith(".dat"));
        if (files == null) files = new File[0];
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE);
        int shown = 0;
        for (File f : files) {
            Long seed = World.peekSeed(f);
            if (seed == null) continue;
            final String name = f.getName().substring(0, f.getName().length() - 4);
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView b = mcButton(name + "\nSeed : " + seed + "  ·  " + fmt.format(new Date(f.lastModified())), false, () -> startGame(f, name));
            b.setTextSize(14);
            row.addView(b, new LinearLayout.LayoutParams(dp(300), dp(56)));
            TextView x = mcButton("✕", false, () -> confirmDelete(f, name));
            LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(46), dp(56)); xp.leftMargin = dp(6);
            row.addView(x, xp);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2); rp.topMargin = dp(3); rp.bottomMargin = dp(3);
            list.addView(row, rp); shown++;
        }
        if (shown == 0) { TextView e = text("Aucun monde pour l'instant. Crées-en un !", 14, 0xFFDDDDDD, true); e.setPadding(0, dp(20), 0, 0); list.addView(e); }
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        col.addView(mcButton("Retour", false, this::showTitle), wide());
        FrameLayout f = background(); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showTitle);
    }

    private void confirmDelete(File f, String name) {
        new AlertDialog.Builder(this).setTitle("Supprimer « " + name + " » ?").setMessage("Ce monde sera définitivement effacé.")
            .setPositiveButton("Supprimer", (d, w) -> { f.delete(); showWorlds(); }).setNegativeButton("Annuler", null).show();
    }

    /** Création d'un monde : nom + seed. */
    private void showCreate() {
        LinearLayout col = column();
        col.addView(text("Créer un nouveau monde", 22, Color.WHITE, true));
        col.addView(text("Nom du monde", 13, 0xFFCCCCCC, false));
        final EditText name = field("Nouveau monde"); name.setText("Nouveau monde");
        col.addView(name, new LinearLayout.LayoutParams(dp(300), -2));
        col.addView(text("Seed (vide = aléatoire, nombre ou texte)", 13, 0xFFCCCCCC, false));
        final EditText seed = field("Aléatoire");
        col.addView(seed, new LinearLayout.LayoutParams(dp(300), -2));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(10)); col.addView(new View(this), gap);
        col.addView(mcButton("Créer le monde", true, () -> {
            String n = sanitize(name.getText().toString());
            File f = freeFile(n); String finalName = f.getName().substring(0, f.getName().length() - 4);
            try { new World(parseSeed(seed.getText().toString())).save(f, 8.5f, Float.NaN, 8.5f); }
            catch (Exception e) { Toast.makeText(this, "Impossible de créer le monde", Toast.LENGTH_SHORT).show(); return; }
            startGame(f, finalName);
        }), wide());
        col.addView(mcButton("Annuler", false, this::showWorlds), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showWorlds);
    }

    /** Paramètres : distance d'affichage et sensibilité. */
    private void showSettings(Runnable back) {
        LinearLayout col = column();
        col.addView(text("Paramètres", 22, Color.WHITE, true));
        addSlider(col, "Distance d'affichage", "dist", 2, 8, 5, " chunks");
        col.addView(text("Appliquée à l'entrée dans un monde. Plus haut = plus beau mais plus lent.", 11, 0xFFBBBBBB, false));
        addSlider(col, "Sensibilité de la caméra", "sens", 1, 12, 6, "");
        addSlider(col, "Vitesse de marche", "speed", 1, 10, 4, "");
        final TextView[] tg = new TextView[1];
        tg[0] = mcButton(barsLabel(), false, () -> { prefs.edit().putBoolean("bars", !prefs.getBoolean("bars", true)).apply(); tg[0].setText(barsLabel()); });
        col.addView(tg[0], wide());
        col.addView(text("Les barres de vie et de faim sont purement visuelles pour l'instant.", 11, 0xFFBBBBBB, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(12)); col.addView(new View(this), gap);
        col.addView(mcButton("Terminé", true, back), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, back);
    }

    private String barsLabel() { return "Barres vie / faim : " + (prefs.getBoolean("bars", true) ? "OUI" : "NON"); }
    private void addSlider(LinearLayout col, String label, String key, int min, int max, int def, String unit) {
        McSlider sl = new McSlider(this, tex, px1, label, unit, min, max, prefs.getInt(key, def), v -> prefs.edit().putInt(key, v).apply());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(300), 20 * px1); p.topMargin = dp(8);
        col.addView(sl, p);
    }

    /** Menu pause en jeu. */
    private void showPause() {
        game.renderer.setMovement(0, 0); Arrays.fill(dirs, false);
        LinearLayout col = column(); col.setGravity(Gravity.CENTER);
        col.addView(text("Jeu en pause", 22, Color.WHITE, true));
        col.addView(text(currentName + "  ·  Seed : " + game.renderer.getSeed(), 13, 0xFFDDDDDD, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(10)); col.addView(new View(this), gap);
        col.addView(mcButton("Reprendre", true, this::resume), wide());
        col.addView(mcButton("Sauvegarder", false, () -> Toast.makeText(this, game.renderer.saveWorld() ? "Monde sauvegardé" : "Erreur de sauvegarde", Toast.LENGTH_SHORT).show()), wide());
        col.addView(mcButton("Paramètres", false, () -> showSettings(this::showPause)), wide());
        col.addView(mcButton("Sauvegarder et quitter", false, this::exitToTitle), wide());
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(0xB8000000); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::resume);
    }
    private void resume() { setMenu(null, null); if (game != null) applySettings(); }
    private void applySettings() { game.renderer.setMoveSpeed(prefs.getInt("speed", 4) * .018f); }

    // =====================================================================
    //  Jeu
    // =====================================================================
    private void startGame(File file, String name) {
        currentFile = file; currentName = name;
        setMenu(null, null);
        gameLayer = buildGame(file, name);
        root.addView(gameLayer, 0, new FrameLayout.LayoutParams(-1, -1));
        inGame = true;
        applySettings();
        hud.removeCallbacks(hudTick); hud.post(hudTick);
    }
    private void exitToTitle() {
        if (inGame) {
            hud.removeCallbacks(hudTick);
            game.renderer.saveWorld(); game.onPause();
            root.removeView(gameLayer); gameLayer = null; game = null; inGame = false;
        }
        showTitle();
    }

    private FrameLayout buildGame(File file, String name) {
        FrameLayout g = new FrameLayout(this);
        game = new GameSurface(this, prefs.getInt("dist", 5));
        g.addView(game, new FrameLayout.LayoutParams(-1, -1));
        game.renderer.setSaveFile(file);
        Arrays.fill(dirs, false);
        loadHotbar();

        // Viseur du pack
        ImageView cross = new ImageView(this); cross.setImageDrawable(GuiTex.crisp(this, tex.scaled("crosshair", px1)));
        g.addView(cross, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));

        // Infos en haut à gauche
        hud = label("", 11); hud.setPadding(dp(8), dp(4), dp(8), dp(4)); hud.setBackgroundColor(0x66000000); hud.setShadowLayer(1, 1, 1, 0xFF000000);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT); hp.leftMargin = dp(6); hp.topMargin = dp(6);
        g.addView(hud, hp);

        // Croix directionnelle (gauche) : on peut combiner deux directions (diagonales)
        int s = dp(52), gap = dp(4), L = dp(16), B = dp(14);
        addPad(g, "▲", L + s + gap, B + 2 * (s + gap), s, 0);
        addPad(g, "▼", L + s + gap, B, s, 1);
        addPad(g, "◀", L, B + s + gap, s, 2);
        addPad(g, "▶", L + 2 * (s + gap), B + s + gap, s, 3);

        // Actions (droite)
        int bw = dp(62), bh = dp(52), R = dp(16);
        addAction(g, "POSER", 12, Gravity.BOTTOM | Gravity.RIGHT, R, B, bw, bh, () -> game.renderer.placeBlock());
        addAction(g, "CASSER", 12, Gravity.BOTTOM | Gravity.RIGHT, R + bw + gap, B, bw, bh, () -> game.renderer.breakBlock());
        addAction(g, "SAUT", 13, Gravity.BOTTOM | Gravity.RIGHT, R + (bw + gap) / 2, B + bh + gap, bw, bh, () -> game.renderer.jump());

        // Sac et menu (haut droite)
        addAction(g, "MENU", 12, Gravity.TOP | Gravity.RIGHT, dp(6), dp(6), dp(64), dp(34), () -> showPause());
        addAction(g, "SAC", 12, Gravity.TOP | Gravity.RIGHT, dp(6) + dp(64) + gap, dp(6), dp(64), dp(34), () -> showInventory());

        // Barre d'objets, cœurs et faim : textures du pack, agrandies d'un facteur entier (pixels nets)
        int screenW = getResources().getDisplayMetrics().widthPixels;
        final int gs = Math.max(1, Math.min(5, (screenW - 2 * dp(190)) / 182)); hotGs = gs;
        FrameLayout hb = new FrameLayout(this); hb.setClipChildren(false);
        if (prefs.getBoolean("bars", true)) {
            for (int i = 0; i < 10; i++) {
                addTex(hb, "heart_container", gs, i * 8 * gs, 0); addTex(hb, "heart_full", gs, i * 8 * gs, 0);
                addTex(hb, "food_empty", gs, (182 - 9 - i * 8) * gs, 0); addTex(hb, "food_full", gs, (182 - 9 - i * 8) * gs, 0);
            }
        }
        addTex(hb, "hotbar", gs, 0, 19 * gs);
        hotSel = addTex(hb, "hotbar_selection", gs, -gs, 18 * gs);
        for (int i = 0; i < 9; i++) {
            ImageView it = new ImageView(this); it.setScaleType(ImageView.ScaleType.FIT_XY);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(16 * gs, 16 * gs); ip.leftMargin = (3 + 20 * i) * gs; ip.topMargin = 22 * gs;
            hb.addView(it, ip); hotItems[i] = it;
        }
        hb.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN || e.getY() < 18f * gs) return false;
            selectSlot(Math.max(0, Math.min(8, (int) ((e.getX() / gs - 1f) / 20f)))); return true;
        });
        FrameLayout.LayoutParams hbp = new FrameLayout.LayoutParams(182 * gs, 41 * gs, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); hbp.bottomMargin = dp(6);
        g.addView(hb, hbp);

        // Nom de l'objet sélectionné (s'efface tout seul, comme dans Minecraft)
        itemName = label("", 14); itemName.setTypeface(Typeface.DEFAULT_BOLD); itemName.setShadowLayer(1, 2, 2, 0xFF000000); itemName.setAlpha(0f);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); np.bottomMargin = dp(6) + 41 * gs + dp(4);
        g.addView(itemName, np);

        selectSlot(selected);

        game.setOnTouchListener((v, e) -> {
            float x = e.getX(), y = e.getY(), k = prefs.getInt("sens", 6) / 6f;
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { lastX = x; lastY = y; rotating = x > v.getWidth() * .42f; return rotating; }
            if (a == MotionEvent.ACTION_MOVE && rotating) { game.renderer.rotate((x - lastX) * .006f * k, (y - lastY) * .004f * k); lastX = x; lastY = y; return true; }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { rotating = false; return true; }
            return rotating;
        });
        return g;
    }
    /** Ajoute une texture du pack (agrandie de k, pixels nets) à une position en pixels. */
    private ImageView addTex(FrameLayout parent, String name, int k, int x, int y) {
        ImageView iv = new ImageView(this); iv.setImageDrawable(GuiTex.crisp(this, tex.scaled(name, k)));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-2, -2); p.leftMargin = x; p.topMargin = y;
        parent.addView(iv, p); return iv;
    }

    // ---------- Barre d'objets ----------
    private void selectSlot(int i) {
        selected = i;
        game.renderer.selectBlock(hotbarIds[i]);
        refreshHotbar();
        if (itemName != null) {
            itemName.animate().cancel();
            itemName.setText(blockName(hotbarIds[i])); itemName.setAlpha(hotbarIds[i] == 0 ? 0f : 1f);
            itemName.animate().alpha(0f).setStartDelay(1200).setDuration(500).start();
        }
    }
    private void refreshHotbar() {
        if (hotSel != null) hotSel.setTranslationX(20f * selected * hotGs);
        for (int i = 0; i < 9; i++) {
            if (hotItems[i] == null) continue;
            int id = hotbarIds[i];
            hotItems[i].setImageBitmap(id == 0 ? null : icon(id, 16 * hotGs));
        }
    }
    private void saveHotbar() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 9; i++) sb.append(i == 0 ? "" : ",").append(hotbarIds[i]);
        prefs.edit().putString("hotbar", sb.toString()).apply();
    }
    private void loadHotbar() {
        String t = prefs.getString("hotbar", null); if (t == null) return;
        try {
            String[] p = t.split(",");
            int[] tmp = new int[9];
            for (int i = 0; i < 9; i++) { tmp[i] = Integer.parseInt(p[i].trim()); if (tmp[i] < 0 || tmp[i] > World.LEAVES) tmp[i] = 0; }
            System.arraycopy(tmp, 0, hotbarIds, 0, 9);
        } catch (Exception ignored) {}
    }
    private static String blockName(int id) {
        switch (id) {
            case World.GRASS: return "Herbe"; case World.DIRT: return "Terre"; case World.STONE: return "Pierre";
            case World.WOOD: return "Bois"; case World.LEAVES: return "Feuilles"; default: return "";
        }
    }

    // ---------- Inventaire : écran « inventory.png » du pack ----------
    private void showInventory() {
        if (game != null) game.renderer.setMovement(0, 0);
        Arrays.fill(dirs, false);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        final int k = Math.max(1, Math.min(6, Math.min((int) (dm.heightPixels * .76f / 166), (int) (dm.widthPixels * .9f / 176))));

        FrameLayout panel = new FrameLayout(this); panel.setClickable(true); panel.setClipChildren(false);
        panel.setBackground(GuiTex.crisp(this, tex.region("inventory", 0, 0, 176, 166, k)));

        TextView title = pxText("Inventaire", 8 * k, 0xFF404040); place(panel, title, 97, 7, 72, 10, k);
        TextView hint = pxText("Touche un bloc, puis une case. ✕ vide la case.", 6 * k, 0xFF505050); hint.setGravity(Gravity.TOP | Gravity.LEFT); place(panel, hint, 97, 20, 72, 40, k);

        // Aperçu du bloc de la case sélectionnée (à la place du personnage)
        int cur = hotbarIds[selected];
        if (cur != 0) {
            ImageView big = new ImageView(this); big.setScaleType(ImageView.ScaleType.FIT_XY); big.setImageBitmap(icon(cur, 32 * k));
            place(panel, big, 34, 16, 32, 32, k);
            TextView nm = pxText(blockName(cur), 8 * k, Color.WHITE); nm.setShadowLayer(1, k, k, 0xFF3F3F3F); nm.setGravity(Gravity.CENTER); place(panel, nm, 26, 56, 49, 10, k);
        }

        // Palette de blocs dans la 1re ligne du sac : 5 blocs + corbeille
        final int[] pal = {World.GRASS, World.DIRT, World.STONE, World.WOOD, World.LEAVES};
        for (int c = 0; c < 9; c++) {
            final int col = c;
            FrameLayout slot = slotView(c < pal.length ? pal[c] : 0, k, c == 8);
            slot.setOnClickListener(v -> {
                if (col < pal.length) hotbarIds[selected] = pal[col]; else if (col == 8) hotbarIds[selected] = 0; else return;
                saveHotbar(); selectSlot(selected); showInventory();
            });
            place(panel, slot, 7 + 18 * c, 83, 18, 18, k);
        }
        // Barre d'objets
        for (int c = 0; c < 9; c++) {
            final int idx = c;
            FrameLayout slot = slotView(hotbarIds[c], k, false);
            slot.setOnClickListener(v -> { selectSlot(idx); showInventory(); });
            place(panel, slot, 7 + 18 * c, 141, 18, 18, k);
        }
        ImageView sel = new ImageView(this); sel.setImageDrawable(GuiTex.crisp(this, tex.scaled("hotbar_selection", k)));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2); sp.leftMargin = (7 + 18 * selected - 3) * k; sp.topMargin = (141 - 3) * k;
        panel.addView(sel, sp);

        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(panel, new LinearLayout.LayoutParams(176 * k, 166 * k));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(200), 20 * px1); cp.topMargin = dp(6);
        col.addView(mcButton("Fermer", true, this::resume), cp);

        FrameLayout overlay = new FrameLayout(this); overlay.setBackgroundColor(0xB8000000);
        overlay.setOnClickListener(v -> resume());
        overlay.addView(col, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setMenu(overlay, this::resume);
    }
    /** Case cliquable de 18x18 pixels de texture ; id 0 = vide, trash = croix rouge. */
    private FrameLayout slotView(int id, int k, boolean trash) {
        FrameLayout f = new FrameLayout(this); f.setClickable(true);
        if (id != 0) {
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.FIT_XY); iv.setImageBitmap(icon(id, 16 * k));
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(16 * k, 16 * k); p.leftMargin = k; p.topMargin = k; f.addView(iv, p);
        } else if (trash) {
            TextView x = new TextView(this); x.setText("✕"); x.setTextColor(0xFF8A1F1F); x.setGravity(Gravity.CENTER); x.setTextSize(TypedValue.COMPLEX_UNIT_PX, 12 * k);
            f.addView(x, new FrameLayout.LayoutParams(-1, -1));
        }
        return f;
    }
    private TextView pxText(String s, int px, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px); t.setIncludeFontPadding(false); return t;
    }
    /** Place une vue à une position/taille exprimées en pixels de texture (x k). */
    private static void place(FrameLayout parent, View v, int x, int y, int w, int h, int k) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w * k, h * k); p.leftMargin = x * k; p.topMargin = y * k; parent.addView(v, p);
    }

    // ---------- Icônes de blocs : petit cube isométrique dessiné à partir de l'atlas ----------
    private Bitmap atlas() {
        if (atlasBmp == null) {
            try (InputStream in = getAssets().open("atlas.png")) {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inScaled = false;
                atlasBmp = BitmapFactory.decodeStream(in, null, o);
            } catch (Exception e) { atlasBmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888); }
        }
        return atlasBmp;
    }
    private Bitmap tileBmp(int t) { return Bitmap.createBitmap(atlas(), (t % 4) * 16, (t / 4) * 16, 16, 16); }
    private Bitmap icon(int id, int px) {
        int key = id * 10000 + px; Bitmap cached = iconCache.get(key); if (cached != null) return cached;
        int top, side;
        switch (id) {
            case World.GRASS: top = 0; side = 1; break;
            case World.DIRT: top = 2; side = 2; break;
            case World.STONE: top = 3; side = 3; break;
            case World.WOOD: top = 5; side = 4; break;
            default: top = 6; side = 6; break;
        }
        Bitmap out = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888); Canvas c = new Canvas(out);
        Bitmap tt = tileBmp(top), ts = tileBmp(side);
        float[] src = {0, 0, 16, 0, 16, 16, 0, 16};
        quad(c, tt, src, new float[]{16, 2, 30, 9, 16, 16, 2, 9}, 0xFFFFFFFF);
        quad(c, ts, src, new float[]{2, 9, 16, 16, 16, 30, 2, 23}, 0xFFCCCCCC);
        quad(c, ts, src, new float[]{16, 16, 30, 9, 30, 23, 16, 30}, 0xFF999999);
        Bitmap scaled = Bitmap.createScaledBitmap(out, px, px, false);
        iconCache.put(key, scaled); return scaled;
    }
    private static void quad(Canvas c, Bitmap bmp, float[] src, float[] dst, int shade) {
        Matrix m = new Matrix(); m.setPolyToPoly(src, 0, dst, 0, 4);
        Paint p = new Paint(); p.setFilterBitmap(false); p.setAntiAlias(false); p.setColorFilter(new PorterDuffColorFilter(shade, PorterDuff.Mode.MULTIPLY));
        c.drawBitmap(bmp, m, p);
    }

    // ---------- Boutons tactiles ----------
    private void addPad(FrameLayout parent, String glyph, int left, int bottom, int size, final int dir) {
        final TextView b = ctrl(glyph, 22);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(size, size, Gravity.BOTTOM | Gravity.LEFT);
        p.leftMargin = left; p.bottomMargin = bottom; parent.addView(b, p);
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { v.setPressed(true); setDir(dir, true); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { v.setPressed(false); setDir(dir, false); }
            return true;
        });
    }
    private void setDir(int i, boolean on) {
        dirs[i] = on;
        if (game != null) game.renderer.setMovement((dirs[0] ? 1 : 0) - (dirs[1] ? 1 : 0), (dirs[3] ? 1 : 0) - (dirs[2] ? 1 : 0));
    }
    private void addAction(FrameLayout parent, String s, int sp, int gravity, int x, int y, int w, int h, Runnable action) {
        TextView b = ctrl(s, sp); FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, h, gravity);
        if ((gravity & Gravity.RIGHT) == Gravity.RIGHT) p.rightMargin = x;
        if ((gravity & Gravity.TOP) == Gravity.TOP) p.topMargin = y; else p.bottomMargin = y;
        parent.addView(b, p); b.setOnClickListener(v -> action.run());
    }
    /** Bouton tactile : texture « button » du pack, légèrement translucide, verte quand on appuie. */
    private TextView ctrl(String s, int sp) {
        TextView t = label(s, sp); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER); t.setShadowLayer(1, 2, 2, 0xFF3F3F3F);
        Drawable d = tex.button(px1); d.setAlpha(215);
        t.setBackground(d); t.setClickable(true); return t;
    }
    private TextView label(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); return t; }

    /** Curseur de réglage Minecraft (textures slider + slider_handle). */
    static class McSlider extends View {
        private final GuiTex tex; private final int px, min, max; private final String label, unit; private final IntConsumer cb;
        private final Drawable track; private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG), crisp = new Paint();
        private int value; private boolean drag;
        McSlider(Activity c, GuiTex tex, int px, String label, String unit, int min, int max, int value, IntConsumer cb) {
            super(c); this.tex = tex; this.px = px; this.label = label; this.unit = unit; this.min = min; this.max = max; this.value = value; this.cb = cb;
            track = tex.nine("slider", 1, px); crisp.setFilterBitmap(false);
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextSize(15f * c.getResources().getDisplayMetrics().scaledDensity); text.setShadowLayer(1, 2, 2, 0xFF3F3F3F);
            setClickable(true);
        }
        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight(), hw = 8 * px;
            track.setBounds(0, 0, w, h); track.draw(c);
            float x = (w - hw) * (value - min) / (float) Math.max(1, max - min);
            c.drawBitmap(tex.get(drag ? "slider_handle_highlighted" : "slider_handle"), null, new RectF(x, 0, x + hw, h), crisp);
            c.drawText(label + " : " + value + unit, w / 2f, h / 2f - (text.ascent() + text.descent()) / 2f, text);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked(), hw = 8 * px;
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                drag = true; if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                float f = Math.max(0f, Math.min(1f, (e.getX() - hw / 2f) / Math.max(1f, getWidth() - hw)));
                int v = min + Math.round(f * (max - min));
                if (v != value) { value = v; cb.accept(v); }
                invalidate(); return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { drag = false; invalidate(); return true; }
            return super.onTouchEvent(e);
        }
    }

    // =====================================================================
    //  Mondes (fichiers)
    // =====================================================================
    private File worldsDir() { File d = new File(getFilesDir(), "worlds"); d.mkdirs(); return d; }
    private void migrateLegacySave() {
        File old = new File(getFilesDir(), "ractex_world.dat");
        if (old.exists() && World.peekSeed(old) != null) old.renameTo(freeFile("Monde 1"));
    }
    private File freeFile(String base) {
        File f = new File(worldsDir(), base + ".dat"); int n = 2;
        while (f.exists()) f = new File(worldsDir(), base + " (" + n++ + ").dat");
        return f;
    }
    private static String sanitize(String s) {
        s = s.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
        if (s.length() > 40) s = s.substring(0, 40);
        return s.isEmpty() ? "Nouveau monde" : s;
    }
    private static long parseSeed(String t) {
        t = t.trim(); if (t.isEmpty()) return System.nanoTime();
        try { return Long.parseLong(t); } catch (NumberFormatException e) { return t.hashCode(); }
    }

    // =====================================================================
    //  Style « Minecraft »
    // =====================================================================
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams wide() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(300), 20 * px1); p.topMargin = dp(3); p.bottomMargin = dp(3); return p; }
    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(12), dp(10), dp(12), dp(10)); return c;
    }
    private TextView text(String s, int sp, int color, boolean shadow) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (shadow) { t.setShadowLayer(1, 2, 2, 0xFF3F3F3F); t.setTypeface(Typeface.DEFAULT_BOLD); }
        t.setPadding(0, dp(3), 0, dp(3)); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF888888);
        e.setInputType(InputType.TYPE_CLASS_TEXT); e.setPadding(dp(10), dp(8), dp(10), dp(8));
        e.setBackground(tex.nine("text_field", 1, px1)); return e;
    }
    /** Bouton Minecraft du pack de textures : gris, vert quand on appuie. */
    private TextView mcButton(String label, boolean primary, Runnable action) {
        TextView b = new TextView(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER); b.setShadowLayer(1, 2, 2, 0xFF3F3F3F); b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(tex.button(px1)); b.setClickable(true); b.setOnClickListener(v -> action.run()); return b;
    }
    /** Fond : texture de terre en pixels nets, assombrie (comme les menus Minecraft). */
    private FrameLayout background() {
        FrameLayout f = new FrameLayout(this);
        try (InputStream in = getAssets().open("atlas.png")) {
            Bitmap atlas = BitmapFactory.decodeStream(in);
            Bitmap tile = Bitmap.createScaledBitmap(Bitmap.createBitmap(atlas, 32, 0, 16, 16), dp(64), dp(64), false);
            BitmapDrawable d = new BitmapDrawable(getResources(), tile);
            d.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT); d.setFilterBitmap(false);
            d.setColorFilter(0xFF606060, PorterDuff.Mode.MULTIPLY);
            f.setBackground(d);
        } catch (Exception e) { f.setBackgroundColor(0xFF3A2A1A); }
        return f;
    }

    @Override public void onBackPressed() {
        if (onBack != null) onBack.run();
        else if (inGame) showPause();
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); if (inGame && game != null) { Arrays.fill(dirs, false); game.renderer.setMovement(0, 0); game.renderer.saveWorld(); game.onPause(); } }
    @Override protected void onResume() { super.onResume(); if (inGame && game != null) game.onResume(); }

    static class GameSurface extends GLSurfaceView {
        final WorldRenderer renderer;
        GameSurface(Activity c, int renderDist) { super(c); setEGLContextClientVersion(2); renderer = new WorldRenderer(c, renderDist); setRenderer(renderer); setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY); }
    }
}
