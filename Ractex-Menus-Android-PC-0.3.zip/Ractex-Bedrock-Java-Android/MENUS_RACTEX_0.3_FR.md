# Ractex 0.3 — menus Android et PC

## Android
L’accueil ajoute les accès Profil et Social. Le profil ouvre la gestion des skins et les statistiques (écran indicatif). Le panneau Social donne accès aux salons et au code d’invitation. Les menus Jouer, Multijoueur et Paramètres existants sont conservés.

## PC
L’application de bureau dispose maintenant d’un accueil cliquable : Jouer, Social, Profil, Paramètres et Quitter. Échap ouvre le menu pause en jeu. Les réglages PC incluent des interrupteurs d’affichage pour les nuages, la lumière douce et le compteur FPS. Les boutons Serveurs, statistiques détaillées et fonctions sociales affichent encore des états indicatifs : leurs services ne sont pas implémentés par cette interface.

## Limites
Cette version ajoute les écrans et leur navigation ; elle ne reproduit pas encore toutes les fonctions Minecraft Bedrock (Realms, compte Microsoft, invitations réseau, vestiaire complet, succès synchronisés). La compilation Android/Windows doit être lancée sur les environnements de build.
