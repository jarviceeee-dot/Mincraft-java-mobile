# Ractex PC — portage 0.1

Cette version PC réutilise directement les classes Java `World`, `Chunk`, `Block`, `Items` et `Inventory` extraites du projet Android 0.14. Le générateur de terrain et le format de sauvegarde `World.save/load` sont donc ceux du projet mobile.

## Lancer sous Windows
- Installer un JDK 17.
- Ouvrir un terminal dans `desktop`.
- Lancer `gradle run` (Gradle 8+).

## Contrôles de cette première base
- ZQSD ou WASD : déplacement horizontal.
- Souris : regarder autour.
- Espace / Maj gauche : monter / descendre provisoirement.
- Échap : libérer/reprendre la souris.
- F5 : sauvegarder.

## État réel
C'est une première base de portage, pas encore l'équivalent complet de l'application mobile. Le rendu PC affiche le terrain issu du même générateur, mais les textures/atlas, le système complet de blocs placés et minés, les menus tactiles adaptés à la souris, l'inventaire interactif, les mods Android et le multijoueur ne sont pas encore portés. Les ressources originales restent dans le projet Android à côté de ce module.


## Améliorations PC 0.2
- Cache du terrain par zone avec listes d'affichage OpenGL : évite de recalculer toutes les hauteurs à chaque image.
- Shader GLSL 1.20 pour une lumière douce et un brouillard de distance.
- Ciel bleu et nuages blancs animés à faible coût de rendu.
- Le workflow Windows détecte maintenant le projet PC déjà extrait **ou** dans une archive ZIP du dépôt : il ne dépend plus du nom `Ractex-PC*.zip`.

Ces améliorations concernent le rendu PC de cette base. Elles ne signifient pas que tous les menus, textures, blocs interactifs ou fonctions mobiles sont déjà portés.
