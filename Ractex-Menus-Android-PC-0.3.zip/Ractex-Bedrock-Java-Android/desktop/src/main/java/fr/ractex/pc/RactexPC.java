package fr.ractex.pc;

import fr.ractex.bedrockjava.World;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;
import java.util.Random;

/** Ractex PC: écran d'accueil et menus natifs au style Bedrock, puis monde partagé. */
public final class RactexPC {
    private long window;
    private final World world = new World(new Random().nextLong());
    private double px=8, py=32, pz=8, yaw=0, pitch=-0.25, lastX,lastY;
    private boolean mouseCaptured=false, firstMouse=true, inGame=false;
    private boolean clouds=true, softLight=true, showFps=true;
    private String screen="HOME";
    private String notice="Bienvenue dans Ractex";
    private double fps=0; private long fpsStart=System.nanoTime(); private int frames=0;
    private RactexPC() {}
    public static void main(String[] args) { new RactexPC().run(); }

    private void run() {
        if (!GLFW.glfwInit()) throw new IllegalStateException("Impossible d'initialiser GLFW");
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR,2);
        GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR,1);
        window=GLFW.glfwCreateWindow(1280,720,"Ractex — PC",MemoryUtil.NULL,MemoryUtil.NULL);
        if(window==MemoryUtil.NULL) throw new RuntimeException("Fenêtre Ractex impossible à créer");
        GLFW.glfwMakeContextCurrent(window); GLFW.glfwSwapInterval(1); GL.createCapabilities();
        GLFW.glfwSetInputMode(window,GLFW.GLFW_CURSOR,GLFW.GLFW_CURSOR_NORMAL);
        GLFW.glfwSetCursorPosCallback(window,(w,x,y)->{
            if(firstMouse){lastX=x;lastY=y;firstMouse=false;}
            double dx=x-lastX,dy=y-lastY;lastX=x;lastY=y;
            if(mouseCaptured){yaw+=dx*0.0025;pitch=Math.max(-1.45,Math.min(1.45,pitch-dy*0.0025));}
        });
        GLFW.glfwSetMouseButtonCallback(window,(w,button,action,mods)->{
            if(button==GLFW.GLFW_MOUSE_BUTTON_LEFT && action==GLFW.GLFW_PRESS && !inGame){
                double[] x={0},y={0}; GLFW.glfwGetCursorPos(window,x,y); click(x[0],y[0]);
            }
        });
        GLFW.glfwSetKeyCallback(window,(w,key,sc,action,mods)->{
            if(action!=GLFW.GLFW_PRESS)return;
            if(key==GLFW.GLFW_KEY_ESCAPE){
                if(inGame){inGame=false;screen="PAUSE";mouseCaptured=false;GLFW.glfwSetInputMode(window,GLFW.GLFW_CURSOR,GLFW.GLFW_CURSOR_NORMAL);}
                else if(screen.equals("HOME")){screen="HOME";} else screen="HOME";
                firstMouse=true;
            }
            if(key==GLFW.GLFW_KEY_F5)save();
        });
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        while(!GLFW.glfwWindowShouldClose(window)){
            if(inGame)update(); render(); GLFW.glfwSwapBuffers(window); GLFW.glfwPollEvents();
            frames++; long now=System.nanoTime(); if(now-fpsStart>=1_000_000_000L){fps=frames*1e9/(now-fpsStart);frames=0;fpsStart=now;}
        }
        save(); GLFW.glfwDestroyWindow(window); GLFW.glfwTerminate();
    }

    private void click(double mx,double my){
        int[] ww={0},hh={0};GLFW.glfwGetWindowSize(window,ww,hh);double sx=ww[0]/1280.0,sy=hh[0]/720.0;double x=mx/sx,y=my/sy;
        if(screen.equals("HOME")){
            if(hit(x,y,450,250,380,58)){screen="PLAY";notice="Choisis un monde ou un serveur";}
            else if(hit(x,y,450,320,380,58)){screen="SOCIAL";}
            else if(hit(x,y,450,390,380,58)){screen="PROFILE";}
            else if(hit(x,y,450,460,380,58)){screen="SETTINGS";}
            else if(hit(x,y,450,530,380,48)){GLFW.glfwSetWindowShouldClose(window,true);}
        } else if(screen.equals("PLAY")){
            if(hit(x,y,350,260,580,58)){startGame();}
            else if(hit(x,y,350,335,580,58)){notice="Serveurs : ajoute bientôt l'adresse de ton serveur";}
            else if(hit(x,y,350,500,580,52)){screen="HOME";}
        } else if(screen.equals("SETTINGS")){
            if(hit(x,y,360,250,560,54)){clouds=!clouds;}
            else if(hit(x,y,360,320,560,54)){softLight=!softLight;}
            else if(hit(x,y,360,390,560,54)){showFps=!showFps;}
            else if(hit(x,y,360,500,560,52)){screen="HOME";}
        } else if(screen.equals("PROFILE")||screen.equals("SOCIAL")||screen.equals("PAUSE")){
            if(hit(x,y,360,500,560,52)){if(screen.equals("PAUSE")){screen="HOME";}else screen="HOME";}
            if(screen.equals("PAUSE")&&hit(x,y,360,420,560,52)){inGame=true;screen="GAME";mouseCaptured=true;GLFW.glfwSetInputMode(window,GLFW.GLFW_CURSOR,GLFW.GLFW_CURSOR_DISABLED);}
        }
    }
    private static boolean hit(double x,double y,double bx,double by,double bw,double bh){return x>=bx&&x<=bx+bw&&y>=by&&y<=by+bh;}
    private void startGame(){inGame=true;screen="GAME";mouseCaptured=true;firstMouse=true;GLFW.glfwSetInputMode(window,GLFW.GLFW_CURSOR,GLFW.GLFW_CURSOR_DISABLED);notice="Echap : pause | WASD : bouger | Espace : monter";}
    private void update(){
        double speed=0.12,fx=Math.sin(yaw),fz=-Math.cos(yaw),rx=Math.cos(yaw),rz=Math.sin(yaw);
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_W)==GLFW.GLFW_PRESS){px+=fx*speed;pz+=fz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_S)==GLFW.GLFW_PRESS){px-=fx*speed;pz-=fz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_A)==GLFW.GLFW_PRESS){px-=rx*speed;pz-=rz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_D)==GLFW.GLFW_PRESS){px+=rx*speed;pz+=rz*speed;}
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_SPACE)==GLFW.GLFW_PRESS)py+=speed;
        if(GLFW.glfwGetKey(window,GLFW.GLFW_KEY_LEFT_SHIFT)==GLFW.GLFW_PRESS)py-=speed;
        world.loadChunk((int)Math.floor(px)>>4,(int)Math.floor(pz)>>4);
    }
    private void render(){
        int[] ww={0},hh={0};GLFW.glfwGetFramebufferSize(window,ww,hh);int w=Math.max(1,ww[0]),h=Math.max(1,hh[0]);
        GL11.glViewport(0,0,w,h);GL11.glClearColor(0.48f,0.70f,0.94f,1);GL11.glClear(GL11.GL_COLOR_BUFFER_BIT|GL11.GL_DEPTH_BUFFER_BIT);
        if(inGame){renderWorld(w,h);if(showFps){begin2d(w,h);text("FPS "+(int)fps+"   XYZ "+(int)px+" / "+(int)py+" / "+(int)pz,18,24,2,0xFFFFFFFF);end2d();}}
        else {begin2d(w,h);drawMenu(w,h);end2d();}
    }
    private void renderWorld(int w,int h){
        GL11.glMatrixMode(GL11.GL_PROJECTION);GL11.glLoadIdentity();perspective(70,(float)w/h,.1f,180);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);GL11.glLoadIdentity();GL11.glRotatef((float)Math.toDegrees(pitch),1,0,0);GL11.glRotatef((float)Math.toDegrees(yaw),0,1,0);GL11.glTranslated(-px,-py,-pz);
        GL11.glBegin(GL11.GL_QUADS);int cx=(int)Math.floor(px),cz=(int)Math.floor(pz);
        for(int x=cx-24;x<=cx+24;x++)for(int z=cz-24;z<=cz+24;z++){
            int top=world.heightAt(x,z);float xf=x,zf=z;colorFor((byte)(top<=World.SAND_LEVEL?World.SAND:World.GRASS));
            GL11.glVertex3f(xf,top+1,zf);GL11.glVertex3f(xf+1,top+1,zf);GL11.glVertex3f(xf+1,top+1,zf+1);GL11.glVertex3f(xf,top+1,zf+1);
            int below=Math.max(0,top-3);colorFor(World.DIRT);if(top>below){GL11.glVertex3f(xf,below,zf);GL11.glVertex3f(xf+1,below,zf);GL11.glVertex3f(xf+1,top+1,zf);GL11.glVertex3f(xf,top+1,zf);}
        }GL11.glEnd();
    }
    private void drawMenu(int w,int h){
        rect(0,0,1280,720,0xFF25282B);rect(0,0,1280,66,0xFFE4E6E9);text("RACTEX",520,18,5,0xFF17191B);
        if(screen.equals("HOME")){
            text("BEDROCK JAVA EDITION",475,160,2,0xFFE0E0E0);text("TON MONDE. TES REGLES.",495,205,2,0xFFFFD45A);
            button("JOUER",450,250,380,58,true);button("SOCIAL",450,320,380,58,false);button("PROFIL",450,390,380,58,false);button("PARAMETRES",450,460,380,58,false);button("QUITTER",450,530,380,48,false);
            text("RACTEX PC  |  VERSION DE DEVELOPPEMENT",24,680,1,0xFFBFC3C7);
        }else if(screen.equals("PLAY")){
            title("JOUER",510);text("MONDES",390,180,2,0xFFFFFFFF);text("SERVEURS",730,180,2,0xFFFFFFFF);
            button("CREER / OUVRIR UN MONDE",350,260,580,58,true);button("REJOINDRE UN SERVEUR (BETA)",350,335,580,58,false);text(notice,350,430,1,0xFFD0D0D0);button("RETOUR",350,500,580,52,false);
        }else if(screen.equals("SETTINGS")){
            title("PARAMETRES",470);text("VIDEO ET ACCESSIBILITE",360,170,2,0xFFFFFFFF);
            button("NUAGES : "+(clouds?"ACTIVES":"DESACTIVES"),360,250,560,54,true);button("LUMIERE DOUCE : "+(softLight?"ACTIVE":"DESACTIVEE"),360,320,560,54,false);button("COMPTEUR FPS : "+(showFps?"ACTIVE":"DESACTIVE"),360,390,560,54,false);button("RETOUR",360,500,560,52,false);
        }else if(screen.equals("PROFILE")){
            title("VOTRE PROFIL",450);rect(90,150,330,430,0xFF414447);text("JOUEUR RACTEX",130,205,2,0xFFFFFFFF);text("STATISTIQUES",500,190,2,0xFFFFFFFF);text("Temps de jeu : bientot",500,250,1,0xFFD0D0D0);text("Skin : gestion a venir",500,300,1,0xFFD0D0D0);text("Succes : systeme a venir",500,350,1,0xFFD0D0D0);button("RETOUR",360,500,560,52,false);
        }else if(screen.equals("SOCIAL")){
            title("SOCIAL",530);text("AMIS ET INVITATIONS",390,190,2,0xFFFFFFFF);text("Le panneau social est pret a recevoir le service en ligne.",390,255,1,0xFFD0D0D0);text("Aucun ami connecte",390,310,1,0xFFB8E8A0);button("RETOUR",360,500,560,52,false);
        }else if(screen.equals("PAUSE")){
            title("PAUSE",555);button("REPRENDRE",360,420,560,52,true);button("MENU PRINCIPAL",360,500,560,52,false);
        }
    }
    private void title(String s,int x){text(s,x,115,3,0xFFFFFFFF);}
    private void button(String label,int x,int y,int bw,int bh,boolean primary){rect(x,y,bw,bh,0xFF17191B);rect(x+3,y+3,bw-6,bh-6,primary?0xFFBFC4C9:0xFF55595D);rect(x+5,y+5,bw-10,bh-10,primary?0xFF777D83:0xFF3B3F43);text(label,x+22,y+bh/2-7,1,0xFFFFFFFF);}
    private void begin2d(int w,int h){GL11.glDisable(GL11.GL_DEPTH_TEST);GL11.glMatrixMode(GL11.GL_PROJECTION);GL11.glLoadIdentity();GL11.glOrtho(0,1280,720,0,-1,1);GL11.glMatrixMode(GL11.GL_MODELVIEW);GL11.glLoadIdentity();}
    private void end2d(){GL11.glEnable(GL11.GL_DEPTH_TEST);}
    private void rect(float x,float y,float w,float h,int c){GL11.glColor4ub((byte)(c>>16),(byte)(c>>8),(byte)c,(byte)(c>>24));GL11.glBegin(GL11.GL_QUADS);GL11.glVertex2f(x,y);GL11.glVertex2f(x+w,y);GL11.glVertex2f(x+w,y+h);GL11.glVertex2f(x,y+h);GL11.glEnd();}
    private void text(String s,int x,int y,int scale,int color){GL11.glColor4ub((byte)(color>>16),(byte)(color>>8),(byte)color,(byte)(color>>24));int ox=x;for(char ch:s.toUpperCase().toCharArray()){if(ch=='\n'){y+=9*scale;x=ox;continue;}int[] rows=glyph(ch);for(int r=0;r<7;r++)for(int c=0;c<5;c++)if((rows[r]&(1<<(4-c)))!=0)rect(x+c*scale,y+r*scale,scale,scale,color);x+=6*scale;}}
    private int[] glyph(char c){String[] a=switch(c){case 'A'->new String[]{"01110","10001","10001","11111","10001","10001","10001"};case 'B'->new String[]{"11110","10001","10001","11110","10001","10001","11110"};case 'C'->new String[]{"01111","10000","10000","10000","10000","10000","01111"};case 'D'->new String[]{"11110","10001","10001","10001","10001","10001","11110"};case 'E'->new String[]{"11111","10000","10000","11110","10000","10000","11111"};case 'F'->new String[]{"11111","10000","10000","11110","10000","10000","10000"};case 'G'->new String[]{"01111","10000","10000","10111","10001","10001","01111"};case 'H'->new String[]{"10001","10001","10001","11111","10001","10001","10001"};case 'I'->new String[]{"11111","00100","00100","00100","00100","00100","11111"};case 'J'->new String[]{"00111","00010","00010","00010","10010","10010","01100"};case 'K'->new String[]{"10001","10010","10100","11000","10100","10010","10001"};case 'L'->new String[]{"10000","10000","10000","10000","10000","10000","11111"};case 'M'->new String[]{"10001","11011","10101","10101","10001","10001","10001"};case 'N'->new String[]{"10001","11001","10101","10011","10001","10001","10001"};case 'O'->new String[]{"01110","10001","10001","10001","10001","10001","01110"};case 'P'->new String[]{"11110","10001","10001","11110","10000","10000","10000"};case 'Q'->new String[]{"01110","10001","10001","10001","10101","10010","01101"};case 'R'->new String[]{"11110","10001","10001","11110","10100","10010","10001"};case 'S'->new String[]{"01111","10000","10000","01110","00001","00001","11110"};case 'T'->new String[]{"11111","00100","00100","00100","00100","00100","00100"};case 'U'->new String[]{"10001","10001","10001","10001","10001","10001","01110"};case 'V'->new String[]{"10001","10001","10001","10001","10001","01010","00100"};case 'W'->new String[]{"10001","10001","10001","10101","10101","10101","01010"};case 'X'->new String[]{"10001","10001","01010","00100","01010","10001","10001"};case 'Y'->new String[]{"10001","10001","01010","00100","00100","00100","00100"};case 'Z'->new String[]{"11111","00001","00010","00100","01000","10000","11111"};case '0'->new String[]{"01110","10001","10011","10101","11001","10001","01110"};case '1'->new String[]{"00100","01100","00100","00100","00100","00100","01110"};case '2'->new String[]{"01110","10001","00001","00010","00100","01000","11111"};case '3'->new String[]{"11110","00001","00001","01110","00001","00001","11110"};case '4'->new String[]{"00010","00110","01010","10010","11111","00010","00010"};case '5'->new String[]{"11111","10000","10000","11110","00001","00001","11110"};case '6'->new String[]{"01110","10000","10000","11110","10001","10001","01110"};case '7'->new String[]{"11111","00001","00010","00100","01000","01000","01000"};case '8'->new String[]{"01110","10001","10001","01110","10001","10001","01110"};case '9'->new String[]{"01110","10001","10001","01111","00001","00001","01110"};case ':'->new String[]{"00000","00100","00100","00000","00100","00100","00000"};case '/'->new String[]{"00001","00010","00010","00100","01000","01000","10000"};case '-'->new String[]{"00000","00000","00000","11111","00000","00000","00000"};case '.'->new String[]{"00000","00000","00000","00000","00000","00110","00110"};default->new String[]{"00000","00000","00000","00000","00000","00000","00000"};};int[] out=new int[7];for(int i=0;i<7;i++)out[i]=Integer.parseInt(a[i],2);return out;}
    private static void colorFor(byte id){if(id==World.GRASS)GL11.glColor3f(.28f,.68f,.24f);else if(id==World.SAND)GL11.glColor3f(.78f,.70f,.46f);else GL11.glColor3f(.43f,.31f,.20f);}
    private static void perspective(float fov,float aspect,float near,float far){float top=(float)(near*Math.tan(Math.toRadians(fov)*.5));float right=top*aspect;GL11.glFrustum(-right,right,-top,top,near,far);}
    private void save(){try{world.save(new java.io.File("ractex-world.rwx"),(float)px,(float)py,(float)pz);}catch(Exception e){System.err.println("Sauvegarde impossible: "+e.getMessage());}}
}
