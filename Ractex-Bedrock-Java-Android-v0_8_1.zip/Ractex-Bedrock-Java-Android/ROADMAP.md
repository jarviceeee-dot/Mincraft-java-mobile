# Feuille de route Ractex Bedrock Java

- [x] 0.1 — squelette Android / OpenGL ES
- [x] 0.2 — terrain de démonstration et commandes tactiles
- [x] 0.3 — blocs 3D indépendants, hotbar, inventaire simple, sauvegarde locale
- [x] 0.4 — gravité, saut et collisions de base
- [x] 0.5 — textures (atlas 16x16, pixels nets, ombrage par face)
- [x] 0.6 — monde infini par seed, chunks chargés autour du joueur, sauvegarde seed + modifications + position
- [x] 0.7 — menu de départ (Jouer, mondes, création avec seed, paramètres, pause)
- [x] 0.7.1 — correctif du blocage au sol, vraie interface (viseur, hotbar à icônes, inventaire)
- [x] 0.8 — mods : import de blocs (mods Ractex .zip, blocs cubiques des mods Minecraft Java .jar), menu Mods, registre dynamique
- [x] 0.8.1 — skins (import PNG Minecraft, aperçu, modèle 3D du joueur, vue 3e personne) et lecteur de code des mods (bytecode des .class, textes, images)
- [ ] 0.9 — inventaire avec quantités et interactions plus complètes
- [ ] 1.0 — API de scripts pour les mods (comportements, génération de terrain) ; pas de compatibilité Fabric/Forge pour le code
