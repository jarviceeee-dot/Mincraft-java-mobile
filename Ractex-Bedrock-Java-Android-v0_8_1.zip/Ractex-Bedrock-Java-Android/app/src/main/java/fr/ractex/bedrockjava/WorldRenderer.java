package fr.ractex.bedrockjava;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.opengl.Matrix;
import java.io.File;
import java.io.InputStream;
import java.nio.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/** Renderer OpenGL ES : monde infini par chunks (seed), caméra première personne, édition de blocs. */
public final class WorldRenderer implements GLSurfaceView.Renderer {
    private final int renderDist;                          // en chunks (réglable dans Paramètres)
    private final int unloadDist;
    private static final int GEN_PER_FRAME = 2, MESH_PER_FRAME = 3;
    private final int[][] offsets;                         // {dx,dz,d2} triés du plus proche au plus loin

    // Atlas assets/atlas.png : 4x4 tuiles de 16x16 px (64x64).
    private static final int T_GRASS_TOP = 0, T_GRASS_SIDE = 1, T_DIRT = 2, T_STONE = 3, T_LOG_SIDE = 4, T_LOG_TOP = 5, T_LEAVES = 6, T_PLANKS = 7;
    private static final int STRIDE = 6; // x,y,z,u,v,shade

    private final Context context;
    private final World world = new World(System.nanoTime());
    private volatile long seedShown = world.getSeed();
    private volatile boolean pendingNewWorld;
    private volatile long pendingSeed;

    private int program, aPosition, aUv, aShade, uMvp, uTex, texture;
    private final float[] projection = new float[16], view = new float[16], vp = new float[16];
    private volatile float yaw = 0f, pitch = .25f, forwardInput, strafeInput;
    private float playerX = 8.5f, playerZ = 8.5f, playerY = 40f, verticalVelocity = 0f;
    private boolean grounded = false;
    private volatile float moveSpeed = .072f;          // blocs par tick (60 ticks/s) = ~4,3 blocs/s comme Minecraft
    private long lastNanos = 0, accum = 0;
    private static final long TICK_NANOS = 16_666_667L;
    private volatile boolean needSpawn = true;
    private int lastPcx = Integer.MIN_VALUE, lastPcz = Integer.MIN_VALUE;

    // Skin / modèle du joueur (vue à la 3e personne)
    private static final class SkinData { final Bitmap bmp; final boolean slim; SkinData(Bitmap b, boolean s) { bmp = b; slim = s; } }
    private volatile SkinData skinData;
    private SkinData uploadedSkin;
    private int skinTex;
    private FloatBuffer[] partBuf; private int[] partVerts; private boolean partsSlim;
    private volatile int viewMode = 0;                     // 0 = 1re personne, 1 = 3e personne (dos), 2 = 3e personne (face)
    private float bodyYaw = 0f, headRel = 0f, walkPhase = 0f, walkAmp = 0f;
    private final float[] mA = new float[16], mC = new float[16];
    private int selectedBlock = World.GRASS;
    private File saveFile;
    private float[] build = new float[1 << 16];
    private int buildN;

    private static final String VS = "uniform mat4 uMvp; attribute vec3 aPosition; attribute vec2 aUv; attribute float aShade; varying vec2 vUv; varying float vShade; void main(){gl_Position=uMvp*vec4(aPosition,1.0);vUv=aUv;vShade=aShade;}";
    private static final String FS = "precision mediump float; uniform sampler2D uTex; varying vec2 vUv; varying float vShade; void main(){vec4 t=texture2D(uTex,vUv); if(t.a<0.5) discard; gl_FragColor=vec4(t.rgb*vShade,1.0);}";

    public WorldRenderer(Context context, int renderDist) {
        this.context = context.getApplicationContext();
        this.renderDist = Math.max(2, Math.min(8, renderDist)); this.unloadDist = this.renderDist + 2; this.offsets = buildOffsets(this.renderDist);
    }

    private static int[][] buildOffsets(int r) {
        List<int[]> l = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            int d2 = dx * dx + dz * dz; if (d2 <= r * r) l.add(new int[]{dx, dz, d2});
        }
        l.sort(Comparator.comparingInt(o -> o[2]));
        return l.toArray(new int[0][]);
    }

    // ---------- API appelée par l'UI ----------
    public void setSaveFile(File f) {
        saveFile = f;
        if (f != null && world.load(f)) {
            seedShown = world.getSeed();
            float[] p = world.takeSavedPlayer();
            if (p != null && !Float.isNaN(p[0]) && !Float.isNaN(p[1]) && !Float.isNaN(p[2])) { playerX = p[0]; playerY = p[1]; playerZ = p[2]; needSpawn = false; }
        }
    }
    public boolean saveWorld() {
        try { if (saveFile == null) return false; world.save(saveFile, playerX, playerY, playerZ); return true; }
        catch (Exception e) { return false; }
    }
    public long getSeed() { return seedShown; }
    /** Génère un nouveau monde avec cette seed (appliqué à la prochaine image, sur le thread GL). */
    public void newWorld(long seed) { seedShown = seed; pendingSeed = seed; pendingNewWorld = true; }
    /** Skin 64x64 (Bitmap ARGB_8888 à ne pas recycler) ; appliqué sur le thread GL à la prochaine image. */
    public void setSkin(Bitmap bmp, boolean slim) { skinData = bmp == null ? null : new SkinData(bmp, slim); }
    /** Change de vue (1re / 3e personne dos / 3e personne face) et renvoie la nouvelle vue. */
    public int cycleView() { viewMode = (viewMode + 1) % 3; return viewMode; }
    public void selectBlock(int id) { selectedBlock = id; }
    public int getSelectedBlock() { return selectedBlock; }
    public void rotate(float dx, float dy) { yaw += dx; pitch = Math.max(-.8f, Math.min(1f, pitch + dy)); }
    public void setMovement(float f, float s) { forwardInput = f; strafeInput = s; }
    public void setMoveSpeed(float v) { moveSpeed = Math.max(.01f, Math.min(.3f, v)); }
    public void jump() { if (grounded) { verticalVelocity = .17f; grounded = false; } }
    public void breakBlock() { editTarget(-1); }
    public void placeBlock() { if (selectedBlock != World.AIR) editTarget(1); }

    private void editTarget(int delta) {
        float dx = (float) Math.sin(yaw), dz = (float) Math.cos(yaw);
        float eyeY = playerY + 1.55f;
        float dy = -(float) Math.sin(pitch);
        for (float d = 1.3f; d < 5.5f; d += .2f) {
            int x = (int) Math.floor(playerX + dx * d), z = (int) Math.floor(playerZ + dz * d);
            int y = (int) Math.floor(eyeY + dy * d);
            if (world.get(x, y, z) != World.AIR) {
                if (delta < 0) world.set(x, y, z, World.AIR);
                else {
                    int px = (int) Math.floor(playerX + dx * (d - .25f)), pz = (int) Math.floor(playerZ + dz * (d - .25f));
                    int py = (int) Math.floor(eyeY + dy * (d - .25f));
                    if (world.get(px, py, pz) == World.AIR) world.set(px, py, pz, (byte) selectedBlock);
                }
                return;
            }
        }
    }

    // ---------- GL ----------
    @Override public void onSurfaceCreated(GL10 gl, EGLConfig c) {
        GLES20.glClearColor(.48f, .72f, .92f, 1); GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        program = createProgram(VS, FS);
        aPosition = GLES20.glGetAttribLocation(program, "aPosition");
        aUv = GLES20.glGetAttribLocation(program, "aUv"); aShade = GLES20.glGetAttribLocation(program, "aShade");
        uMvp = GLES20.glGetUniformLocation(program, "uMvp"); uTex = GLES20.glGetUniformLocation(program, "uTex");
        texture = loadAtlas();
        skinTex = 0; uploadedSkin = null; partBuf = null; // contexte GL recréé : le skin et le modèle sont renvoyés au GPU
        lastNanos = 0; accum = 0;
        for (Chunk ch : world.snapshot()) ch.dirty = true; // contexte GL recréé : tout remailler
    }
    @Override public void onSurfaceChanged(GL10 gl, int w, int h) {
        GLES20.glViewport(0, 0, w, h);
        Matrix.perspectiveM(projection, 0, 68f, (float) w / Math.max(1, h), .1f, (renderDist + 1) * 16f * 1.5f);
    }
    @Override public void onDrawFrame(GL10 gl) {
        if (pendingNewWorld) {
            pendingNewWorld = false; world.reset(pendingSeed);
            playerX = 8.5f; playerZ = 8.5f; verticalVelocity = 0; needSpawn = true; lastPcx = Integer.MIN_VALUE;
        }
        int pcx = Math.floorDiv((int) Math.floor(playerX), 16), pcz = Math.floorDiv((int) Math.floor(playerZ), 16);
        streamChunks(pcx, pcz);
        if (needSpawn) { playerY = world.surfaceAt((int) Math.floor(playerX), (int) Math.floor(playerZ)) + 1; verticalVelocity = 0; needSpawn = false; }
        long now = System.nanoTime();
        if (lastNanos == 0) lastNanos = now;
        accum += Math.min(now - lastNanos, 100_000_000L); lastNanos = now;
        int steps = 0;
        while (accum >= TICK_NANOS && steps < 5) { updatePlayer(); accum -= TICK_NANOS; steps++; }
        if (steps == 5) accum = 0;

        List<Chunk> list = world.snapshot();
        ArrayList<Chunk> dirty = null;
        for (Chunk c : list) if (c.dirty) { if (dirty == null) dirty = new ArrayList<>(); dirty.add(c); }
        if (dirty != null) {
            dirty.sort(Comparator.comparingInt(c -> (c.cx - pcx) * (c.cx - pcx) + (c.cz - pcz) * (c.cz - pcz)));
            for (int i = 0; i < Math.min(MESH_PER_FRAME, dirty.size()); i++) buildMesh(dirty.get(i));
        }

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
        float ex = playerX, ey = playerY + 1.62f, ez = playerZ;
        float fx = (float) (Math.sin(yaw) * Math.cos(pitch)), fy = -(float) Math.sin(pitch), fz = (float) (Math.cos(yaw) * Math.cos(pitch));
        // Caméra : aux yeux (1re personne) ou reculée derrière / devant le joueur, arrêtée par les blocs.
        int mode = viewMode;
        float camX = ex, camY = ey, camZ = ez, dirX = fx, dirY = fy, dirZ = fz;
        if (mode != 0) {
            float sgn = mode == 1 ? -1f : 1f, dist = 3.6f;
            for (float t = .3f; t <= 3.6f; t += .15f) {
                if (world.solidAt((int) Math.floor(ex + sgn * fx * t), (int) Math.floor(ey + sgn * fy * t), (int) Math.floor(ez + sgn * fz * t))) { dist = Math.max(.3f, t - .3f); break; }
            }
            camX = ex + sgn * fx * dist; camY = ey + sgn * fy * dist; camZ = ez + sgn * fz * dist;
            if (mode == 2) { dirX = -fx; dirY = -fy; dirZ = -fz; }
        }
        Matrix.setLookAtM(view, 0, camX, camY, camZ, camX + dirX, camY + dirY, camZ + dirZ, 0, 1, 0); Matrix.multiplyMM(vp, 0, projection, 0, view, 0);
        GLES20.glUseProgram(program); GLES20.glUniformMatrix4fv(uMvp, 1, false, vp, 0);
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture); GLES20.glUniform1i(uTex, 0);
        GLES20.glEnableVertexAttribArray(aPosition); GLES20.glEnableVertexAttribArray(aUv); GLES20.glEnableVertexAttribArray(aShade);
        int maxD2 = (renderDist + 1) * (renderDist + 1);
        for (Chunk c : list) {
            FloatBuffer m = c.mesh; int n = c.vertexCount;
            if (m == null || n == 0) continue;
            int ddx = c.cx - pcx, ddz = c.cz - pcz; if (ddx * ddx + ddz * ddz > maxD2) continue;
            // Élimination simple des chunks derrière la caméra.
            float cxw = c.cx * 16 + 8 - camX, czw = c.cz * 16 + 8 - camZ;
            if (cxw * dirX + czw * dirZ < -24f) continue;
            m.position(0); GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, STRIDE * 4, m);
            m.position(3); GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, STRIDE * 4, m);
            m.position(5); GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, STRIDE * 4, m);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, n);
        }
        if (mode != 0) drawPlayer();
        GLES20.glDisableVertexAttribArray(aPosition); GLES20.glDisableVertexAttribArray(aUv); GLES20.glDisableVertexAttribArray(aShade);
    }

    // ---------- joueur : modèle 3D + skin ----------
    private void ensureSkin() {
        SkinData d = skinData;
        if (d == null || d == uploadedSkin) return;
        if (skinTex == 0) { int[] id = new int[1]; GLES20.glGenTextures(1, id, 0); skinTex = id[0]; }
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, skinTex);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, d.bmp, 0);
        if (partBuf == null || partsSlim != d.slim) {
            partBuf = new FloatBuffer[PlayerModel.PARTS]; partVerts = new int[PlayerModel.PARTS]; partsSlim = d.slim;
            for (int i = 0; i < PlayerModel.PARTS; i++) {
                float[] m = PlayerModel.mesh(i, d.slim);
                FloatBuffer fb = ByteBuffer.allocateDirect(m.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
                fb.put(m); fb.position(0); partBuf[i] = fb; partVerts[i] = m.length / PlayerModel.STRIDE;
            }
        }
        uploadedSkin = d;
    }
    private static float wrapPi(float a) { return (float) (a - 2 * Math.PI * Math.floor((a + Math.PI) / (2 * Math.PI))); }

    private void drawPlayer() {
        ensureSkin();
        if (uploadedSkin == null || partBuf == null) return;
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, skinTex);
        final float s = PlayerModel.S, swing = (float) Math.sin(walkPhase) * .8f * walkAmp;
        for (int i = 0; i < PlayerModel.PARTS; i++) {
            Matrix.setIdentityM(mA, 0);
            Matrix.translateM(mA, 0, playerX, playerY, playerZ);
            Matrix.rotateM(mA, 0, (float) Math.toDegrees(bodyYaw), 0, 1, 0);
            float[] pv = PlayerModel.pivot(i, partsSlim);
            Matrix.translateM(mA, 0, pv[0] * s, pv[1] * s, pv[2] * s);
            if (i == PlayerModel.HEAD) {
                Matrix.rotateM(mA, 0, (float) Math.toDegrees(headRel), 0, 1, 0);
                Matrix.rotateM(mA, 0, (float) Math.toDegrees(pitch), 1, 0, 0);
            } else if (i != PlayerModel.BODY) {
                float a = (i == PlayerModel.RARM || i == PlayerModel.LLEG) ? swing : -swing; // bras et jambe opposés
                Matrix.rotateM(mA, 0, (float) Math.toDegrees(a), 1, 0, 0);
            }
            Matrix.multiplyMM(mC, 0, vp, 0, mA, 0);
            GLES20.glUniformMatrix4fv(uMvp, 1, false, mC, 0);
            FloatBuffer m = partBuf[i];
            m.position(0); GLES20.glVertexAttribPointer(aPosition, 3, GLES20.GL_FLOAT, false, STRIDE * 4, m);
            m.position(3); GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, STRIDE * 4, m);
            m.position(5); GLES20.glVertexAttribPointer(aShade, 1, GLES20.GL_FLOAT, false, STRIDE * 4, m);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, partVerts[i]);
        }
    }

    /** Charge les chunks autour du joueur (les plus proches d'abord) et décharge les trop lointains. */
    private void streamChunks(int pcx, int pcz) {
        int budget = GEN_PER_FRAME;
        for (int[] o : offsets) {
            int cx = pcx + o[0], cz = pcz + o[1];
            if (world.isLoaded(cx, cz)) continue;
            if (o[2] > 2 && budget <= 0) break; // les 9 chunks autour du joueur sont chargés tout de suite
            world.loadChunk(cx, cz); budget--;
        }
        if (pcx != lastPcx || pcz != lastPcz) { world.unloadFar(pcx, pcz, unloadDist); lastPcx = pcx; lastPcz = pcz; }
    }

    private void updatePlayer() {
        // Sécurité : si le joueur est coincé dans un bloc (ancienne sauvegarde, bug de 0.7), on le remonte.
        if (collides(playerX, playerY, playerZ, false)) {
            for (int i = 0; i < World.HEIGHT && collides(playerX, playerY, playerZ, false); i++) playerY = (float) Math.floor(playerY) + 1f;
            verticalVelocity = 0;
        }
        final float oldX = playerX, oldZ = playerZ;
        float norm = (forwardInput != 0 && strafeInput != 0) ? .7071f : 1f;
        float f = forwardInput * moveSpeed * norm, s = strafeInput * moveSpeed * norm;
        float mx = (float) Math.sin(yaw) * f + (float) Math.cos(yaw) * s;
        float mz = (float) Math.cos(yaw) * f - (float) Math.sin(yaw) * s;
        if (!collides(playerX + mx, playerY, playerZ, false)) playerX += mx;
        if (!collides(playerX, playerY, playerZ + mz, false)) playerZ += mz;

        verticalVelocity = Math.max(-.32f, verticalVelocity - .012f);
        float nextY = playerY + verticalVelocity;
        if (verticalVelocity <= 0 && collides(playerX, nextY, playerZ, true)) {
            // Atterrissage : on se pose pile sur le dessus du bloc touché (et non plus dans le bloc du dessous).
            playerY = (float) Math.floor(nextY) + 1f; verticalVelocity = 0; grounded = true;
        } else if (verticalVelocity > 0 && collides(playerX, nextY, playerZ, true)) {
            verticalVelocity = 0; grounded = false;
        } else { playerY = nextY; grounded = false; }
        if (playerY < -8) { playerY = world.surfaceAt((int) Math.floor(playerX), (int) Math.floor(playerZ)) + 1; verticalVelocity = 0; }

        // Animation du modèle : marche (bras / jambes), corps qui tourne vers la caméra, tête qui suit le regard.
        float moved = (float) Math.hypot(playerX - oldX, playerZ - oldZ);
        walkPhase += moved * 2.4f;
        walkAmp += ((moved > .001f ? 1f : 0f) - walkAmp) * .25f;
        float diff = wrapPi(yaw - bodyYaw);
        if (moved > .001f) bodyYaw += diff * .3f;
        else if (Math.abs(diff) > .9f) bodyYaw += diff - Math.signum(diff) * .9f;
        headRel = Math.max(-1.2f, Math.min(1.2f, wrapPi(yaw - bodyYaw)));
    }
    /** vertical=true : test exact des pieds (pour se poser proprement) ; false : tolérance de 3 cm (déplacements). */
    private boolean collides(float x, float feetY, float z, boolean vertical) {
        float radius = .27f, height = 1.8f, eps = vertical ? 0f : .03f;
        int minX = (int) Math.floor(x - radius), maxX = (int) Math.floor(x + radius);
        int minZ = (int) Math.floor(z - radius), maxZ = (int) Math.floor(z + radius);
        int minY = (int) Math.floor(feetY + eps), maxY = (int) Math.floor(feetY + height - eps);
        for (int bx = minX; bx <= maxX; bx++) for (int bz = minZ; bz <= maxZ; bz++) for (int by = minY; by <= maxY; by++)
            if (world.solidAt(bx, by, bz)) return true;
        return false;
    }
    public float getPlayerX() { return playerX; }
    public float getPlayerY() { return playerY; }
    public float getPlayerZ() { return playerZ; }

    // ---------- textures & maillage ----------
    private int loadAtlas() {
        int[] id = new int[1]; GLES20.glGenTextures(1, id, 0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id[0]);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_NEAREST);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        ModRegistry.init(context);
        Bitmap bmp = ModRegistry.atlas();
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0); // l'atlas est partagé avec l'interface : on ne le recycle pas
        return id[0];
    }
    /** Face 0=haut, 1=bas, 2..5=côtés. */
    private static int tile(byte id, int face) {
        int[] f = ModRegistry.faces(id);
        return face == 0 ? f[0] : face == 1 ? f[1] : f[2];
    }
    /** Voisin en coordonnées locales (peut sortir du chunk). Sous le monde = solide. */
    private byte nb(Chunk c, int x, int y, int z) {
        if (y < 0) return World.STONE;
        if (y >= World.HEIGHT) return World.AIR;
        if (x >= 0 && x < 16 && z >= 0 && z < 16) return c.get(x, y, z);
        return world.get(c.cx * 16 + x, y, c.cz * 16 + z);
    }
    private void buildMesh(Chunk c) {
        c.dirty = false; buildN = 0;
        int ox = c.cx * 16, oz = c.cz * 16;
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = 0; y <= c.maxY; y++) {
            byte id = c.get(x, y, z); if (id == World.AIR) continue;
            float X = ox + x, Z = oz + z;
            if (nb(c, x, y + 1, z) == World.AIR) face(tile(id, 0), 1.00f, X, y + 1, Z, X + 1, y + 1, Z, X + 1, y + 1, Z + 1, X, y + 1, Z + 1);
            if (nb(c, x, y - 1, z) == World.AIR) face(tile(id, 1), .50f, X, y, Z + 1, X + 1, y, Z + 1, X + 1, y, Z, X, y, Z);
            if (nb(c, x - 1, y, z) == World.AIR) face(tile(id, 2), .65f, X, y, Z, X, y, Z + 1, X, y + 1, Z + 1, X, y + 1, Z);
            if (nb(c, x + 1, y, z) == World.AIR) face(tile(id, 3), .65f, X + 1, y, Z + 1, X + 1, y, Z, X + 1, y + 1, Z, X + 1, y + 1, Z + 1);
            if (nb(c, x, y, z - 1) == World.AIR) face(tile(id, 4), .80f, X + 1, y, Z, X, y, Z, X, y + 1, Z, X + 1, y + 1, Z);
            if (nb(c, x, y, z + 1) == World.AIR) face(tile(id, 5), .80f, X, y, Z + 1, X + 1, y, Z + 1, X + 1, y + 1, Z + 1, X, y + 1, Z + 1);
        }
        if (buildN == 0) { c.mesh = null; c.vertexCount = 0; return; }
        ByteBuffer bb = ByteBuffer.allocateDirect(buildN * 4).order(ByteOrder.nativeOrder());
        FloatBuffer fb = bb.asFloatBuffer(); fb.put(build, 0, buildN); fb.position(0);
        c.mesh = fb; c.vertexCount = buildN / STRIDE;
    }
    /** Quad a,b (bas) puis c,d (haut) ; UV rentrés pour éviter tout débordement de tuile. */
    private void face(int tile, float shade, float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float dx, float dy, float dz) {
        if (buildN + 6 * STRIDE > build.length) build = Arrays.copyOf(build, build.length * 2);
        int cols = ModRegistry.COLS, rws = ModRegistry.rows();
        float eu = .02f / (cols * 16), ev = .02f / (rws * 16);
        float u0 = (tile % cols) / (float) cols + eu, u1 = (tile % cols + 1) / (float) cols - eu;
        float v0 = (tile / cols) / (float) rws + ev, v1 = (tile / cols + 1) / (float) rws - ev;
        vertex(ax, ay, az, u0, v1, shade); vertex(bx, by, bz, u1, v1, shade); vertex(cx, cy, cz, u1, v0, shade);
        vertex(ax, ay, az, u0, v1, shade); vertex(cx, cy, cz, u1, v0, shade); vertex(dx, dy, dz, u0, v0, shade);
    }
    private void vertex(float x, float y, float z, float u, float v, float s) {
        float[] a = build; int n = buildN;
        a[n] = x; a[n + 1] = y; a[n + 2] = z; a[n + 3] = u; a[n + 4] = v; a[n + 5] = s; buildN = n + 6;
    }

    private static int shader(int type, String src) { int s = GLES20.glCreateShader(type); GLES20.glShaderSource(s, src); GLES20.glCompileShader(s); int[] ok = {0}; GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0); if (ok[0] == 0) throw new RuntimeException(GLES20.glGetShaderInfoLog(s)); return s; }
    private static int createProgram(String vs, String fs) { int p = GLES20.glCreateProgram(); GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs)); GLES20.glLinkProgram(p); int[] ok = {0}; GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0); if (ok[0] == 0) throw new RuntimeException(GLES20.glGetProgramInfoLog(p)); return p; }
}
