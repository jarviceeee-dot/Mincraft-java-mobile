# Ractex Bedrock Java — Prototype 0.4

Moteur voxel Android indépendant expérimental, en Java 17 et OpenGL ES 2.0.

## Nouveautés 0.4
- Gravité verticale et chute.
- Bouton SAUT avec saut lorsque le joueur touche le sol.
- Collisions simples avec les blocs : le joueur ne traverse plus les murs et le sol.
- Déplacement horizontal avec test de collision par axe.
- Caméra en hauteur par rapport aux pieds du joueur.
- Les fonctions 3D, hotbar, inventaire simplifié et sauvegarde de la 0.3 sont conservées.

## Compiler
Ouvrir le dossier dans Android Studio avec JDK 17 et Android SDK 35, synchroniser Gradle puis lancer sur un appareil Android. Ce ZIP contient le code source et non un APK compilé.

## Textures (0.5)
Atlas `app/src/main/assets/atlas.png` (4x4 tuiles de 16x16). Filtrage NEAREST : pixels nets. Teinte herbe/feuilles déjà appliquée dans l'atlas.

## Limites
Physique prototype : pas encore de sprint, nage, échelles, escaliers optimisés, synchronisation multijoueur ou compatibilité avec les mods Fabric/Forge. La physique est encore mise à jour par image et pourra être améliorée avec un pas de temps fixe.

## Monde infini et seed (0.6)
Le terrain est généré par chunks de 16x16 autour du joueur (rayon de 5 chunks) à partir d'une seed : même seed = même monde. Bouton SEED pour entrer un nombre ou un texte. La sauvegarde ne contient que la seed, tes modifications de blocs et ta position, et se fait aussi en quittant l'app.

## Menu de départ (0.7)
Écran titre : Jouer, Paramètres, Quitter. « Jouer » liste les mondes (un fichier par monde, avec seed et date), « Créer un nouveau monde » demande un nom et une seed. En jeu, le bouton MENU (ou le bouton Retour d'Android) ouvre la pause : Reprendre, Sauvegarder, Paramètres, Sauvegarder et quitter. Paramètres : distance d'affichage (2 à 8 chunks) et sensibilité de la caméra. L'ancienne sauvegarde 0.6 est convertie en « Monde 1 ».

## Correctif et interface (0.7.1)
- **Blocage corrigé** : à l'atterrissage, le joueur s'enfonçait d'un bloc dans le sol et toutes les directions étaient bloquées. Il se pose maintenant exactement sur le dessus du bloc, et un joueur déjà coincé (ancienne sauvegarde) est remonté automatiquement.
- **Vraie interface** : viseur au centre, croix directionnelle et boutons à taille réelle (en dp) avec effet d'appui, diagonales possibles (deux directions en même temps), barre d'objets avec icônes de blocs 3D tirées de l'atlas, nom de l'objet affiché au changement de case, coordonnées en haut à gauche.
- **Inventaire** : vrai écran (plus de boîte de dialogue). Touche un bloc pour le mettre dans la case sélectionnée, « Vider » pour la libérer. La barre d'objets est sauvegardée.

## Pack GUI et vitesse (0.7.2)
- **Textures du pack « Recompleted GUI »** (YAPK0, dossier `assets/gui/`) : barre d'objets + sélection, viseur, boutons (gris, verts quand on appuie), champs de texte, curseurs de réglage, écran d'inventaire `inventory.png`, cœurs et faim.
- **Inventaire** : le vrai écran du pack. 1re ligne du sac = les 5 blocs + ✕ (vider la case). Touche une case de la barre du bas pour la sélectionner.
- **Vitesse** : la marche ne dépend plus des images par seconde (avant, un écran 120 Hz allait deux fois plus vite). Vitesse par défaut ~4,3 blocs/s comme Minecraft, réglable dans Paramètres (1 à 10). Diagonales normalisées, saut ramené à ~1,2 bloc.
- Les barres de vie et de faim sont purement visuelles (pas encore de dégâts ni de faim) ; désactivables dans Paramètres.

## Mods (0.8)
Menu **Mods** : ajoute un .zip/.jar depuis ton téléphone. Les blocs cubiques (textures + noms) des mods Minecraft Java et des mods Ractex apparaissent dans le Sac. Le code des mods Minecraft ne peut pas tourner dans Ractex (moteur indépendant) : voir `MODS_FR.md` pour le détail, le format Ractex et les exemples.

## Skins et lecteur de code (0.8.1)
- **Skins** : menu principal → **Skins** → *Ajouter un skin (.png)*. Format Minecraft Java : 64×64, ou 64×32 (ancien format, converti automatiquement) ; les skins HD sont réduits en 64×64 ; les bras fins « Alex » sont détectés tout seuls. Un aperçu face + dos s'affiche ; sans skin choisi, un personnage par défaut est utilisé.
- **Vue 3e personne** : en jeu, le bouton **VUE** passe de la 1re personne à la 3e personne (de dos), puis (de face). Le personnage porte ton skin (couches externes chapeau / veste / manches / pantalon comprises), marche (bras et jambes), tourne le corps et la tête avec la caméra. La caméra est arrêtée par les blocs.
- **Lire le code des mods** : menu **Mods** → touche un mod → liste de tous ses fichiers (code en premier, avec filtre). Un fichier `.class` s'affiche en **bytecode lisible** (classe, champs, méthodes, instructions, appels de méthodes, textes, noms de variables si le mod les contient) ; les fichiers JSON / TOML / .java / texte s'affichent tels quels (texte sélectionnable et copiable) ; les images PNG sont affichées. Ce n'est pas un décompilateur : le `.class` ne contient pas le code Java d'origine, seulement le bytecode.
