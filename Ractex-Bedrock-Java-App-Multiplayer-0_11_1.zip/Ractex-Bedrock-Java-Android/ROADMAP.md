# Feuille de route Ractex Bedrock Java

- [x] 0.1 — squelette Android / OpenGL ES
- [x] 0.2 — terrain de démonstration et commandes tactiles
- [x] 0.3 — blocs 3D indépendants, hotbar, inventaire simple, sauvegarde locale
- [x] 0.4 — gravité, saut et collisions de base
- [x] 0.5 — textures (atlas 16x16, pixels nets, ombrage par face)
- [x] 0.6 — monde infini par seed, chunks chargés autour du joueur, sauvegarde seed + modifications + position
- [x] 0.7 — menu de départ (Jouer, mondes, création avec seed, paramètres, pause)
- [x] 0.7.1 — correctif du blocage au sol, vraie interface (viseur, hotbar à icônes, inventaire)
- [x] 0.8 — mods : import de blocs (mods Ractex .zip, blocs cubiques des mods Minecraft Java .jar), menu Mods, registre dynamique
- [x] 0.8.1 — skins (import PNG Minecraft, aperçu, modèle 3D du joueur, vue 3e personne) et lecteur de code des mods (bytecode des .class, textes, images)
- [x] 0.9 — survie : inventaire à quantités (piles de 64), minage en maintenant le doigt, butin, vie / faim / chute / mort, pommes, cycle jour-nuit, sable / pierre taillée / planches, fabrication simple
- [x] 0.10 — outils (pioche / hache / pelle en bois et en pierre) avec durabilité, bâton, table de fabrication, minage comme Minecraft (pierre = pioche obligatoire)
- [x] 0.10.1 — minerais (charbon, fer), cavernes, lacs et nage, four, lingots, outils en fer, air sous l'eau
- [ ] 0.11 — monstres et animaux, armes, armure
- [ ] 0.12 — biomes, structures, cuisson (four), lit et sommeil
- [ ] 1.0 — API de scripts pour les mods (comportements, génération de terrain) ; pas de compatibilité Fabric/Forge pour le code

- [x] 0.11 étape 1 — base réseau WebSocket, relais de salons et chat (prototype à déployer)
- [ ] 0.11 étape 2 — synchronisation réelle du monde (blocs, joueurs, inventaires) et tests multi-appareils
- [ ] 0.12 — serveurs permanents dédiés, sauvegarde des mondes, comptes et catalogue public
