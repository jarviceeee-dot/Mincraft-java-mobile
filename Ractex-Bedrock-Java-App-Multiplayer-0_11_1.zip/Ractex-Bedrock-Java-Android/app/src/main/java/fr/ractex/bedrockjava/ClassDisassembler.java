package fr.ractex.bedrockjava;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Lecteur de fichiers .class (Java pur, sans dépendance) : produit un texte lisible façon « javap -c » avec
 * la déclaration de la classe, ses champs, ses méthodes et le vrai bytecode de chaque méthode
 * (constantes, appels de méthodes, noms de variables locales quand le mod les contient).
 * Ce n'est pas un décompilateur : on lit le bytecode, on ne le réécrit pas en Java.
 */
final class ClassDisassembler {
    private ClassDisassembler() {}

    private static final String[] OPS = {
        "nop", "aconst_null", "iconst_m1", "iconst_0", "iconst_1", "iconst_2", "iconst_3", "iconst_4", "iconst_5", "lconst_0", "lconst_1",
        "fconst_0", "fconst_1", "fconst_2", "dconst_0", "dconst_1", "bipush", "sipush", "ldc", "ldc_w", "ldc2_w",
        "iload", "lload", "fload", "dload", "aload", "iload_0", "iload_1", "iload_2", "iload_3", "lload_0", "lload_1", "lload_2", "lload_3",
        "fload_0", "fload_1", "fload_2", "fload_3", "dload_0", "dload_1", "dload_2", "dload_3", "aload_0", "aload_1", "aload_2", "aload_3",
        "iaload", "laload", "faload", "daload", "aaload", "baload", "caload", "saload",
        "istore", "lstore", "fstore", "dstore", "astore", "istore_0", "istore_1", "istore_2", "istore_3", "lstore_0", "lstore_1", "lstore_2", "lstore_3",
        "fstore_0", "fstore_1", "fstore_2", "fstore_3", "dstore_0", "dstore_1", "dstore_2", "dstore_3", "astore_0", "astore_1", "astore_2", "astore_3",
        "iastore", "lastore", "fastore", "dastore", "aastore", "bastore", "castore", "sastore",
        "pop", "pop2", "dup", "dup_x1", "dup_x2", "dup2", "dup2_x1", "dup2_x2", "swap",
        "iadd", "ladd", "fadd", "dadd", "isub", "lsub", "fsub", "dsub", "imul", "lmul", "fmul", "dmul", "idiv", "ldiv", "fdiv", "ddiv",
        "irem", "lrem", "frem", "drem", "ineg", "lneg", "fneg", "dneg", "ishl", "lshl", "ishr", "lshr", "iushr", "lushr",
        "iand", "land", "ior", "lor", "ixor", "lxor", "iinc", "i2l", "i2f", "i2d", "l2i", "l2f", "l2d", "f2i", "f2l", "f2d", "d2i", "d2l", "d2f",
        "i2b", "i2c", "i2s", "lcmp", "fcmpl", "fcmpg", "dcmpl", "dcmpg",
        "ifeq", "ifne", "iflt", "ifge", "ifgt", "ifle", "if_icmpeq", "if_icmpne", "if_icmplt", "if_icmpge", "if_icmpgt", "if_icmple",
        "if_acmpeq", "if_acmpne", "goto", "jsr", "ret", "tableswitch", "lookupswitch",
        "ireturn", "lreturn", "freturn", "dreturn", "areturn", "return",
        "getstatic", "putstatic", "getfield", "putfield", "invokevirtual", "invokespecial", "invokestatic", "invokeinterface", "invokedynamic",
        "new", "newarray", "anewarray", "arraylength", "athrow", "checkcast", "instanceof", "monitorenter", "monitorexit",
        "wide", "multianewarray", "ifnull", "ifnonnull", "goto_w", "jsr_w"
    };

    // ------------------------------------------------------------ point d'entrée
    /** Texte lisible d'un .class ; ne lève jamais d'exception (le message d'erreur est écrit dans le texte). */
    static String disassemble(byte[] data) {
        StringBuilder out = new StringBuilder();
        try { new Reader(data, out).run(); }
        catch (Exception e) { out.append("\n// Lecture interrompue : ").append(e.getClass().getSimpleName()).append(e.getMessage() != null ? " : " + e.getMessage() : "").append('\n'); }
        return out.toString();
    }

    // ------------------------------------------------------------ lecture
    private static final class Reader {
        final StringBuilder out; final DataInputStream in; final byte[] data;
        int n; int[] tag, a, b; Object[] val;
        String thisName = "", superName = "";

        Reader(byte[] data, StringBuilder out) { this.data = data; this.out = out; this.in = new DataInputStream(new ByteArrayInputStream(data)); }

        void run() throws Exception {
            if (data.length < 10 || in.readInt() != 0xCAFEBABE) throw new Exception("ce fichier n'est pas un .class Java valide (" + data.length + " octets)");
            int minor = in.readUnsignedShort(), major = in.readUnsignedShort();
            readPool();
            int access = in.readUnsignedShort();
            thisName = cls(in.readUnsignedShort()); int sup = in.readUnsignedShort(); superName = sup == 0 ? "" : cls(sup);
            int ni = in.readUnsignedShort(); List<String> ifs = new ArrayList<>();
            for (int i = 0; i < ni; i++) ifs.add(cls(in.readUnsignedShort()));

            int nf = in.readUnsignedShort(); List<String> fields = new ArrayList<>();
            for (int i = 0; i < nf; i++) fields.add(readField());
            int nm = in.readUnsignedShort(); List<String> methods = new ArrayList<>();
            for (int i = 0; i < nm; i++) methods.add(readMethod());
            String source = null;
            int na = in.readUnsignedShort();
            for (int i = 0; i < na; i++) {
                String an = utf(in.readUnsignedShort()); int len = in.readInt();
                if (an.equals("SourceFile") && len == 2) source = utf(in.readUnsignedShort()); else in.skipBytes(len);
            }

            out.append("// Classe : ").append(thisName).append("   (Java ").append(javaVersion(major)).append(", format ").append(major).append('.').append(minor).append(")\n");
            if (source != null) out.append("// Source d'origine : ").append(source).append('\n');
            out.append("// Bytecode lu tel quel (pas un décompilateur : le code Java d'origine n'est pas dans le .class).\n\n");
            StringBuilder head = new StringBuilder(flags(access & ~0x20, 0));
            boolean isIf = (access & 0x200) != 0;
            head.append(isIf ? ((access & 0x2000) != 0 ? "@interface " : "interface ") : (access & 0x4000) != 0 ? "enum " : "class ").append(thisName);
            if (!superName.isEmpty() && !superName.equals("java.lang.Object") && !isIf) head.append(" extends ").append(superName);
            if (!ifs.isEmpty()) head.append(isIf ? " extends " : " implements ").append(String.join(", ", ifs));
            out.append(head).append(" {\n");
            if (!fields.isEmpty()) { out.append("\n    // ----- champs -----\n"); for (String f : fields) out.append(f); }
            if (!methods.isEmpty()) { out.append("\n    // ----- méthodes -----\n"); for (String m : methods) out.append(m); }
            out.append("}\n");
        }

        static String javaVersion(int major) { return major >= 49 ? String.valueOf(major - 44) : major == 48 ? "1.4" : major == 47 ? "1.3" : major == 46 ? "1.2" : "1.1"; }

        // ---------- table des constantes ----------
        void readPool() throws Exception {
            n = in.readUnsignedShort(); tag = new int[n]; a = new int[n]; b = new int[n]; val = new Object[n];
            for (int i = 1; i < n; i++) {
                int t = in.readUnsignedByte(); tag[i] = t;
                switch (t) {
                    case 1: val[i] = in.readUTF(); break;
                    case 3: val[i] = in.readInt(); break;
                    case 4: val[i] = in.readFloat(); break;
                    case 5: val[i] = in.readLong(); i++; break;
                    case 6: val[i] = in.readDouble(); i++; break;
                    case 7: case 8: case 16: case 19: case 20: a[i] = in.readUnsignedShort(); break;
                    case 9: case 10: case 11: case 12: case 17: case 18: a[i] = in.readUnsignedShort(); b[i] = in.readUnsignedShort(); break;
                    case 15: a[i] = in.readUnsignedByte(); b[i] = in.readUnsignedShort(); break;
                    default: throw new Exception("constante inconnue (type " + t + ") à l'entrée " + i);
                }
            }
        }
        String utf(int i) { return i > 0 && i < n && tag[i] == 1 ? (String) val[i] : "?#" + i; }
        String cls(int i) { return i > 0 && i < n && tag[i] == 7 ? utf(a[i]).replace('/', '.') : "?#" + i; }
        String nameAndType(int i) { return utf(a[i]) + ":" + utf(b[i]); }
        /** Constante lisible : texte entre guillemets, nombre, classe, membre « Classe.nom:type »... */
        String konst(int i) {
            if (i <= 0 || i >= n) return "#" + i;
            switch (tag[i]) {
                case 1: return utf(i);
                case 3: return String.valueOf(val[i]);
                case 4: return val[i] + "f";
                case 5: return val[i] + "L";
                case 6: return val[i] + "d";
                case 7: return cls(i);
                case 8: return quote(utf(a[i]));
                case 9: case 10: case 11: return cls(a[i]) + "." + nameAndType(b[i]);
                case 12: return nameAndType(i);
                case 15: return "handle " + a[i] + " " + konst(b[i]);
                case 16: return "methodtype " + utf(a[i]);
                case 17: case 18: return "dynamic #" + a[i] + ":" + nameAndType(b[i]);
                case 19: case 20: return utf(a[i]);
                default: return "#" + i;
            }
        }

        // ---------- champs et méthodes ----------
        String readField() throws Exception {
            int acc = in.readUnsignedShort(); String name = utf(in.readUnsignedShort()), desc = utf(in.readUnsignedShort());
            String cv = null; int na = in.readUnsignedShort();
            for (int i = 0; i < na; i++) {
                String an = utf(in.readUnsignedShort()); int len = in.readInt();
                if (an.equals("ConstantValue") && len == 2) cv = konst(in.readUnsignedShort()); else in.skipBytes(len);
            }
            return "    " + flags(acc, 2) + type(desc) + " " + name + (cv != null ? " = " + cv : "") + ";\n";
        }

        String readMethod() throws Exception {
            int acc = in.readUnsignedShort(); String name = utf(in.readUnsignedShort()), desc = utf(in.readUnsignedShort());
            int na = in.readUnsignedShort();
            List<String> throwsList = new ArrayList<>(); String code = null; Map<Integer, String> locals = new HashMap<>();
            byte[] bc = null; int maxStack = 0, maxLocals = 0; List<String> exc = new ArrayList<>();
            for (int i = 0; i < na; i++) {
                String an = utf(in.readUnsignedShort()); int len = in.readInt();
                if (an.equals("Exceptions")) {
                    int c = in.readUnsignedShort(); for (int k = 0; k < c; k++) throwsList.add(cls(in.readUnsignedShort()));
                } else if (an.equals("Code")) {
                    maxStack = in.readUnsignedShort(); maxLocals = in.readUnsignedShort();
                    int cl = in.readInt(); bc = new byte[cl]; in.readFully(bc);
                    int ne = in.readUnsignedShort();
                    for (int k = 0; k < ne; k++) {
                        int s = in.readUnsignedShort(), e = in.readUnsignedShort(), h = in.readUnsignedShort(), ct = in.readUnsignedShort();
                        exc.add(String.format("%5d à %-5d -> %-5d  %s", s, e, h, ct == 0 ? "(tout)" : cls(ct)));
                    }
                    int nca = in.readUnsignedShort();
                    for (int k = 0; k < nca; k++) {
                        String can = utf(in.readUnsignedShort()); int clen = in.readInt();
                        if (can.equals("LocalVariableTable")) {
                            int c = in.readUnsignedShort();
                            for (int q = 0; q < c; q++) { in.readUnsignedShort(); in.readUnsignedShort(); String vn = utf(in.readUnsignedShort()); in.readUnsignedShort(); int slot = in.readUnsignedShort(); locals.putIfAbsent(slot, vn); }
                        } else in.skipBytes(clen);
                    }
                } else in.skipBytes(len);
            }
            boolean isStatic = (acc & 8) != 0;
            StringBuilder sb = new StringBuilder("\n    ");
            if (name.equals("<clinit>")) sb.append("static");
            else {
                sb.append(flags(acc, 1));
                List<String> ps = params(desc);
                boolean ctor = name.equals("<init>");
                if (!ctor) sb.append(type(desc.substring(desc.indexOf(')') + 1))).append(' ');
                sb.append(ctor ? simple(thisName) : name).append('(');
                int slot = isStatic ? 0 : 1;
                for (int i = 0; i < ps.size(); i++) {
                    if (i > 0) sb.append(", ");
                    sb.append(ps.get(i)); String ln = locals.get(slot); if (ln != null) sb.append(' ').append(ln);
                    slot += (ps.get(i).equals("long") || ps.get(i).equals("double")) ? 2 : 1;
                }
                sb.append(')');
                if (!throwsList.isEmpty()) sb.append(" throws ").append(String.join(", ", throwsList));
            }
            if (bc == null) return sb.append(";\n").toString();
            sb.append(" {\n        // pile max : ").append(maxStack).append(", variables locales : ").append(maxLocals).append('\n');
            sb.append(code(bc, locals, isStatic));
            if (!exc.isEmpty()) { sb.append("        // blocs try/catch (début à fin -> gestionnaire)\n"); for (String e : exc) sb.append("        //   ").append(e).append('\n'); }
            return sb.append("    }\n").toString();
        }

        // ---------- bytecode ----------
        String code(byte[] c, Map<Integer, String> locals, boolean isStatic) {
            StringBuilder sb = new StringBuilder();
            int pc = 0;
            try {
                while (pc < c.length) {
                    int op = c[pc] & 0xff;
                    String nm = op < OPS.length ? OPS[op] : "op_" + op;
                    StringBuilder arg = new StringBuilder(); int len = 1;
                    switch (op) {
                        case 16: arg.append((byte) c[pc + 1]); len = 2; break;
                        case 17: arg.append(s2(c, pc + 1)); len = 3; break;
                        case 18: arg.append(konst(c[pc + 1] & 0xff)); len = 2; break;
                        case 19: case 20: arg.append(konst(u2(c, pc + 1))); len = 3; break;
                        case 21: case 22: case 23: case 24: case 25: case 54: case 55: case 56: case 57: case 58: case 169:
                            arg.append(local(c[pc + 1] & 0xff, locals, isStatic)); len = 2; break;
                        case 132: arg.append(local(c[pc + 1] & 0xff, locals, isStatic)).append(", ").append((byte) c[pc + 2]); len = 3; break;
                        case 153: case 154: case 155: case 156: case 157: case 158: case 159: case 160: case 161: case 162: case 163: case 164:
                        case 165: case 166: case 167: case 168: case 198: case 199:
                            arg.append(pc + s2(c, pc + 1)); len = 3; break;
                        case 200: case 201: arg.append(pc + s4(c, pc + 1)); len = 5; break;
                        case 170: {
                            int p = (pc + 4) & ~3; int def = s4(c, p), lo = s4(c, p + 4), hi = s4(c, p + 8);
                            arg.append("{ // ").append(lo).append(" à ").append(hi);
                            for (int k = 0; k <= hi - lo; k++) arg.append("\n                ").append(lo + k).append(": ").append(pc + s4(c, p + 12 + 4 * k));
                            arg.append("\n                défaut: ").append(pc + def).append(" }");
                            len = p + 12 + 4 * (hi - lo + 1) - pc; break;
                        }
                        case 171: {
                            int p = (pc + 4) & ~3; int def = s4(c, p), np = s4(c, p + 4);
                            arg.append("{ // ").append(np);
                            for (int k = 0; k < np; k++) arg.append("\n                ").append(s4(c, p + 8 + 8 * k)).append(": ").append(pc + s4(c, p + 12 + 8 * k));
                            arg.append("\n                défaut: ").append(pc + def).append(" }");
                            len = p + 8 + 8 * np - pc; break;
                        }
                        case 178: case 179: case 180: case 181: case 182: case 183: case 184: case 187: case 189: case 192: case 193:
                            arg.append(konst(u2(c, pc + 1))); len = 3; break;
                        case 185: arg.append(konst(u2(c, pc + 1))).append(", ").append(c[pc + 3] & 0xff); len = 5; break;
                        case 186: arg.append(konst(u2(c, pc + 1))); len = 5; break;
                        case 188: arg.append(new String[]{"?", "?", "?", "?", "boolean", "char", "float", "double", "byte", "short", "int", "long"}[Math.min(11, c[pc + 1] & 0xff)]); len = 2; break;
                        case 196: {
                            int op2 = c[pc + 1] & 0xff; nm = "wide " + (op2 < OPS.length ? OPS[op2] : "op_" + op2);
                            arg.append(local(u2(c, pc + 2), locals, isStatic));
                            if (op2 == 132) { arg.append(", ").append(s2(c, pc + 4)); len = 6; } else len = 4; break;
                        }
                        case 197: arg.append(konst(u2(c, pc + 1))).append(", ").append(c[pc + 3] & 0xff); len = 4; break;
                        default:
                            // formes courtes iload_0 ... astore_3 : on affiche le nom de la variable si le mod le contient
                            if ((op >= 26 && op <= 45)) arg.append(localName((op - 26) % 4, locals, isStatic));
                            else if (op >= 59 && op <= 78) arg.append(localName((op - 59) % 4, locals, isStatic));
                    }
                    sb.append(String.format("        %5d: %-15s %s\n", pc, nm, arg.toString().trim()));
                    pc += len;
                }
            } catch (RuntimeException e) { sb.append("        // bytecode tronqué ou illisible à partir de ").append(pc).append('\n'); }
            return sb.toString();
        }
        String local(int slot, Map<Integer, String> locals, boolean isStatic) { String nm = locals.get(slot); return slot + (nm != null ? " // " + nm : (slot == 0 && !isStatic ? " // this" : "")); }
        String localName(int slot, Map<Integer, String> locals, boolean isStatic) { String nm = locals.get(slot); return nm != null ? "// " + nm : (slot == 0 && !isStatic ? "// this" : ""); }
    }

    // ------------------------------------------------------------ outils
    private static int u2(byte[] c, int i) { return ((c[i] & 0xff) << 8) | (c[i + 1] & 0xff); }
    private static int s2(byte[] c, int i) { return (short) u2(c, i); }
    private static int s4(byte[] c, int i) { return ((c[i] & 0xff) << 24) | ((c[i + 1] & 0xff) << 16) | ((c[i + 2] & 0xff) << 8) | (c[i + 3] & 0xff); }

    private static String simple(String cls) { int i = Math.max(cls.lastIndexOf('.'), cls.lastIndexOf('$')); return i >= 0 ? cls.substring(i + 1) : cls; }

    private static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length() && i < 400; i++) {
            char ch = s.charAt(i);
            if (ch == '"' || ch == '\\') sb.append('\\').append(ch);
            else if (ch == '\n') sb.append("\\n"); else if (ch == '\t') sb.append("\\t"); else if (ch == '\r') sb.append("\\r");
            else if (ch < 32) sb.append(String.format("\\u%04x", (int) ch)); else sb.append(ch);
        }
        if (s.length() > 400) sb.append("…");
        return sb.append('"').toString();
    }

    /** Modificateurs : kind 0 = classe, 1 = méthode, 2 = champ. */
    private static String flags(int f, int kind) {
        StringBuilder sb = new StringBuilder();
        if ((f & 1) != 0) sb.append("public "); if ((f & 2) != 0) sb.append("private "); if ((f & 4) != 0) sb.append("protected ");
        if ((f & 8) != 0 && kind != 0) sb.append("static ");
        if ((f & 0x10) != 0) sb.append("final ");
        if (kind == 1) { if ((f & 0x20) != 0) sb.append("synchronized "); if ((f & 0x100) != 0) sb.append("native "); }
        if (kind == 2) { if ((f & 0x40) != 0) sb.append("volatile "); if ((f & 0x80) != 0) sb.append("transient "); }
        if ((f & 0x400) != 0 && !(kind == 0 && (f & 0x200) != 0)) sb.append("abstract ");
        if ((f & 0x1000) != 0) sb.append("/*synthetic*/ ");
        return sb.toString();
    }

    /** Descripteur JVM (« Ljava/lang/String; », « [I »...) -> type Java lisible. */
    static String type(String d) {
        int dims = 0; while (d.startsWith("[")) { dims++; d = d.substring(1); }
        String t;
        switch (d.isEmpty() ? ' ' : d.charAt(0)) {
            case 'B': t = "byte"; break; case 'C': t = "char"; break; case 'D': t = "double"; break; case 'F': t = "float"; break;
            case 'I': t = "int"; break; case 'J': t = "long"; break; case 'S': t = "short"; break; case 'Z': t = "boolean"; break; case 'V': t = "void"; break;
            case 'L': t = d.substring(1, Math.max(1, d.indexOf(';') < 0 ? d.length() : d.indexOf(';'))).replace('/', '.'); break;
            default: t = d;
        }
        StringBuilder sb = new StringBuilder(t); for (int i = 0; i < dims; i++) sb.append("[]"); return sb.toString();
    }
    /** Types des paramètres d'un descripteur de méthode « (ILjava/lang/String;[J)V ». */
    static List<String> params(String desc) {
        List<String> r = new ArrayList<>();
        int i = desc.indexOf('(') + 1, end = desc.indexOf(')');
        while (i > 0 && i < end) {
            int s = i; while (desc.charAt(i) == '[') i++;
            if (desc.charAt(i) == 'L') i = desc.indexOf(';', i);
            i++; r.add(type(desc.substring(s, i)));
        }
        return r;
    }
}
