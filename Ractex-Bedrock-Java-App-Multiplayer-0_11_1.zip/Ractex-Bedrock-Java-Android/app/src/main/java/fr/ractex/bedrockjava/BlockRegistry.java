package fr.ractex.bedrockjava;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Registry foundation. A future mod API can register additional block definitions here. */
public final class BlockRegistry {
    private static final Map<Integer, Block> BY_ID = new LinkedHashMap<>();
    static {
        register(Block.AIR); register(Block.GRASS); register(Block.DIRT); register(Block.STONE);
    }
    private BlockRegistry() {}
    public static void register(Block block) { BY_ID.put(block.id, block); }
    public static Block get(int id) { return BY_ID.getOrDefault(id, Block.AIR); }
    public static Map<Integer, Block> all() { return Collections.unmodifiableMap(BY_ID); }
}
