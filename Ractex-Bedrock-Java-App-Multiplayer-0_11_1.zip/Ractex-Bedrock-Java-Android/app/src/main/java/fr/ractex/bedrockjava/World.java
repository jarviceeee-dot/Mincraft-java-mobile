package fr.ractex.bedrockjava;

import java.io.*;
import java.util.*;

/**
 * Monde infini généré à partir d'une seed. Le terrain est une fonction pure de (seed, x, z) :
 * la même seed redonne exactement le même monde. Seules les modifications du joueur sont sauvegardées.
 */
public final class World {
    public static final int HEIGHT = 48;
    public static final int SAND_LEVEL = 16; // en dessous : plages de sable
    public static final int WATER_LEVEL = 14; // les creux sous ce niveau se remplissent d'eau (lacs)
    public static final byte AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, WOOD = 4, LEAVES = 5,
        SAND = 120, COBBLE = 121, PLANKS = 122, TABLE = 123,
        COAL_ORE = 124, IRON_ORE = 125, WATER = 126, FURNACE = 127;
    private static final int MAGIC = 0x52425834;

    private long seed;
    private final Map<Long, Chunk> chunks = new HashMap<>();
    /** Modifications du joueur : clé chunk -> (index local -> bloc). */
    private final Map<Long, Map<Integer, Byte>> edits = new HashMap<>();
    private float[] savedPlayer;
    private float[] savedVitals; // vie, faim, heure du jour (absent dans les anciens mondes)

    public World(long seed) { this.seed = seed; }

    public static long key(int cx, int cz) { return ((long) cx << 32) | (cz & 0xffffffffL); }
    public synchronized long getSeed() { return seed; }
    public synchronized void reset(long newSeed) { seed = newSeed; chunks.clear(); edits.clear(); savedPlayer = null; savedVitals = null; }
    public synchronized float[] takeSavedPlayer() { float[] p = savedPlayer; savedPlayer = null; return p; }
    public synchronized float[] takeSavedVitals() { float[] v = savedVitals; savedVitals = null; return v; }

    // ---------- bruit déterministe ----------
    private static long mix(long h) {
        h ^= h >>> 33; h *= 0xff51afd7ed558ccdL; h ^= h >>> 33; h *= 0xc4ceb9fe1a85ec53L; h ^= h >>> 33; return h;
    }
    private double hash01(int x, int z, int salt) {
        long h = mix(seed * 31 + salt);
        h = mix(h ^ ((long) x * 0x9E3779B97F4A7C15L));
        h = mix(h ^ ((long) z * 0xC2B2AE3D27D4EB4FL));
        return (h >>> 11) * (1.0 / (1L << 53));
    }
    private double valueNoise(double x, double z, int salt) {
        int x0 = (int) Math.floor(x), z0 = (int) Math.floor(z);
        double fx = x - x0, fz = z - z0;
        fx = fx * fx * (3 - 2 * fx); fz = fz * fz * (3 - 2 * fz);
        double a = hash01(x0, z0, salt), b = hash01(x0 + 1, z0, salt);
        double c = hash01(x0, z0 + 1, salt), d = hash01(x0 + 1, z0 + 1, salt);
        return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fz;
    }
    private double fbm(double x, double z) {
        double v = 0, amp = 1, f = 1, norm = 0;
        for (int i = 0; i < 4; i++) { v += amp * valueNoise(x * f, z * f, i); norm += amp; amp *= .5; f *= 2; }
        return v / norm;
    }
    /** Hauteur du sol (dernier bloc solide) en (x,z). Fonction pure de la seed. */
    public int heightAt(int x, int z) {
        double n = fbm(x / 64.0, z / 64.0);
        int h = 22 + (int) Math.round((n - .5) * 2 * 20);
        return Math.max(3, Math.min(HEIGHT - 10, h));
    }
    private double h3(int x, int y, int z, int salt) { return hash01(x * 31 + y * 1009, z * 7 + y * 13, salt); }
    private double noise3(double x, double y, double z, int salt) {
        int x0 = (int) Math.floor(x), y0 = (int) Math.floor(y), z0 = (int) Math.floor(z);
        double fx = x - x0, fy = y - y0, fz = z - z0;
        fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy); fz = fz * fz * (3 - 2 * fz);
        double c00 = h3(x0, y0, z0, salt) + (h3(x0 + 1, y0, z0, salt) - h3(x0, y0, z0, salt)) * fx;
        double c10 = h3(x0, y0 + 1, z0, salt) + (h3(x0 + 1, y0 + 1, z0, salt) - h3(x0, y0 + 1, z0, salt)) * fx;
        double c01 = h3(x0, y0, z0 + 1, salt) + (h3(x0 + 1, y0, z0 + 1, salt) - h3(x0, y0, z0 + 1, salt)) * fx;
        double c11 = h3(x0, y0 + 1, z0 + 1, salt) + (h3(x0 + 1, y0 + 1, z0 + 1, salt) - h3(x0, y0 + 1, z0 + 1, salt)) * fx;
        double a = c00 + (c10 - c00) * fy, b = c01 + (c11 - c01) * fy;
        return a + (b - a) * fz;
    }
    /** Tunnels : intersection de deux surfaces de bruit 3D. Fonction pure de la seed. */
    private boolean isCave(int x, int y, int z) {
        double a = noise3(x / 14.0, y / 9.0, z / 14.0, 301);
        if (Math.abs(a - .5) > .045) return false;
        double b = noise3(x / 14.0 + 50, y / 9.0, z / 14.0 + 50, 302);
        return Math.abs(b - .5) <= .045;
    }
    private boolean isTree(int x, int z) { return hash01(x, z, 99) < 0.012; }

    // ---------- génération ----------
    private Chunk generate(int cx, int cz) {
        Chunk c = new Chunk(cx, cz);
        int x0 = cx * 16, z0 = cz * 16;
        for (int lx = 0; lx < 16; lx++) for (int lz = 0; lz < 16; lz++) {
            int top = heightAt(x0 + lx, z0 + lz);
            int wx = x0 + lx, wz = z0 + lz;
            for (int y = 0; y <= top; y++) {
                byte b = top <= SAND_LEVEL ? (y >= top - 3 ? SAND : STONE) : (y == top ? GRASS : (y >= top - 3 ? DIRT : STONE));
                {
                    if (y >= 5 && top > WATER_LEVEL + 1 && isCave(wx, y, wz)) continue; // caverne (air), parfois ouverte en surface
                    if (b == STONE && y >= 3) {
                        double h = hash01(wx + y * 131, wz, 400);
                        if (h < .012) b = COAL_ORE; else if (y <= 30 && h < .019) b = IRON_ORE;
                    }
                }
                c.set(lx, y, lz, b);
            }
            for (int y = top + 1; y <= WATER_LEVEL; y++) c.set(lx, y, lz, WATER);
        }
        // Arbres : on parcourt aussi les origines voisines pour que les feuilles traversent les bords de chunk.
        for (int tx = x0 - 2; tx < x0 + 18; tx++) for (int tz = z0 - 2; tz < z0 + 18; tz++) {
            if (!isTree(tx, tz)) continue;
            int g = heightAt(tx, tz);
            if (g <= SAND_LEVEL) continue;
            for (int y = g + 1; y <= g + 4; y++) put(c, tx, y, tz, WOOD, false);
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++)
                for (int y = g + 3; y <= g + 5; y++)
                    if (Math.abs(dx) + Math.abs(dz) + (y == g + 5 ? 1 : 0) <= 4)
                        put(c, tx + dx, y, tz + dz, LEAVES, true);
        }
        Map<Integer, Byte> e = edits.get(key(cx, cz));
        if (e != null) for (Map.Entry<Integer, Byte> en : e.entrySet()) {
            int i = en.getKey(); byte id = en.getValue();
            c.blocks[i] = id;
            int y = (i / 16) % HEIGHT; if (id != AIR && y > c.maxY) c.maxY = y;
        }
        return c;
    }
    private static void put(Chunk c, int wx, int y, int wz, byte id, boolean onlyAir) {
        int lx = wx - c.cx * 16, lz = wz - c.cz * 16;
        if (lx < 0 || lx > 15 || lz < 0 || lz > 15 || y < 0 || y >= HEIGHT) return;
        if (onlyAir && c.get(lx, y, lz) != AIR) return;
        c.set(lx, y, lz, id);
    }

    // ---------- accès ----------
    public synchronized Chunk loadChunk(int cx, int cz) {
        Chunk c = chunks.get(key(cx, cz));
        if (c == null) { c = generate(cx, cz); chunks.put(key(cx, cz), c); }
        return c;
    }
    public synchronized boolean isLoaded(int cx, int cz) { return chunks.containsKey(key(cx, cz)); }
    public synchronized List<Chunk> snapshot() { return new ArrayList<>(chunks.values()); }
    public synchronized void unloadFar(int pcx, int pcz, int radius) {
        int r2 = radius * radius;
        chunks.values().removeIf(c -> (c.cx - pcx) * (c.cx - pcx) + (c.cz - pcz) * (c.cz - pcz) > r2);
    }
    public synchronized byte get(int x, int y, int z) {
        if (y < 0 || y >= HEIGHT) return AIR;
        Chunk c = chunks.get(key(x >> 4, z >> 4));
        return c == null ? AIR : c.get(x & 15, y, z & 15);
    }
    /** Pour les collisions : chunk non chargé = solide (on ne traverse pas le vide). */
    public synchronized boolean solidAt(int x, int y, int z) {
        if (y < 0) return true;
        if (y >= HEIGHT) return false;
        Chunk c = chunks.get(key(x >> 4, z >> 4));
        if (c == null) return true;
        byte b = c.get(x & 15, y, z & 15);
        return b != AIR && b != WATER;
    }
    public synchronized boolean set(int x, int y, int z, byte id) {
        if (y < 0 || y >= HEIGHT) return false;
        int cx = x >> 4, cz = z >> 4;
        Chunk c = chunks.get(key(cx, cz));
        if (c == null) return false;
        int lx = x & 15, lz = z & 15;
        c.set(lx, y, lz, id);
        edits.computeIfAbsent(key(cx, cz), k -> new HashMap<>()).put(Chunk.idx(lx, y, lz), id);
        c.dirty = true;
        if (lx == 0) dirty(cx - 1, cz);
        if (lx == 15) dirty(cx + 1, cz);
        if (lz == 0) dirty(cx, cz - 1);
        if (lz == 15) dirty(cx, cz + 1);
        return true;
    }
    private void dirty(int cx, int cz) { Chunk n = chunks.get(key(cx, cz)); if (n != null) n.dirty = true; }
    public synchronized int surfaceAt(int x, int z) {
        Chunk c = chunks.get(key(x >> 4, z >> 4));
        if (c == null) return heightAt(x, z);
        for (int y = HEIGHT - 1; y >= 0; y--) if (c.get(x & 15, y, z & 15) != AIR) return y;
        return 0;
    }

    // ---------- sauvegarde : seed + modifications + position ----------
    public synchronized void save(File file, float px, float py, float pz) throws IOException { save(file, px, py, pz, 20f, 20f, .05f); }
    public synchronized void save(File file, float px, float py, float pz, float health, float food, float time) throws IOException {
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeInt(MAGIC); out.writeLong(seed);
            int n = 0; for (Map<Integer, Byte> m : edits.values()) n += m.size();
            out.writeInt(n);
            for (Map.Entry<Long, Map<Integer, Byte>> ce : edits.entrySet()) {
                int cx = (int) (ce.getKey() >> 32), cz = (int) (long) ce.getKey();
                for (Map.Entry<Integer, Byte> e : ce.getValue().entrySet()) {
                    out.writeInt(cx); out.writeInt(cz); out.writeInt(e.getKey()); out.writeByte(e.getValue());
                }
            }
            out.writeFloat(px); out.writeFloat(py); out.writeFloat(pz);
            out.writeFloat(health); out.writeFloat(food); out.writeFloat(time);
        }
    }
    /** Lit uniquement la seed d'un fichier de monde (null si illisible ou ancien format). */
    public static Long peekSeed(File file) {
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            return in.readInt() == MAGIC ? in.readLong() : null;
        } catch (IOException e) { return null; }
    }
    public synchronized boolean load(File file) {
        if (!file.exists()) return false;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(file)))) {
            if (in.readInt() != MAGIC) return false;
            long s = in.readLong(); int n = in.readInt();
            Map<Long, Map<Integer, Byte>> ed = new HashMap<>();
            for (int i = 0; i < n; i++) {
                int cx = in.readInt(), cz = in.readInt(), idx = in.readInt(); byte id = in.readByte();
                ed.computeIfAbsent(key(cx, cz), k -> new HashMap<>()).put(idx, id);
            }
            float[] p = {in.readFloat(), in.readFloat(), in.readFloat()};
            float[] v = null;
            try { v = new float[]{in.readFloat(), in.readFloat(), in.readFloat()}; } catch (IOException noVitals) { v = null; }
            reset(s); edits.putAll(ed); savedPlayer = p; savedVitals = v;
            return true;
        } catch (IOException e) { return false; }
    }
}
