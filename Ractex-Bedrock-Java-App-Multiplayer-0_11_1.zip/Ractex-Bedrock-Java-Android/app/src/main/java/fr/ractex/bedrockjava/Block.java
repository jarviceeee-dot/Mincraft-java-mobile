package fr.ractex.bedrockjava;

/** Basic engine block definition. IDs are internal to this prototype. */
public final class Block {
    public static final Block AIR = new Block(0, "air", 0f, 0f, 0f, 0f, false);
    public static final Block GRASS = new Block(1, "grass", 0.28f, 0.66f, 0.25f, 1f, true);
    public static final Block DIRT = new Block(2, "dirt", 0.48f, 0.30f, 0.16f, 1f, true);
    public static final Block STONE = new Block(3, "stone", 0.48f, 0.50f, 0.53f, 1f, true);

    public final int id;
    public final String name;
    public final float r, g, b, a;
    public final boolean solid;

    public Block(int id, String name, float r, float g, float b, float a, boolean solid) {
        this.id = id; this.name = name;
        this.r = r; this.g = g; this.b = b; this.a = a; this.solid = solid;
    }
}
