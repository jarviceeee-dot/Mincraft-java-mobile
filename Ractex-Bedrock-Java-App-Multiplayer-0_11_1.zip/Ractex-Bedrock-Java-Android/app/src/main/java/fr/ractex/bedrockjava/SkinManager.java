package fr.ractex.bedrockjava;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.view.View;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Skins du joueur : fichiers PNG au format Minecraft Java (64x64, ou 64x32 converti) rangés dans files/skins/.
 * Le skin choisi est mémorisé dans les préférences (clé « skin », vide = skin par défaut).
 */
final class SkinManager {
    static final String PREF = "skin";

    private SkinManager() {}

    static final class Skin {
        final Bitmap bmp; final boolean slim;
        Skin(Bitmap bmp, boolean slim) { this.bmp = bmp; this.slim = slim; }
    }

    static File dir(Context c) { File d = new File(c.getFilesDir(), "skins"); d.mkdirs(); return d; }

    /** Noms des fichiers de skins installés (triés). */
    static List<String> list(Context c) {
        List<String> r = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".png"));
        if (fs != null) { Arrays.sort(fs); for (File f : fs) r.add(f.getName()); }
        return r;
    }

    static Skin fromPixels(int[] px) { return new Skin(Bitmap.createBitmap(px, SkinUtil.W, SkinUtil.H, Bitmap.Config.ARGB_8888), SkinUtil.isSlim(px)); }

    /** Charge un skin installé ; skin par défaut si le nom est vide ou si le fichier est illisible. */
    static Skin load(Context c, String file) {
        if (file != null && !file.isEmpty()) {
            try {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inScaled = false;
                Bitmap b = BitmapFactory.decodeFile(new File(dir(c), file).getPath(), o);
                if (b != null) {
                    int[] px = new int[b.getWidth() * b.getHeight()]; b.getPixels(px, 0, b.getWidth(), 0, 0, b.getWidth(), b.getHeight());
                    int[] p64 = SkinUtil.to64(px, b.getWidth(), b.getHeight());
                    if (p64 != null) return fromPixels(p64);
                }
            } catch (Exception ignored) {}
        }
        return fromPixels(SkinUtil.defaultSkin());
    }

    /**
     * Copie un skin choisi par l'utilisateur dans files/skins/ (converti en 64x64).
     * Retourne le nom du fichier créé ; lève une IOException avec un message lisible si l'image n'est pas un skin.
     */
    static String importSkin(Context c, Uri uri, String displayName) throws IOException {
        Bitmap b;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("lecture impossible");
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inScaled = false;
            b = BitmapFactory.decodeStream(in, null, o);
        }
        if (b == null) throw new IOException("ce fichier n'est pas une image PNG");
        int w = b.getWidth(), h = b.getHeight();
        int[] px = new int[w * h]; b.getPixels(px, 0, w, 0, 0, w, h);
        int[] p64 = SkinUtil.to64(px, w, h);
        if (p64 == null) throw new IOException("taille " + w + "x" + h + " : un skin fait 64x64 ou 64x32");
        String base = displayName == null ? "skin" : displayName;
        if (base.toLowerCase().endsWith(".png")) base = base.substring(0, base.length() - 4);
        base = base.replaceAll("[\\\\/:*?\"<>|]", "_"); if (base.isEmpty()) base = "skin"; if (base.length() > 40) base = base.substring(0, 40);
        File dest = new File(dir(c), base + ".png"); int n = 2;
        while (dest.exists()) dest = new File(dir(c), base + " (" + n++ + ").png");
        try (FileOutputStream out = new FileOutputStream(dest)) {
            if (!Bitmap.createBitmap(p64, SkinUtil.W, SkinUtil.H, Bitmap.Config.ARGB_8888).compress(Bitmap.CompressFormat.PNG, 100, out)) throw new IOException("écriture impossible");
        }
        return dest.getName();
    }

    static String label(String file) { return file == null || file.isEmpty() ? "Skin par défaut" : file.substring(0, file.length() - 4); }

    // ------------------------------------------------------------------ aperçu 2D (face + dos)
    /** Vue qui dessine le personnage de face et de dos à partir des zones du skin, en pixels nets. */
    static final class Preview extends View {
        private Skin skin;
        private final Paint paint = new Paint();
        private final Rect src = new Rect(), dst = new Rect();
        Preview(Context c) { super(c); paint.setFilterBitmap(false); paint.setAntiAlias(false); }
        void setSkin(Skin s) { skin = s; invalidate(); }

        @Override protected void onDraw(Canvas cv) {
            if (skin == null) return;
            int k = Math.max(1, Math.min((getHeight() - 4) / 32, (getWidth() - 12) / 36));
            int totalW = (16 + 4 + 16) * k, ox = (getWidth() - totalW) / 2, oy = (getHeight() - 32 * k) / 2;
            figure(cv, ox, oy, k, true);
            figure(cv, ox + 20 * k, oy, k, false);
        }

        /** Dessine un personnage de 16 x 32 pixels de skin ; base puis couche externe pour chaque partie. */
        private void figure(Canvas cv, int ox, int oy, int k, boolean front) {
            int aw = skin.slim ? 3 : 4;
            int armBack = skin.slim ? 3 : 4;                       // la face du dos d'un bras commence 2d + w après son origine
            // tête (8x8) et chapeau
            part(cv, front ? 8 : 24, 8, 8, 8, ox + 4 * k, oy, k, 8, 8); part(cv, front ? 40 : 56, 8, 8, 8, ox + 4 * k, oy, k, 8, 8);
            // corps (8x12) et veste
            part(cv, front ? 20 : 32, 20, 8, 12, ox + 4 * k, oy + 8 * k, k, 8, 12); part(cv, front ? 20 : 32, 36, 8, 12, ox + 4 * k, oy + 8 * k, k, 8, 12);
            // bras : à gauche de l'image = bras droit du personnage vu de face, bras gauche vu de dos
            int lx = ox + (4 - aw) * k, rx = ox + 12 * k;
            if (front) {
                part(cv, 44, 20, aw, 12, lx, oy + 8 * k, k, aw, 12); part(cv, 44, 36, aw, 12, lx, oy + 8 * k, k, aw, 12);   // bras droit
                part(cv, 36, 52, aw, 12, rx, oy + 8 * k, k, aw, 12); part(cv, 52, 52, aw, 12, rx, oy + 8 * k, k, aw, 12);   // bras gauche
            } else {
                part(cv, 32 + 8 + armBack, 52, aw, 12, lx, oy + 8 * k, k, aw, 12); part(cv, 48 + 8 + armBack, 52, aw, 12, lx, oy + 8 * k, k, aw, 12); // bras gauche (dos)
                part(cv, 40 + 8 + armBack, 20, aw, 12, rx, oy + 8 * k, k, aw, 12); part(cv, 40 + 8 + armBack, 36, aw, 12, rx, oy + 8 * k, k, aw, 12); // bras droit (dos)
            }
            // jambes (4x12)
            int y = oy + 20 * k;
            if (front) {
                part(cv, 4, 20, 4, 12, ox + 4 * k, y, k, 4, 12); part(cv, 4, 36, 4, 12, ox + 4 * k, y, k, 4, 12);       // jambe droite
                part(cv, 20, 52, 4, 12, ox + 8 * k, y, k, 4, 12); part(cv, 4, 52, 4, 12, ox + 8 * k, y, k, 4, 12);      // jambe gauche
            } else {
                part(cv, 28, 52, 4, 12, ox + 4 * k, y, k, 4, 12); part(cv, 12, 52, 4, 12, ox + 4 * k, y, k, 4, 12);     // jambe gauche (dos)
                part(cv, 12, 20, 4, 12, ox + 8 * k, y, k, 4, 12); part(cv, 12, 36, 4, 12, ox + 8 * k, y, k, 4, 12);     // jambe droite (dos)
            }
        }
        private void part(Canvas cv, int sx, int sy, int sw, int sh, int dx, int dy, int k, int dw, int dh) {
            src.set(sx, sy, sx + sw, sy + sh); dst.set(dx, dy, dx + dw * k, dy + dh * k);
            cv.drawBitmap(skin.bmp, src, dst, paint);
        }
    }
}
