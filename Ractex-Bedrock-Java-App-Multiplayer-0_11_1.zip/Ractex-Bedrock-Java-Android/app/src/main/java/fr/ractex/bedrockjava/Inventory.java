package fr.ractex.bedrockjava;

/** Inventaire de survie : 36 cases (0-8 = barre d'objets, 9-35 = sac), piles de 64 (outils : 1, avec durabilité). */
final class Inventory {
    static final int SIZE = 36, MAX_STACK = 64;
    final int[] id = new int[SIZE];
    final int[] n = new int[SIZE];
    final int[] dur = new int[SIZE]; // durabilité restante (outils)

    /** Ajoute count objets (piles existantes d'abord, puis cases vides). Renvoie ce qui n'a pas pu rentrer. */
    int add(int item, int count) {
        if (item == 0) return 0;
        int max = Items.stackMax(item);
        for (int i = 0; i < SIZE && count > 0 && max > 1; i++) {
            if (id[i] == item && n[i] < max) { int k = Math.min(count, max - n[i]); n[i] += k; count -= k; }
        }
        for (int i = 0; i < SIZE && count > 0; i++) {
            if (id[i] == 0) { int k = Math.min(count, max); id[i] = item; n[i] = k; dur[i] = Items.maxDur(item); count -= k; }
        }
        return count;
    }
    /** true si count objets peuvent encore rentrer. */
    boolean canAdd(int item, int count) {
        int max = Items.stackMax(item), room = 0;
        for (int i = 0; i < SIZE; i++) { if (id[i] == item && max > 1) room += max - n[i]; else if (id[i] == 0) room += max; }
        return room >= count;
    }
    /** Nombre total d'un objet. */
    int count(int item) { int t = 0; for (int i = 0; i < SIZE; i++) if (id[i] == item) t += n[i]; return t; }
    /** Retire count objets au total (false et rien retiré s'il n'y en a pas assez). */
    boolean remove(int item, int count) {
        if (count(item) < count) return false;
        for (int i = SIZE - 1; i >= 0 && count > 0; i--) {
            if (id[i] != item) continue;
            int k = Math.min(count, n[i]); n[i] -= k; count -= k; if (n[i] == 0) clearSlot(i);
        }
        return true;
    }
    /** Retire 1 objet d'une case. */
    void take(int slot) { if (id[slot] != 0 && --n[slot] <= 0) clearSlot(slot); }
    /** Use un outil d'un point de durabilité ; il se brise à 0. Renvoie true s'il s'est brisé. */
    boolean useTool(int slot) {
        if (!Items.isTool(id[slot])) return false;
        if (--dur[slot] <= 0) { clearSlot(slot); return true; }
        return false;
    }
    /** Déplace / fusionne / échange deux cases. */
    void move(int a, int b) {
        if (a == b) return;
        int max = Items.stackMax(id[a]);
        if (id[a] != 0 && id[a] == id[b] && max > 1) {
            int k = Math.min(n[a], max - n[b]); n[b] += k; n[a] -= k; if (n[a] <= 0) clearSlot(a);
        } else {
            int ti = id[a], tn = n[a], td = dur[a];
            id[a] = id[b]; n[a] = n[b]; dur[a] = dur[b]; id[b] = ti; n[b] = tn; dur[b] = td;
        }
    }
    void clearSlot(int s) { id[s] = 0; n[s] = 0; dur[s] = 0; }

    String serialize() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < SIZE; i++) sb.append(i == 0 ? "" : ",").append(id[i]).append(':').append(n[i]).append(':').append(dur[i]);
        return sb.toString();
    }
    static Inventory parse(String s) {
        Inventory inv = new Inventory();
        if (s == null || s.isEmpty()) return inv;
        try {
            String[] p = s.split(",");
            for (int i = 0; i < SIZE && i < p.length; i++) {
                String[] q = p[i].split(":");
                int a = Integer.parseInt(q[0].trim()), c = Integer.parseInt(q[1].trim());
                if (a <= 0 || c <= 0) continue;
                inv.id[i] = a; inv.n[i] = Math.min(c, Items.stackMax(a));
                int d = q.length > 2 ? Integer.parseInt(q[2].trim()) : Items.maxDur(a);
                inv.dur[i] = Items.isTool(a) ? Math.max(1, Math.min(d, Items.maxDur(a))) : 0;
            }
        } catch (Exception ignored) {}
        return inv;
    }
}
