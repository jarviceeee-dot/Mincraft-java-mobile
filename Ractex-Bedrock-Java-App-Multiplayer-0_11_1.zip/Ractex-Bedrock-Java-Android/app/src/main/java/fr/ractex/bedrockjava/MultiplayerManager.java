package fr.ractex.bedrockjava;

import android.os.Handler;
import android.os.Looper;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;
import java.net.URI;
import java.util.UUID;

/**
 * Transport multijoueur Ractex.
 * Le relais WebSocket doit être déployé par l'administrateur du projet.
 * Les événements de monde devront ensuite être branchés au moteur World/WorldRenderer.
 */
public final class MultiplayerManager {
    public interface Listener {
        void onStatus(String status);
        void onRoomJoined(String code);
        void onPacket(JSONObject packet);
        void onError(String message);
    }

    private final Handler main = new Handler(Looper.getMainLooper());
    private WebSocketClient socket;
    private Listener listener;
    private String roomCode;
    private String playerName = "Joueur";
    private String relayUrl = "wss://CHANGE-ME.example/ws";

    public void setRelayUrl(String url) { relayUrl = url == null ? "" : url.trim(); }
    public boolean isConnected() { return socket != null && socket.isOpen(); }
    public String getRoomCode() { return roomCode; }

    public void createRoom(String name, Listener callback) {
        connectAndSend("create", "", name, callback);
    }

    public void joinRoom(String code, String name, Listener callback) {
        connectAndSend("join", code == null ? "" : code.trim().toUpperCase(), name, callback);
    }

    private void connectAndSend(String action, String code, String name, Listener callback) {
        close();
        listener = callback;
        playerName = name == null || name.trim().isEmpty() ? "Joueur" : name.trim();
        if (!relayUrl.startsWith("wss://")) {
            notifyError("Configure d'abord l'adresse WSS du relais Ractex dans multiplayer-config.json.");
            return;
        }
        try {
            socket = new WebSocketClient(new URI(relayUrl)) {
                @Override public void onOpen(ServerHandshake handshake) {
                    JSONObject msg = new JSONObject();
                    try {
                        msg.put("type", action);
                        msg.put("code", code);
                        msg.put("name", playerName);
                        send(msg.toString());
                    } catch (Exception e) { notifyError("Impossible d'envoyer la demande."); }
                    notifyStatus("Connexion au service Ractex…");
                }
                @Override public void onMessage(String raw) {
                    try {
                        JSONObject packet = new JSONObject(raw);
                        String type = packet.optString("type");
                        if ("joined".equals(type)) {
                            roomCode = packet.optString("code");
                            main.post(() -> { if (listener != null) listener.onRoomJoined(roomCode); });
                        }
                        main.post(() -> { if (listener != null) listener.onPacket(packet); });
                    } catch (Exception ignored) { }
                }
                @Override public void onClose(int code, String reason, boolean remote) {
                    notifyStatus("Déconnecté du service multijoueur.");
                }
                @Override public void onError(Exception ex) {
                    notifyError("Connexion impossible : vérifie l'adresse du relais et Internet.");
                }
            };
            socket.connect();
            notifyStatus("Connexion…");
        } catch (Exception e) { notifyError("Adresse du relais invalide."); }
    }

    public void sendChat(String message) {
        if (!isConnected() || message == null || message.trim().isEmpty()) return;
        JSONObject packet = new JSONObject();
        try {
            packet.put("type", "chat");
            packet.put("name", playerName);
            packet.put("message", message.trim());
            socket.send(packet.toString());
        } catch (Exception ignored) { }
    }

    /** Enveloppe générique pour les futurs événements de monde (blocs, position, inventaire). */
    public void sendWorldEvent(String event, JSONObject data) {
        if (!isConnected()) return;
        JSONObject packet = new JSONObject();
        try {
            packet.put("type", "world");
            packet.put("event", event);
            packet.put("data", data == null ? new JSONObject() : data);
            socket.send(packet.toString());
        } catch (Exception ignored) { }
    }

    public void close() {
        WebSocketClient old = socket;
        socket = null;
        roomCode = null;
        if (old != null) try { old.close(); } catch (Exception ignored) { }
    }

    private void notifyStatus(String s) { main.post(() -> { if (listener != null) listener.onStatus(s); }); }
    private void notifyError(String s) { main.post(() -> { if (listener != null) listener.onError(s); }); }
}
