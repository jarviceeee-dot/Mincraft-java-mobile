package fr.ractex.bedrockjava;

import java.util.Arrays;

/**
 * Modèle 3D du joueur (disposition des skins Minecraft Java 64x64), en Java pur.
 * Chaque partie est une liste de sommets (x, y, z, u, v, ombrage), en blocs, centrée sur son point de pivot.
 * Le personnage regarde vers +Z, les pieds en y = 0, 1,8 bloc de haut.
 */
final class PlayerModel {
    static final int HEAD = 0, BODY = 1, RARM = 2, LARM = 3, RLEG = 4, LLEG = 5, PARTS = 6;
    static final float S = 1.8f / 32f;   // un pixel de skin en blocs
    static final int STRIDE = 6;

    private PlayerModel() {}

    /** Pivot de chaque partie, en pixels de skin, relatif aux pieds (axe vertical) au centre du joueur. */
    static float[] pivot(int part, boolean slim) {
        float arm = slim ? 5.5f : 6f;
        switch (part) {
            case HEAD: return new float[]{0, 24, 0};
            case BODY: return new float[]{0, 18, 0};
            case RARM: return new float[]{-arm, 22, 0};
            case LARM: return new float[]{arm, 22, 0};
            case RLEG: return new float[]{-2, 12, 0};
            default:   return new float[]{2, 12, 0};
        }
    }

    /** Sommets d'une partie : couche de base puis couche externe (chapeau, veste, manches, pantalon). */
    static float[] mesh(int part, boolean slim) {
        float aw = slim ? 3 : 4;
        switch (part) {
            case HEAD: return both(8, 8, 8, 0, 0, 32, 0, 0, 4, 0, .5f);
            case BODY: return both(8, 12, 4, 16, 16, 16, 32, 0, 0, 0, .25f);
            case RARM: return both(aw, 12, 4, 40, 16, 40, 32, 0, -4, 0, .25f);
            case LARM: return both(aw, 12, 4, 32, 48, 48, 48, 0, -4, 0, .25f);
            case RLEG: return both(4, 12, 4, 0, 16, 0, 32, 0, -6, 0, .25f);
            default:   return both(4, 12, 4, 16, 48, 0, 48, 0, -6, 0, .25f);
        }
    }
    private static float[] both(float w, float h, float d, int u, int v, int ou, int ov, float cx, float cy, float cz, float grow) {
        float[] a = box(w, h, d, u, v, 0, cx, cy, cz), b = box(w, h, d, ou, ov, grow, cx, cy, cz);
        float[] r = Arrays.copyOf(a, a.length + b.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    /**
     * Boîte w x h x d dont le patron de skin commence en (u,v), centrée en (cx,cy,cz) (en pixels),
     * agrandie de « grow » pixels de chaque côté. 36 sommets.
     */
    static float[] box(float w, float h, float d, int u, int v, float grow, float cx, float cy, float cz) {
        float hx = w / 2 + grow, hy = h / 2 + grow, hz = d / 2 + grow;
        float[] o = new float[36 * STRIDE]; int[] n = {0};
        // Chaque face est vue de l'extérieur : bas-gauche, bas-droite, haut-droite, haut-gauche. Patron : [droite][face][gauche][dos].
        // face (+Z)
        quad(o, n, u + d, v + d, w, h, 0.80f, cx - hx, cy - hy, cz + hz, cx + hx, cy - hy, cz + hz, cx + hx, cy + hy, cz + hz, cx - hx, cy + hy, cz + hz);
        // dos (-Z)
        quad(o, n, u + 2 * d + w, v + d, w, h, 0.80f, cx + hx, cy - hy, cz - hz, cx - hx, cy - hy, cz - hz, cx - hx, cy + hy, cz - hz, cx + hx, cy + hy, cz - hz);
        // côté droit du personnage (-X)
        quad(o, n, u, v + d, d, h, 0.65f, cx - hx, cy - hy, cz - hz, cx - hx, cy - hy, cz + hz, cx - hx, cy + hy, cz + hz, cx - hx, cy + hy, cz - hz);
        // côté gauche (+X)
        quad(o, n, u + d + w, v + d, d, h, 0.65f, cx + hx, cy - hy, cz + hz, cx + hx, cy - hy, cz - hz, cx + hx, cy + hy, cz - hz, cx + hx, cy + hy, cz + hz);
        // dessus (+Y), bord haut du patron = arrière
        quad(o, n, u + d, v, w, d, 1.00f, cx - hx, cy + hy, cz + hz, cx + hx, cy + hy, cz + hz, cx + hx, cy + hy, cz - hz, cx - hx, cy + hy, cz - hz);
        // dessous (-Y), bord haut du patron = avant
        quad(o, n, u + d + w, v, w, d, 0.50f, cx - hx, cy - hy, cz - hz, cx + hx, cy - hy, cz - hz, cx + hx, cy - hy, cz + hz, cx - hx, cy - hy, cz + hz);
        return o;
    }

    private static void quad(float[] o, int[] n, float pu, float pv, float pw, float ph, float shade,
                             float ax, float ay, float az, float bx, float by, float bz, float cx, float cy, float cz, float dx, float dy, float dz) {
        float u0 = pu / 64f, u1 = (pu + pw) / 64f, v0 = pv / 64f, v1 = (pv + ph) / 64f;
        vtx(o, n, ax, ay, az, u0, v1, shade); vtx(o, n, bx, by, bz, u1, v1, shade); vtx(o, n, cx, cy, cz, u1, v0, shade);
        vtx(o, n, ax, ay, az, u0, v1, shade); vtx(o, n, cx, cy, cz, u1, v0, shade); vtx(o, n, dx, dy, dz, u0, v0, shade);
    }
    private static void vtx(float[] o, int[] n, float x, float y, float z, float u, float v, float s) {
        int i = n[0]; o[i] = x * S; o[i + 1] = y * S; o[i + 2] = z * S; o[i + 3] = u; o[i + 4] = v; o[i + 5] = s; n[0] = i + STRIDE;
    }
}
