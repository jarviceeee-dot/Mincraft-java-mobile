package fr.ractex.bedrockjava;

/**
 * Outils de skins au format Minecraft Java (PNG 64x64 ou 64x32), en Java pur (pixels ARGB dans des int[]),
 * donc sans dépendance à Android : conversion 64x32 -> 64x64, détection des bras fins (Alex), skin par défaut.
 */
final class SkinUtil {
    static final int W = 64, H = 64;

    private SkinUtil() {}

    /**
     * Convertit une image de skin en 64x64 : accepte 64x64, 64x32 (ancien format) et les skins HD (multiples de 64, réduits).
     * Retourne null si la taille n'est pas celle d'un skin.
     */
    static int[] to64(int[] src, int w, int h) {
        if (src == null || w < 64 || w % 64 != 0) return null;
        if (h != w && h * 2 != w) return null;
        if (w > 64) { // skin HD : on prend un pixel sur « f »
            int f = w / 64, nh = h / f;
            int[] s = new int[64 * nh];
            for (int y = 0; y < nh; y++) for (int x = 0; x < 64; x++) s[y * 64 + x] = src[(y * f) * w + x * f];
            return to64(s, 64, nh);
        }
        int[] o = new int[W * H];
        if (h == 64) { System.arraycopy(src, 0, o, 0, W * H); return o; }
        System.arraycopy(src, 0, o, 0, W * 32); // 64x32 : moitié haute telle quelle
        mirrorBox(o, 0, 16, 16, 48, 4, 12, 4);   // jambe gauche = jambe droite en miroir
        mirrorBox(o, 40, 16, 32, 48, 4, 12, 4);  // bras gauche = bras droit en miroir
        return o;
    }

    /** Copie en miroir une « boîte » du patron de skin (w x h x d pixels) de (sx,sy) vers (dx,dy). */
    private static void mirrorBox(int[] p, int sx, int sy, int dx, int dy, int w, int h, int d) {
        mirror(p, sx + d, sy, dx + d, dy, w, d);                    // dessus
        mirror(p, sx + d + w, sy, dx + d + w, dy, w, d);            // dessous
        mirror(p, sx + d + w, sy + d, dx, dy + d, d, h);            // côté droit <- côté gauche de la source
        mirror(p, sx + d, sy + d, dx + d, dy + d, w, h);            // face
        mirror(p, sx, sy + d, dx + d + w, dy + d, d, h);            // côté gauche <- côté droit de la source
        mirror(p, sx + d + w + d, sy + d, dx + d + w + d, dy + d, w, h); // dos
    }
    private static void mirror(int[] p, int sx, int sy, int dx, int dy, int w, int h) {
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) p[(dy + y) * W + dx + x] = p[(sy + y) * W + sx + (w - 1 - x)];
    }

    /** Bras fins (3 px, modèle « Alex ») : la 4e colonne des deux bras est entièrement transparente. */
    static boolean isSlim(int[] p) {
        if (p == null || p.length < W * H) return false;
        return colTransparent(p, 47, 20) && colTransparent(p, 55, 20) && colTransparent(p, 39, 52) && colTransparent(p, 47, 52);
    }
    private static boolean colTransparent(int[] p, int x, int y0) {
        for (int y = y0; y < y0 + 12; y++) if ((p[y * W + x] >>> 24) != 0) return false;
        return true;
    }

    // ------------------------------------------------------------ skin par défaut
    private static final int SKIN = 0xFFC8946A, HAIR = 0xFF4A2E1A, SHIRT = 0xFF1AA6A6, PANTS = 0xFF3B3FA0, SHOE = 0xFF6E6E6E;

    /** Petit personnage de départ (dessiné en code, aucune ressource externe). */
    static int[] defaultSkin() {
        int[] p = new int[W * H];
        // Tête (0,0) + chapeau (32,0) vide
        box(p, 0, 0, 8, 8, 8, SKIN);
        rect(p, 8, 0, 8, 8, HAIR);                       // dessus = cheveux
        rect(p, 8, 8, 8, 2, HAIR); rect(p, 0, 8, 8, 2, HAIR); rect(p, 16, 8, 8, 2, HAIR); rect(p, 24, 8, 8, 8, HAIR); // front, côtés, nuque
        rect(p, 9, 12, 2, 1, 0xFFFFFFFF); rect(p, 13, 12, 2, 1, 0xFFFFFFFF);          // yeux
        rect(p, 9, 12, 1, 1, 0xFF3A3A9A); rect(p, 14, 12, 1, 1, 0xFF3A3A9A);          // pupilles
        rect(p, 11, 14, 2, 1, 0xFF8A5A3A);                                           // bouche
        // Corps (16,16)
        box(p, 16, 16, 8, 12, 4, SHIRT);
        // Bras droit (40,16) et gauche (32,48) : manche courte
        box(p, 40, 16, 4, 12, 4, SKIN); armSleeve(p, 40, 16);
        box(p, 32, 48, 4, 12, 4, SKIN); armSleeve(p, 32, 48);
        // Jambes : droite (0,16), gauche (16,48)
        box(p, 0, 16, 4, 12, 4, PANTS); shoes(p, 0, 16);
        box(p, 16, 48, 4, 12, 4, PANTS); shoes(p, 16, 48);
        return p;
    }
    private static void armSleeve(int[] p, int u, int v) { // 4 px de manche, sur les 4 côtés (d=4,w=4)
        rect(p, u + 4, v + 4, 4, 4, SHIRT); rect(p, u, v + 4, 4, 4, SHIRT); rect(p, u + 8, v + 4, 4, 4, SHIRT); rect(p, u + 12, v + 4, 4, 4, SHIRT);
    }
    private static void shoes(int[] p, int u, int v) {
        rect(p, u + 4, v + 4 + 9, 4, 3, SHOE); rect(p, u, v + 4 + 9, 4, 3, SHOE); rect(p, u + 8, v + 4 + 9, 4, 3, SHOE); rect(p, u + 12, v + 4 + 9, 4, 3, SHOE);
        rect(p, u + 8, v, 4, 4, SHOE); // semelle
    }
    /** Remplit toutes les faces du patron d'une boîte w x h x d dont le coin est en (u,v). */
    private static void box(int[] p, int u, int v, int w, int h, int d, int c) {
        rect(p, u + d, v, w, d, c); rect(p, u + d + w, v, w, d, c);
        rect(p, u, v + d, d, h, c); rect(p, u + d, v + d, w, h, c); rect(p, u + d + w, v + d, d, h, c); rect(p, u + 2 * d + w, v + d, w, h, c);
    }
    private static void rect(int[] p, int x, int y, int w, int h, int c) {
        for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) p[j * W + i] = c;
    }
}
