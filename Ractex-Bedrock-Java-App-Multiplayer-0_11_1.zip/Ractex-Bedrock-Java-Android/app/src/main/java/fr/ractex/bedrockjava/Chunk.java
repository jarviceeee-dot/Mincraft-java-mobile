package fr.ractex.bedrockjava;

import java.nio.FloatBuffer;

/** Colonne 16 x HEIGHT x 16 blocs + maillage GL. Coordonnées locales [0..15]. */
public final class Chunk {
    public static final int SIZE = 16;
    public final int cx, cz;
    public final byte[] blocks = new byte[SIZE * World.HEIGHT * SIZE];
    public volatile boolean dirty = true;   // maillage à reconstruire
    public int maxY = 0;                    // plus haut bloc non vide (borne de boucle)
    public FloatBuffer mesh;                // x,y,z,u,v,shade
    public int vertexCount;

    public Chunk(int cx, int cz) { this.cx = cx; this.cz = cz; }
    public static int idx(int x, int y, int z) { return (x * World.HEIGHT + y) * SIZE + z; }
    public byte get(int x, int y, int z) { return blocks[idx(x, y, z)]; }
    public void set(int x, int y, int z, byte id) {
        blocks[idx(x, y, z)] = id;
        if (id != World.AIR && y > maxY) maxY = y;
    }
}
