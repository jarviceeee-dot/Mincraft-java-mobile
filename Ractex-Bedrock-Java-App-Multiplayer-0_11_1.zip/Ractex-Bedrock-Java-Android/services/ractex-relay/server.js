// Ractex Multiplayer Relay — prototype de service WebSocket
// Node.js 20+ : npm install && npm start
// En production, place ce service derrière un proxy TLS (WSS), ajoute une authentification
// et une base de données pour les serveurs permanents.
const http = require("http");
const { WebSocketServer, WebSocket } = require("ws");
const crypto = require("crypto");

const PORT = Number(process.env.PORT || 8080);
const rooms = new Map();
const server = http.createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, {"content-type":"application/json"});
    return res.end(JSON.stringify({ok:true, service:"Ractex Relay", rooms:rooms.size}));
  }
  if (req.url === "/servers") {
    // Catalogue public : compléter avec les serveurs dédiés réellement déployés.
    res.writeHead(200, {"content-type":"application/json","access-control-allow-origin":"*"});
    return res.end(JSON.stringify({servers:[]}));
  }
  res.writeHead(404); res.end("Not found");
});
const wss = new WebSocketServer({server, path:"/ws", maxPayload:16 * 1024});
function code() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function broadcast(room, obj, except) {
  for (const peer of room.clients) if (peer !== except) send(peer, obj);
}
wss.on("connection", ws => {
  ws.room = null;
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws,{type:"error",message:"JSON invalide"}); }
    if (msg.type === "create" || msg.type === "join") {
      let id = msg.type === "create" ? code() : String(msg.code || "").toUpperCase();
      if (msg.type === "create") {
        while (rooms.has(id)) id = code();
        rooms.set(id,{clients:new Set(),createdAt:Date.now()});
      }
      const room = rooms.get(id);
      if (!room) return send(ws,{type:"error",message:"Salon introuvable"});
      if (room.clients.size >= 8) return send(ws,{type:"error",message:"Salon complet (8 joueurs maximum)"});
      ws.room = id; ws.playerName = String(msg.name || "Joueur").slice(0,20);
      room.clients.add(ws);
      send(ws,{type:"joined",code:id,players:room.clients.size});
      broadcast(room,{type:"player_joined",name:ws.playerName,players:room.clients.size},ws);
      return;
    }
    const room = ws.room && rooms.get(ws.room);
    if (!room) return send(ws,{type:"error",message:"Rejoins un salon avant d'envoyer des données"});
    if (msg.type === "chat") {
      const message = String(msg.message || "").slice(0,240);
      if (message) broadcast(room,{type:"chat",name:ws.playerName,message},null);
    } else if (msg.type === "world") {
      // Relais uniquement : le moteur devra valider et appliquer les événements.
      broadcast(room,{type:"world",event:String(msg.event || "").slice(0,40),data:msg.data || {}},ws);
    }
  });
  ws.on("close", () => {
    if (!ws.room) return;
    const room = rooms.get(ws.room);
    if (!room) return;
    room.clients.delete(ws);
    broadcast(room,{type:"player_left",name:ws.playerName || "Joueur",players:room.clients.size},null);
    if (room.clients.size === 0) rooms.delete(ws.room);
  });
});
server.listen(PORT,"0.0.0.0",() => console.log(`Ractex relay listening on ${PORT}`));
