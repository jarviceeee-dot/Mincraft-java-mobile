# Service multijoueur Ractex (prototype)

## Démarrer le relais
- Installer Node.js 20 ou supérieur sur un serveur.
- Dans ce dossier : `npm install`, puis `npm start`.
- Le service écoute sur le port `8080`, endpoint WebSocket `/ws`.
- En production, configurer un nom de domaine et un proxy TLS (WSS). Ne pas exposer le WebSocket non chiffré sur Internet.

## Important
Ce relais crée des salons temporaires (8 joueurs maximum) et relaie le chat / les événements génériques.
Il ne sauvegarde pas encore les mondes et n'héberge pas encore un serveur de jeu permanent.
Le moteur Ractex doit encore connecter `World` / `WorldRenderer` aux événements `world` et valider côté serveur les modifications de blocs, positions et inventaires.
Pour les serveurs permanents, il faudra ajouter un processus de monde dédié, une base de données et l'authentification.
