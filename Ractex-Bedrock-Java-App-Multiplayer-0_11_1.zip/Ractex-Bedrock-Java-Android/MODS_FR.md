# Mods Ractex

## Ce qui est possible (et ce qui ne l'est pas)
Ractex n'est pas Minecraft : c'est un moteur indépendant. Un mod Minecraft Java (Forge/Fabric) est du code compilé contre les classes de Minecraft ; ce code ne peut pas tourner ici (et Android n'exécute pas les .jar tels quels). Ractex **importe donc le contenu** des mods, pas leur code :

- **Blocs cubiques** des mods Minecraft Java (.jar / .zip) : textures, noms (lang), faces haut/côtés/bas.
  Modèles reconnus : `cube_all`, `cube_column`, `cube_bottom_top`, `cube_top`, `orientable`, `cube`.
  Ignorés : escaliers, dalles, machines, objets, mobs, dimensions, recettes, tout le code.
  Les textures vanilla référencées par un mod (`minecraft:block/...`) ne sont pas dans le jar : damier violet.
- **Mods Ractex** (.zip avec `mod.json`) : voir ci-dessous.

## Lire le code d'un mod
Menu **Mods** → touche un mod installé : tu vois tous ses fichiers. Les `.class` (le vrai code Java compilé du mod) sont affichés en bytecode lisible, les `.json`, `.toml`, `.java`, `.txt`… en texte. On peut **lire** ce code, pas l'**exécuter** : il appelle des classes de Minecraft (`net.minecraft...`) qui n'existent pas dans Ractex.

## Installer un mod
Menu principal → **Mods** → **Ajouter un mod** → choisis le .zip ou .jar. Les blocs apparaissent dans le **Sac** (page 2, 3... si besoin). Les mods sont copiés dans le stockage interne de l'appli. Les ids de blocs sont mémorisés (`ids.json`) : tes mondes gardent leurs blocs même si tu ajoutes d'autres mods ensuite. Limite : 122 blocs de mods au total, 1000 textures.

## Format d'un mod Ractex
```
mon_mod.zip
├─ mod.json
└─ textures/
   ├─ rubis.png
   └─ ...
```
```json
{
  "id": "monmod", "name": "Mon mod", "version": "1.0",
  "blocks": [
    { "id": "rubis", "name": "Bloc de rubis", "texture": "textures/rubis.png" },
    { "id": "colonne", "name": "Colonne", "top": "textures/haut.png", "side": "textures/cote.png", "bottom": "textures/haut.png" }
  ]
}
```
Textures PNG 16×16 (les autres tailles sont réduites en 16×16 ; une image plus haute que large est prise comme animation, première image).

## Exemples fournis (dossier `exemples/`)
- `exemple_mod_ractex.zip` : 3 blocs (rubis, or, colonne).
- `exemple_mod_minecraft.jar` : faux mod Fabric pour tester l'import (2 cubes + 1 colonne).

## Limites actuelles
Les blocs de mods se posent mais ne se génèrent pas dans le terrain. Pas d'API de code (scripts) pour l'instant. Un bloc transparent (verre) cache encore les faces voisines.
