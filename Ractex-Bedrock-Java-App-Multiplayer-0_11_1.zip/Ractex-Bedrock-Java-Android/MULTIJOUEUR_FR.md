# Multijoueur Ractex — étape 1 (0.11)

Cette mise à jour prépare le transport multijoueur :
- permissions Android Internet / état réseau ;
- client WebSocket Java ;
- création et entrée dans un salon par code ;
- relais Node.js pour salons temporaires, chat et événements génériques ;
- endpoint `/servers` réservé au futur catalogue des serveurs permanents.

## Ce qui fonctionne dans cette base
Le code client et le relais sont fournis. Le relais doit être déployé et son URL WSS configurée avant toute connexion réelle.

## Ce qui n'est pas encore terminé
- Le relais n'est pas hébergé par OpenAI ni activé automatiquement.
- Les salons sont temporaires : ils disparaissent lorsque tous les joueurs quittent.
- Le catalogue `/servers` est vide.
- Le monde, les chunks, les blocs, la position et l'inventaire ne sont pas encore synchronisés avec le moteur. `MultiplayerManager.sendWorldEvent()` est le point d'entrée prévu.
- Il n'y a pas encore de compte joueur ni d'authentification. Ne publie pas ce prototype tel quel.

## Sécurité
Utiliser uniquement `wss://` en ligne, ajouter une authentification et valider côté serveur chaque action de jeu avant une mise en production.
