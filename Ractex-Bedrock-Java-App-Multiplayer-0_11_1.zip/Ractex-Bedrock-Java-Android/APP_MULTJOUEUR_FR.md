# Multijoueur intégré à l'application — 0.11.1

L'écran d'accueil contient maintenant un bouton « Multijoueur en ligne » avec :
- Créer un salon ;
- Rejoindre avec un code ;
- Configurer l'adresse WSS ;
- Vérifier l'état et se déconnecter.

Aucune application terminal n'est nécessaire pour utiliser ces commandes depuis l'interface.
Limite : l'application ne peut pas créer à elle seule un service cloud public permanent. Il faut d'abord déployer le relais Node.js sur un hébergeur et saisir son adresse WSS dans l'écran de configuration.
Les mondes persistants, le catalogue de serveurs dédiés et la synchronisation des blocs/joueurs/inventaires restent à développer.
