package fr.ractex.bedrockjava;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Registre de blocs (de base + mods) et atlas de textures dynamique.
 *
 * Deux sortes de mods sont lues dans files/mods/ :
 *  - mod Ractex (.zip avec mod.json) : blocs décrits en JSON + textures PNG ;
 *  - mod Minecraft Java (.jar/.zip avec assets/) : on importe seulement les blocs cubiques (modèles cube_all, cube_column,
 *    cube_bottom_top, cube...), avec leurs textures et leurs noms. Le code Java du mod n'est jamais exécuté.
 */
final class ModRegistry {
    static final int COLS = 16, MISSING_TILE = 15, FIRST_MOD_TILE = 32, FIRST_MOD_ID = 6, MAX_ID = 127, MOD_MAX_ID = 119, MAX_TILES = 1000;

    static final class BlockDef {
        final int id; final String key, name, mod; final int[] faces; // faces = {haut, bas, côtés}
        BlockDef(int id, String key, String name, String mod, int top, int bottom, int side) {
            this.id = id; this.key = key; this.name = name; this.mod = mod; this.faces = new int[]{top, bottom, side};
        }
    }
    static final class ModInfo {
        String file, name = "", version = "", kind = ""; int blocks, skipped; String error;
    }

    private static final List<Bitmap> modTiles = new ArrayList<>();
    private static final List<ModInfo> mods = new ArrayList<>();
    private static volatile BlockDef[] byId = new BlockDef[MAX_ID + 1];
    private static volatile List<Integer> ids = Collections.emptyList();
    private static Bitmap baseAtlas, atlas, extraAtlas;
    private static volatile int rows = 1;
    private static final int[] FALLBACK = {7, 7, 7}, MISSING = {MISSING_TILE, MISSING_TILE, MISSING_TILE};

    private ModRegistry() {}

    // ------------------------------------------------------------------ API
    static synchronized void init(Context c) { if (atlas == null) reload(c); }

    static File modsDir(Context c) { File d = new File(c.getFilesDir(), "mods"); d.mkdirs(); return d; }

    /** Faces {haut, bas, côtés} d'un bloc ; tuile « manquante » (damier) si le mod du bloc n'est plus installé. */
    static int[] faces(int id) {
        if (id < 0 || id > MAX_ID) return MISSING;
        BlockDef d = byId[id];
        if (d != null) return d.faces;
        return id >= FIRST_MOD_ID ? MISSING : FALLBACK;
    }
    static boolean has(int id) { return id > 0 && id <= MAX_ID && byId[id] != null; }
    static String name(int id) { BlockDef d = (id > 0 && id <= MAX_ID) ? byId[id] : null; return d != null ? d.name : (id >= FIRST_MOD_ID ? "Bloc inconnu" : ""); }
    /** Tous les blocs posables, dans l'ordre (base puis mods). */
    static List<Integer> allIds() { return ids; }
    static synchronized List<ModInfo> mods() { return new ArrayList<>(mods); }
    static synchronized Bitmap atlas() { return atlas; }
    static int rows() { return rows; }
    static synchronized Bitmap tile(int t) {
        int x = (t % COLS) * 16, y = (t / COLS) * 16;
        if (atlas == null || y + 16 > atlas.getHeight()) return Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888);
        return Bitmap.createBitmap(atlas, x, y, 16, 16);
    }

    // ------------------------------------------------------------ chargement
    static synchronized void reload(Context c) {
        modTiles.clear(); mods.clear();
        BlockDef[] arr = new BlockDef[MAX_ID + 1];
        List<Integer> list = new ArrayList<>();
        addBase(arr, list, World.GRASS, "grass", "Herbe", 0, 2, 1);
        addBase(arr, list, World.DIRT, "dirt", "Terre", 2, 2, 2);
        addBase(arr, list, World.STONE, "stone", "Pierre", 3, 3, 3);
        addBase(arr, list, World.WOOD, "wood", "Bois", 5, 5, 4);
        addBase(arr, list, World.LEAVES, "leaves", "Feuilles", 6, 6, 6);
        addBase(arr, list, World.SAND, "sand", "Sable", 8, 8, 8);
        addBase(arr, list, World.COBBLE, "cobblestone", "Pierre taillée", 9, 9, 9);
        addBase(arr, list, World.PLANKS, "planks", "Planches", 7, 7, 7);
        addBase(arr, list, World.TABLE, "crafting_table", "Table de fabrication", 16, 7, 17);

        JSONObject idMap = loadIds(c);
        File[] files = modsDir(c).listFiles((d, n) -> n.endsWith(".zip") || n.endsWith(".jar"));
        if (files == null) files = new File[0];
        Arrays.sort(files);
        for (File f : files) {
            ModInfo info = new ModInfo(); info.file = f.getName(); info.name = baseName(f.getName());
            try (ZipFile z = new ZipFile(f)) {
                Loader l = new Loader(z, info, arr, list, idMap);
                if (z.getEntry("mod.json") != null) l.loadRactex(); else l.loadMinecraft();
            } catch (Exception e) { info.error = e.getClass().getSimpleName() + (e.getMessage() != null ? " : " + e.getMessage() : ""); }
            mods.add(info);
        }
        saveIds(c, idMap);
        byId = arr; ids = Collections.unmodifiableList(list);
        buildAtlas(c);
    }

    private static void addBase(BlockDef[] arr, List<Integer> list, int id, String key, String name, int top, int bottom, int side) {
        arr[id] = new BlockDef(id, "ractex:" + key, name, "Ractex", top, bottom, side); list.add(id);
    }

    private static JSONObject loadIds(Context c) {
        File f = new File(modsDir(c), "ids.json");
        try { return new JSONObject(new String(readAll(new java.io.FileInputStream(f)), StandardCharsets.UTF_8)); }
        catch (Exception e) { return new JSONObject(); }
    }
    private static void saveIds(Context c, JSONObject o) {
        try (FileOutputStream out = new FileOutputStream(new File(modsDir(c), "ids.json"))) { out.write(o.toString().getBytes(StandardCharsets.UTF_8)); }
        catch (Exception ignored) {}
    }

    private static void buildAtlas(Context c) {
        if (baseAtlas == null) {
            try (InputStream in = c.getAssets().open("atlas.png")) {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inScaled = false;
                baseAtlas = BitmapFactory.decodeStream(in, null, o);
            } catch (Exception e) { baseAtlas = null; }
            if (baseAtlas == null) baseAtlas = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888);
        }
        if (extraAtlas == null) {
            try (InputStream in = c.getAssets().open("atlas_extra.png")) {
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inScaled = false;
                extraAtlas = BitmapFactory.decodeStream(in, null, o);
            } catch (Exception e) { extraAtlas = null; }
        }
        int total = FIRST_MOD_TILE + modTiles.size();
        rows = Math.max(1, (total + COLS - 1) / COLS);
        Bitmap a = Bitmap.createBitmap(COLS * 16, rows * 16, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(a); Paint p = new Paint(); p.setFilterBitmap(false); p.setAntiAlias(false);
        for (int t = 0; t < 16; t++) {
            int sx = (t % 4) * 16, sy = (t / 4) * 16;
            if (sx + 16 > baseAtlas.getWidth() || sy + 16 > baseAtlas.getHeight()) continue;
            cv.drawBitmap(baseAtlas, new Rect(sx, sy, sx + 16, sy + 16), new Rect(t * 16, 0, t * 16 + 16, 16), p);
        }
        // Tuiles 16..31 = atlas_extra.png (table de fabrication, bâton, outils)
        if (extraAtlas != null) for (int i = 0; i < 16; i++) {
            int sx = (i % 4) * 16, sy = (i / 4) * 16, t = 16 + i;
            if (sx + 16 > extraAtlas.getWidth() || sy + 16 > extraAtlas.getHeight()) continue;
            cv.drawBitmap(extraAtlas, new Rect(sx, sy, sx + 16, sy + 16), new Rect((t % COLS) * 16, (t / COLS) * 16, (t % COLS) * 16 + 16, (t / COLS) * 16 + 16), p);
        }
        // Tuile 15 = damier violet/noir (texture manquante)
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) a.setPixel(MISSING_TILE * 16 + x, y, ((x / 8 + y / 8) % 2 == 0) ? 0xFFF800F8 : 0xFF000000);
        for (int i = 0; i < modTiles.size(); i++) {
            int t = FIRST_MOD_TILE + i;
            cv.drawBitmap(modTiles.get(i), (t % COLS) * 16, (t / COLS) * 16, p);
        }
        atlas = a;
    }

    // ------------------------------------------------------------------ outils
    static String baseName(String f) { int i = f.lastIndexOf('.'); return i > 0 ? f.substring(0, i) : f; }
    static byte[] readAll(InputStream in) throws java.io.IOException {
        try (InputStream i = in) {
            ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
            while ((n = i.read(b)) > 0) o.write(b, 0, n);
            return o.toByteArray();
        }
    }
    private static String pretty(String s) {
        StringBuilder sb = new StringBuilder();
        for (String w : s.replace('/', ' ').split("[_\\s]+")) if (!w.isEmpty()) sb.append(sb.length() > 0 ? " " : "").append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        return sb.toString();
    }

    /** Lecture d'un mod : accumule ses tuiles et ses blocs dans le registre. */
    private static final class Loader {
        final ZipFile z; final ModInfo info; final BlockDef[] arr; final List<Integer> list; final JSONObject idMap;
        final Map<String, Integer> texIndex = new HashMap<>();
        Loader(ZipFile z, ModInfo info, BlockDef[] arr, List<Integer> list, JSONObject idMap) { this.z = z; this.info = info; this.arr = arr; this.list = list; this.idMap = idMap; }

        String text(String path) {
            try { ZipEntry e = z.getEntry(path); return e == null ? null : new String(readAll(z.getInputStream(e)), StandardCharsets.UTF_8); }
            catch (Exception e) { return null; }
        }

        /** Tuile de l'atlas pour un PNG du mod (redimensionné en 16x16, première image si animé). */
        int tile(String path) {
            if (path == null) return MISSING_TILE;
            String key = z.getName() + "!" + path;
            Integer known = texIndex.get(key); if (known != null) return known;
            int result = MISSING_TILE;
            try {
                ZipEntry e = z.getEntry(path);
                if (e != null && modTiles.size() < MAX_TILES) {
                    Bitmap b = BitmapFactory.decodeStream(z.getInputStream(e));
                    if (b != null) {
                        int w = b.getWidth(), h = b.getHeight();
                        if (h > w) b = Bitmap.createBitmap(b, 0, 0, w, w);
                        b = Bitmap.createScaledBitmap(b, 16, 16, false);
                        if (b.getConfig() != Bitmap.Config.ARGB_8888) b = b.copy(Bitmap.Config.ARGB_8888, false);
                        modTiles.add(b); result = FIRST_MOD_TILE + modTiles.size() - 1;
                    }
                }
            } catch (Exception ignored) {}
            texIndex.put(key, result); return result;
        }

        /** Attribue un id stable (mémorisé dans ids.json) et enregistre le bloc. */
        void register(String key, String name, int top, int bottom, int side) {
            int id = idMap.optInt(key, 0);
            if (id < FIRST_MOD_ID || id > MOD_MAX_ID || arr[id] != null) {
                if (id >= FIRST_MOD_ID && id <= MOD_MAX_ID && arr[id] != null) { info.skipped++; return; }
                int max = FIRST_MOD_ID - 1;
                java.util.Iterator<String> it = idMap.keys();
                while (it.hasNext()) max = Math.max(max, idMap.optInt(it.next(), 0));
                id = max + 1;
                if (id > MOD_MAX_ID) {
                    // Plus d'id neuf : on réutilise un id libre (mod supprimé) s'il y en a.
                    id = 0; for (int i = FIRST_MOD_ID; i <= MOD_MAX_ID; i++) if (arr[i] == null && !idUsed(i)) { id = i; break; }
                    if (id == 0) { info.skipped++; return; }
                }
                try { idMap.put(key, id); } catch (Exception ignored) {}
            }
            arr[id] = new BlockDef(id, key, name, info.name, top, bottom, side); list.add(id); info.blocks++;
        }
        boolean idUsed(int id) {
            java.util.Iterator<String> it = idMap.keys();
            while (it.hasNext()) if (idMap.optInt(it.next(), 0) == id) return true;
            return false;
        }

        // ---------------- mod Ractex : mod.json ----------------
        void loadRactex() throws Exception {
            JSONObject o = new JSONObject(text("mod.json"));
            String modId = o.optString("id", baseName(info.file));
            info.name = o.optString("name", modId); info.version = o.optString("version", ""); info.kind = "Ractex";
            JSONArray bl = o.optJSONArray("blocks"); if (bl == null) return;
            for (int i = 0; i < bl.length(); i++) {
                JSONObject b = bl.optJSONObject(i); if (b == null) continue;
                String bid = b.optString("id", ""); if (bid.isEmpty()) continue;
                String all = b.optString("texture", null);
                String side = b.optString("side", all), top = b.optString("top", all != null ? all : side), bottom = b.optString("bottom", top);
                if (side == null) side = top;
                register(modId + ":" + bid, b.optString("name", pretty(bid)), tile(top), tile(bottom), tile(side));
            }
        }

        // ---------------- mod Minecraft Java : assets/ ----------------
        void loadMinecraft() {
            info.kind = "Minecraft";
            Map<String, String> lang = new HashMap<>();
            List<String> models = new ArrayList<>();
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName();
                if (n.startsWith("assets/") && n.contains("/models/block/") && n.endsWith(".json")) models.add(n);
                else if (n.startsWith("assets/") && (n.endsWith("/lang/fr_fr.json") || n.endsWith("/lang/en_us.json"))) readLang(n, lang);
            }
            readMeta();
            Collections.sort(models);
            for (String m : models) {
                String[] p = m.split("/"); // assets, ns, models, block, name.json
                if (p.length != 5) continue;
                String ns = p[1], name = baseName(p[4]);
                if (name.contains("inventory") || z.getEntry("assets/" + ns + "/blockstates/" + name + ".json") == null) continue;
                try {
                    JSONObject o = new JSONObject(text(m));
                    String parent = o.optString("parent", "").replace("minecraft:", "");
                    JSONObject t = o.optJSONObject("textures"); if (t == null) continue;
                    String top, bottom, side;
                    switch (parent) {
                        case "block/cube_all": case "block/cube_mirrored_all": top = bottom = side = tex(t, "all"); break;
                        case "block/cube_column": case "block/cube_column_mirrored": top = bottom = tex(t, "end"); side = tex(t, "side"); break;
                        case "block/cube_bottom_top": top = tex(t, "top"); bottom = tex(t, "bottom"); side = tex(t, "side"); break;
                        case "block/cube_top": top = tex(t, "top"); side = bottom = tex(t, "side"); break;
                        case "block/orientable": case "block/orientable_with_bottom": top = tex(t, "top"); side = tex(t, "side"); bottom = t.has("bottom") ? tex(t, "bottom") : top; break;
                        case "block/cube": top = tex(t, "up"); bottom = tex(t, "down"); side = tex(t, "north"); break;
                        default: continue;
                    }
                    String disp = lang.get("block." + ns + "." + name);
                    register(ns + ":" + name, disp != null ? disp : pretty(name), tile(top), tile(bottom), tile(side));
                } catch (Exception ignored) {}
            }
        }
        /** Résout « modid:block/nom » (ou « #ref ») en chemin PNG dans le jar. Les textures vanilla ne sont pas dans le jar : null. */
        String tex(JSONObject t, String k) {
            String v = t.optString(k, null);
            for (int i = 0; i < 4 && v != null && v.startsWith("#"); i++) v = t.optString(v.substring(1), null);
            if (v == null || v.startsWith("#")) return null;
            String ns = "minecraft", path = v; int c = v.indexOf(':');
            if (c >= 0) { ns = v.substring(0, c); path = v.substring(c + 1); }
            return "assets/" + ns + "/textures/" + path + ".png";
        }
        void readLang(String path, Map<String, String> out) {
            boolean fr = path.endsWith("fr_fr.json");
            try {
                JSONObject o = new JSONObject(text(path));
                java.util.Iterator<String> it = o.keys();
                while (it.hasNext()) { String k = it.next(); if (k.startsWith("block.") && (fr || !out.containsKey(k))) out.put(k, o.optString(k)); }
            } catch (Exception ignored) {}
        }
        void readMeta() {
            String f = text("fabric.mod.json");
            if (f != null) {
                try { JSONObject o = new JSONObject(f); info.kind = "Fabric"; info.name = o.optString("name", info.name); info.version = o.optString("version", ""); } catch (Exception ignored) {}
                return;
            }
            String t = text("META-INF/neoforge.mods.toml"); String kind = "NeoForge";
            if (t == null) { t = text("META-INF/mods.toml"); kind = "Forge"; }
            if (t != null) {
                info.kind = kind;
                Matcher m = Pattern.compile("displayName\\s*=\\s*\"([^\"]+)\"").matcher(t); if (m.find()) info.name = m.group(1);
                m = Pattern.compile("(?m)^\\s*version\\s*=\\s*\"([^\"$]+)\"").matcher(t); if (m.find()) info.version = m.group(1);
                return;
            }
            String old = text("mcmod.info");
            if (old != null) {
                try {
                    JSONArray a = old.trim().startsWith("[") ? new JSONArray(old) : new JSONObject(old).optJSONArray("modList");
                    if (a != null && a.length() > 0) { info.kind = "Forge"; info.name = a.getJSONObject(0).optString("name", info.name); info.version = a.getJSONObject(0).optString("version", ""); }
                } catch (Exception ignored) {}
            }
        }
    }
}
