package fr.ractex.bedrockjava;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.IntConsumer;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String VERSION = "0.10";
    private static final String[] SPLASH = {"Pixels nets !", "Monde infini !", "Même seed, même monde !", "100% Java !", "Creuse, creuse !", "Fait sur téléphone !", "Un chunk à la fois !"};

    private FrameLayout root, gameLayer;
    private View menuLayer;
    private Runnable onBack;
    private GameSurface game;
    private TextView hud;
    private final ImageView[] hotItems = new ImageView[9];
    // Survie (0.9)
    private Inventory inv = new Inventory();
    private boolean survival = true, deathShown, mining;
    private int invPick = -1;
    private final Random rnd = new Random();
    private TextView[] hotCnt = new TextView[9];
    private ImageView[] heartFull = new ImageView[10], heartHalf = new ImageView[10], foodFull = new ImageView[10], foodHalf = new ImageView[10];
    private View hurtFlash, mineFill; private FrameLayout mineBar;
    private long mineKey = -1; private float mineProgress;
    private TextView mineBtn;
    // {table requise (1) ou non (0), objet obtenu, quantité, ingrédient A, quantité A, ingrédient B, quantité B}
    private static final int[][] RECIPES = {
        {0, World.PLANKS, 4, World.WOOD, 1, 0, 0},
        {0, Items.STICK, 4, World.PLANKS, 2, 0, 0},
        {0, World.TABLE, 1, World.PLANKS, 4, 0, 0},
        {1, Items.WOOD_PICK, 1, World.PLANKS, 3, Items.STICK, 2},
        {1, Items.STONE_PICK, 1, World.COBBLE, 3, Items.STICK, 2},
        {1, Items.WOOD_AXE, 1, World.PLANKS, 3, Items.STICK, 2},
        {1, Items.STONE_AXE, 1, World.COBBLE, 3, Items.STICK, 2},
        {1, Items.WOOD_SHOVEL, 1, World.PLANKS, 1, Items.STICK, 2},
        {1, Items.STONE_SHOVEL, 1, World.COBBLE, 1, Items.STICK, 2}};
    private ImageView hotSel;
    private GuiTex tex;
    private int px1, hotGs = 3;
    private final int[] hotbarIds = {World.GRASS, World.DIRT, World.STONE, World.WOOD, World.LEAVES, 0, 0, 0, 0};
    private final boolean[] dirs = new boolean[4]; // avant, arrière, gauche, droite
    private final Map<Integer, Bitmap> iconCache = new HashMap<>();
        private TextView itemName;
    private int selected = 0, invPage = 0;
    private static final int REQ_MOD = 77, REQ_SKIN = 78;
    private float lastX, lastY;
    private boolean rotating, inGame;
    private File currentFile;
    private String currentName;
    private SharedPreferences prefs;
    private final Runnable hudTick = new Runnable() {
        @Override public void run() {
            if (!inGame || game == null || hud == null) return;
            hud.setText("Ractex Bedrock Java " + VERSION + "\n" + currentName + "  ·  " + (survival ? "Survie" : "Créatif") + "  ·  Seed " + game.renderer.getSeed() + "\n"
                + String.format(Locale.US, "XYZ  %.1f / %.1f / %.1f", game.renderer.getPlayerX(), game.renderer.getPlayerY(), game.renderer.getPlayerZ()));
            refreshVitals();
            if (game.renderer.isDead() && !deathShown) showDeath();
            if (game.renderer.consumeHurt()) flashHurt();
            hud.postDelayed(this, 250);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        prefs = getSharedPreferences("ractex", MODE_PRIVATE);
        tex = new GuiTex(this);
        ModRegistry.init(this);
        px1 = Math.max(2, Math.round(getResources().getDisplayMetrics().density * 2f)); // 1 pixel de texture = ~2 dp
        root = new FrameLayout(this);
        setContentView(root);
        migrateLegacySave();
        showTitle();
    }

    // =====================================================================
    //  Menus
    // =====================================================================
    private void setMenu(View v, Runnable back) {
        if (menuLayer != null) root.removeView(menuLayer);
        menuLayer = v; onBack = back;
        if (game != null && inGame) game.renderer.setPaused(v != null);
        if (v != null) { v.setClickable(true); root.addView(v, new FrameLayout.LayoutParams(-1, -1)); }
    }

    /** Écran titre : logo, phrase jaune, Jouer / Paramètres / Quitter. */
    private void showTitle() {
        LinearLayout col = column();
        col.setGravity(Gravity.CENTER);
        TextView logo = text("RACTEX", 46, 0xFFE8E8E8, true);
        logo.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); logo.setLetterSpacing(.12f);
        logo.setShadowLayer(dp(2), dp(3), dp(3), 0xFF2A2A2A);
        TextView sub = text("BEDROCK JAVA EDITION", 15, 0xFFBDBDBD, true);
        sub.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); sub.setLetterSpacing(.2f);
        TextView splash = text(SPLASH[new Random().nextInt(SPLASH.length)], 15, 0xFFFFFF55, true);
        splash.setRotation(-6f); splash.setShadowLayer(1, 2, 2, 0xFF3F3F00);
        col.addView(logo); col.addView(sub);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2); sp.topMargin = dp(8); sp.bottomMargin = dp(14);
        col.addView(splash, sp);
        col.addView(mcButton("Jouer", true, this::showWorlds), wide());
        LinearLayout duo = new LinearLayout(this); duo.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(dp(147), 20 * px1); hl.topMargin = dp(3); hl.bottomMargin = dp(3);
        LinearLayout.LayoutParams hr = new LinearLayout.LayoutParams(dp(147), 20 * px1); hr.topMargin = dp(3); hr.bottomMargin = dp(3); hr.leftMargin = dp(6);
        duo.addView(mcButton("Mods", false, this::showMods), hl); duo.addView(mcButton("Skins", false, this::showSkins), hr);
        col.addView(duo);
        col.addView(mcButton("Paramètres", false, () -> showSettings(this::showTitle)), wide());
        col.addView(mcButton("Quitter le jeu", false, this::finish), wide());
        FrameLayout f = background();
        f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        TextView v = text("Ractex " + VERSION, 11, 0xFFFFFFFF, false);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT); vp.leftMargin = dp(10); vp.bottomMargin = dp(6);
        f.addView(v, vp);
        setMenu(f, this::finish);
    }

    /** Liste des mondes + création. */
    private void showWorlds() {
        LinearLayout col = column();
        col.addView(text("Jouer", 22, Color.WHITE, true));
        col.addView(mcButton("Créer un nouveau monde", true, this::showCreate), wide());
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setGravity(Gravity.CENTER_HORIZONTAL);
        ScrollView sv = new ScrollView(this); sv.addView(list, new ScrollView.LayoutParams(-1, -2));
        File[] files = worldsDir().listFiles((d, n) -> n.endsWith(".dat"));
        if (files == null) files = new File[0];
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE);
        int shown = 0;
        for (File f : files) {
            Long seed = World.peekSeed(f);
            if (seed == null) continue;
            final String name = f.getName().substring(0, f.getName().length() - 4);
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView b = mcButton(name + "\nSeed : " + seed + "  ·  " + fmt.format(new Date(f.lastModified())), false, () -> startGame(f, name));
            b.setTextSize(14);
            row.addView(b, new LinearLayout.LayoutParams(dp(300), dp(56)));
            TextView x = mcButton("✕", false, () -> confirmDelete(f, name));
            LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(46), dp(56)); xp.leftMargin = dp(6);
            row.addView(x, xp);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2); rp.topMargin = dp(3); rp.bottomMargin = dp(3);
            list.addView(row, rp); shown++;
        }
        if (shown == 0) { TextView e = text("Aucun monde pour l'instant. Crées-en un !", 14, 0xFFDDDDDD, true); e.setPadding(0, dp(20), 0, 0); list.addView(e); }
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        col.addView(mcButton("Retour", false, this::showTitle), wide());
        FrameLayout f = background(); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showTitle);
    }

    private void confirmDelete(File f, String name) {
        new AlertDialog.Builder(this).setTitle("Supprimer « " + name + " » ?").setMessage("Ce monde sera définitivement effacé.")
            .setPositiveButton("Supprimer", (d, w) -> { f.delete(); prefs.edit().remove("inv_" + name).apply(); showWorlds(); }).setNegativeButton("Annuler", null).show();
    }

    /** Création d'un monde : nom + seed. */
    private void showCreate() {
        LinearLayout col = column();
        col.addView(text("Créer un nouveau monde", 22, Color.WHITE, true));
        col.addView(text("Nom du monde", 13, 0xFFCCCCCC, false));
        final EditText name = field("Nouveau monde"); name.setText("Nouveau monde");
        col.addView(name, new LinearLayout.LayoutParams(dp(300), -2));
        col.addView(text("Seed (vide = aléatoire, nombre ou texte)", 13, 0xFFCCCCCC, false));
        final EditText seed = field("Aléatoire");
        col.addView(seed, new LinearLayout.LayoutParams(dp(300), -2));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(10)); col.addView(new View(this), gap);
        col.addView(mcButton("Créer le monde", true, () -> {
            String n = sanitize(name.getText().toString());
            File f = freeFile(n); String finalName = f.getName().substring(0, f.getName().length() - 4);
            try { new World(parseSeed(seed.getText().toString())).save(f, 8.5f, Float.NaN, 8.5f); }
            catch (Exception e) { Toast.makeText(this, "Impossible de créer le monde", Toast.LENGTH_SHORT).show(); return; }
            startGame(f, finalName);
        }), wide());
        col.addView(mcButton("Annuler", false, this::showWorlds), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showWorlds);
    }

    /** Paramètres : distance d'affichage et sensibilité. */
    private void showSettings(Runnable back) {
        LinearLayout col = column();
        col.addView(text("Paramètres", 22, Color.WHITE, true));
        addSlider(col, "Distance d'affichage", "dist", 2, 8, 5, " chunks");
        col.addView(text("Appliquée à l'entrée dans un monde. Plus haut = plus beau mais plus lent.", 11, 0xFFBBBBBB, false));
        addSlider(col, "Sensibilité de la caméra", "sens", 1, 12, 6, "");
        addSlider(col, "Vitesse de marche", "speed", 1, 10, 4, "");
        final TextView[] tg = new TextView[1];
        tg[0] = mcButton(barsLabel(), false, () -> { prefs.edit().putBoolean("bars", !prefs.getBoolean("bars", true)).apply(); tg[0].setText(barsLabel()); });
        col.addView(tg[0], wide());
        final TextView[] md = new TextView[1];
        md[0] = mcButton(modeLabel(), false, () -> { prefs.edit().putBoolean("survival", !prefs.getBoolean("survival", true)).apply(); md[0].setText(modeLabel()); });
        col.addView(md[0], wide());
        col.addView(text("Survie : vie, faim, chute, minage, butin. Le mode s'applique à l'entrée dans un monde.", 11, 0xFFBBBBBB, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(12)); col.addView(new View(this), gap);
        col.addView(mcButton("Terminé", true, back), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, back);
    }

    private String modeLabel() { return "Mode de jeu : " + (prefs.getBoolean("survival", true) ? "SURVIE" : "CRÉATIF"); }
    private String barsLabel() { return "Barres vie / faim : " + (prefs.getBoolean("bars", true) ? "OUI" : "NON"); }
    private void addSlider(LinearLayout col, String label, String key, int min, int max, int def, String unit) {
        McSlider sl = new McSlider(this, tex, px1, label, unit, min, max, prefs.getInt(key, def), v -> prefs.edit().putInt(key, v).apply());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(300), 20 * px1); p.topMargin = dp(8);
        col.addView(sl, p);
    }

    /** Liste des mods installés, ajout depuis le téléphone (.zip / .jar), suppression. */
    private void showMods() {
        LinearLayout col = column();
        col.addView(text("Mods", 22, Color.WHITE, true));
        TextView info = text("Mods Ractex (.zip avec mod.json) et mods Minecraft Java (.jar Forge/Fabric) : les blocs cubiques sont importés avec leurs textures et leurs noms. Touche un mod pour lire son vrai code (bytecode des .class, fichiers JSON, etc.). Le code des mods Minecraft ne peut pas être exécuté ici.", 11, 0xFFDDDDDD, false);
        col.addView(info, new LinearLayout.LayoutParams(dp(420), -2));
        col.addView(mcButton("Ajouter un mod (.zip / .jar)", true, this::pickMod), wide());
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setGravity(Gravity.CENTER_HORIZONTAL);
        ScrollView sv = new ScrollView(this); sv.addView(list, new ScrollView.LayoutParams(-1, -2));
        List<ModRegistry.ModInfo> mods = ModRegistry.mods();
        for (final ModRegistry.ModInfo m : mods) {
            String line = m.name + (m.version.isEmpty() ? "" : "  " + m.version) + "\n";
            line += m.error != null ? "Erreur : " + m.error : m.kind + "  ·  " + m.blocks + " bloc(s)" + (m.skipped > 0 ? "  ·  " + m.skipped + " ignoré(s)" : "");
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView b = mcButton(line, false, () -> showModFiles(m));
            b.setTextSize(13); row.addView(b, new LinearLayout.LayoutParams(dp(300), 26 * px1));
            TextView x = mcButton("✕", false, () -> confirmDeleteMod(m));
            LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(46), 26 * px1); xp.leftMargin = dp(6);
            row.addView(x, xp);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2); rp.topMargin = dp(3); rp.bottomMargin = dp(3);
            list.addView(row, rp);
        }
        if (mods.isEmpty()) { TextView e = text("Aucun mod installé.", 14, 0xFFDDDDDD, true); e.setPadding(0, dp(16), 0, 0); list.addView(e); }
        col.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        col.addView(mcButton("Retour", false, this::showTitle), wide());
        FrameLayout f = background(); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showTitle);
    }
    private void confirmDeleteMod(final ModRegistry.ModInfo m) {
        new AlertDialog.Builder(this).setTitle("Supprimer « " + m.name + " » ?").setMessage("Les blocs de ce mod déjà posés dans tes mondes s'afficheront comme des damiers violets.")
            .setPositiveButton("Supprimer", (d, w) -> {
                new File(ModRegistry.modsDir(this), m.file).delete(); ModRegistry.reload(this); iconCache.clear(); showMods();
            }).setNegativeButton("Annuler", null).show();
    }
    private void pickMod() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/java-archive", "application/x-zip-compressed", "application/octet-stream"});
        try { startActivityForResult(i, REQ_MOD); } catch (Exception e) { Toast.makeText(this, "Aucun sélecteur de fichiers disponible", Toast.LENGTH_SHORT).show(); }
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SKIN) { onSkinPicked(res, data); return; }
        if (req != REQ_MOD || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData(); String name = displayName(uri, "mod.zip");
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        if (!name.endsWith(".zip") && !name.endsWith(".jar")) name += ".zip";
        File dest = new File(ModRegistry.modsDir(this), name);
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(dest)) {
            if (in == null) throw new java.io.IOException("lecture impossible");
            byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } catch (Exception e) { Toast.makeText(this, "Impossible de copier le mod", Toast.LENGTH_SHORT).show(); return; }
        ModRegistry.reload(this); iconCache.clear();
        String msg = "Mod ajouté";
        for (ModRegistry.ModInfo m : ModRegistry.mods()) if (m.file.equals(name)) msg = m.error != null ? "Mod illisible : " + m.error : m.name + " : " + m.blocks + " bloc(s) importé(s)";
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        if (!inGame) showMods();
    }


    /** Nom d'affichage d'un fichier choisi dans le sélecteur Android. */
    private String displayName(Uri uri, String fallback) {
        String name = fallback;
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ix >= 0 && c.getString(ix) != null) name = c.getString(ix); }
        } catch (Exception ignored) {}
        return name;
    }

    // =====================================================================
    //  Skins
    // =====================================================================
    /** Écran Skins : aperçu (face + dos), ajout d'un PNG, choix et suppression. */
    private void showSkins() {
        final String active = prefs.getString(SkinManager.PREF, "");
        LinearLayout col = column();
        col.addView(text("Skins", 22, Color.WHITE, true));
        SkinManager.Preview prev = new SkinManager.Preview(this); prev.setSkin(SkinManager.load(this, active));
        col.addView(prev, new LinearLayout.LayoutParams(dp(260), dp(140)));
        col.addView(text("PNG au format Minecraft Java (64×64 ou 64×32 ; les bras fins « Alex » sont reconnus tout seuls). En jeu, le bouton VUE affiche ton personnage à la 3e personne.", 11, 0xFFDDDDDD, false), new LinearLayout.LayoutParams(dp(420), -2));
        col.addView(mcButton("Ajouter un skin (.png)", true, this::pickSkin), wide());
        List<String> names = new ArrayList<>(); names.add(""); names.addAll(SkinManager.list(this));
        for (final String n : names) {
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView b = mcButton((n.equals(active) ? "✔ " : "") + SkinManager.label(n), false, () -> { prefs.edit().putString(SkinManager.PREF, n).apply(); showSkins(); });
            b.setTextSize(14); row.addView(b, new LinearLayout.LayoutParams(dp(300), 18 * px1));
            if (!n.isEmpty()) {
                TextView x = mcButton("✕", false, () -> confirmDeleteSkin(n, n.equals(active)));
                LinearLayout.LayoutParams xp = new LinearLayout.LayoutParams(dp(46), 18 * px1); xp.leftMargin = dp(6); row.addView(x, xp);
            }
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-2, -2); rp.topMargin = dp(3); rp.bottomMargin = dp(3);
            col.addView(row, rp);
        }
        col.addView(mcButton("Retour", false, this::showTitle), wide());
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(col, new ScrollView.LayoutParams(-1, -2));
        FrameLayout f = background(); f.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showTitle);
    }
    private void confirmDeleteSkin(final String file, final boolean wasActive) {
        new AlertDialog.Builder(this).setTitle("Supprimer « " + SkinManager.label(file) + " » ?").setMessage("Ce skin sera effacé de l'appareil.")
            .setPositiveButton("Supprimer", (d, w) -> {
                new File(SkinManager.dir(this), file).delete();
                if (wasActive) prefs.edit().putString(SkinManager.PREF, "").apply();
                showSkins();
            }).setNegativeButton("Annuler", null).show();
    }
    private void pickSkin() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
        try { startActivityForResult(i, REQ_SKIN); } catch (Exception e) { Toast.makeText(this, "Aucun sélecteur de fichiers disponible", Toast.LENGTH_SHORT).show(); }
    }
    private void onSkinPicked(int res, Intent data) {
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            String file = SkinManager.importSkin(this, uri, displayName(uri, "skin.png"));
            prefs.edit().putString(SkinManager.PREF, file).apply();
            Toast.makeText(this, "Skin ajouté et choisi", Toast.LENGTH_SHORT).show();
        } catch (Exception e) { Toast.makeText(this, "Skin refusé : " + e.getMessage(), Toast.LENGTH_LONG).show(); }
        if (!inGame) showSkins();
    }

    // =====================================================================
    //  Lecteur de code des mods
    // =====================================================================
    private static int codeRank(String n) {
        String l = n.toLowerCase(Locale.ROOT);
        if (l.endsWith(".class") || l.endsWith(".java") || l.endsWith(".kt") || l.endsWith(".js") || l.endsWith(".groovy") || l.endsWith(".scala")) return 0;
        if (l.endsWith(".png") || l.endsWith(".ogg") || l.endsWith(".jpg") || l.endsWith(".mcmeta")) return 2;
        return 1;
    }

    /** Liste des fichiers d'un mod (code d'abord) avec filtre ; touche un fichier pour le lire. */
    private void showModFiles(final ModRegistry.ModInfo m) {
        final List<String> all = new ArrayList<>(); String err = null; int classes = 0;
        try (ZipFile z = new ZipFile(new File(ModRegistry.modsDir(this), m.file))) {
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) { ZipEntry e = en.nextElement(); if (!e.isDirectory()) all.add(e.getName()); }
        } catch (Exception e) { err = e.getClass().getSimpleName() + (e.getMessage() != null ? " : " + e.getMessage() : ""); }
        Collections.sort(all, (a, b) -> { int ra = codeRank(a), rb = codeRank(b); return ra != rb ? ra - rb : a.compareTo(b); });
        for (String n : all) if (n.endsWith(".class")) classes++;

        LinearLayout col = column();
        col.addView(text("Code : " + m.name, 20, Color.WHITE, true));
        col.addView(text(err != null ? "Erreur : " + err : all.size() + " fichier(s), dont " + classes + " classe(s) Java (.class). Les .class s'affichent en bytecode lisible (champs, méthodes, appels, textes).", 11, 0xFFDDDDDD, false), new LinearLayout.LayoutParams(dp(480), -2));
        final EditText filter = field("Filtrer (ex. block, .json, Main)");
        col.addView(filter, new LinearLayout.LayoutParams(dp(300), -2));
        final List<String> shown = new ArrayList<>(all);
        final ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, shown) {
            @Override public View getView(int pos, View cv, android.view.ViewGroup parent) {
                TextView t = (TextView) super.getView(pos, cv, parent);
                t.setTextColor(Color.WHITE); t.setTypeface(Typeface.MONOSPACE); t.setTextSize(12); t.setSingleLine(true);
                t.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE); t.setPadding(dp(8), dp(6), dp(8), dp(6)); return t;
            }
        };
        ListView lv = new ListView(this); lv.setAdapter(ad); lv.setBackgroundColor(0x66000000); lv.setDividerHeight(1);
        lv.setOnItemClickListener((p, v, pos, id) -> showModFile(m, shown.get(pos)));
        filter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) {
                String q = e.toString().trim().toLowerCase(Locale.ROOT); shown.clear();
                for (String n : all) if (q.isEmpty() || n.toLowerCase(Locale.ROOT).contains(q)) shown.add(n);
                ad.notifyDataSetChanged();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(480), 0, 1f); lp.topMargin = dp(6);
        col.addView(lv, lp);
        col.addView(mcButton("Retour", false, this::showMods), wide());
        FrameLayout f = background(); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::showMods);
    }

    /** Lecture d'un fichier du mod : .class en bytecode lisible, texte tel quel, image affichée, binaire signalé. */
    private void showModFile(final ModRegistry.ModInfo m, final String entry) {
        final int MAX = 8 * 1024 * 1024; byte[] data = null; String err = null;
        try (ZipFile z = new ZipFile(new File(ModRegistry.modsDir(this), m.file))) {
            ZipEntry e = z.getEntry(entry);
            if (e == null) err = "fichier introuvable";
            else if (e.getSize() > MAX) err = "fichier trop gros (" + (e.getSize() / 1024) + " Ko) pour être affiché";
            else data = ModRegistry.readAll(z.getInputStream(e));
        } catch (Exception e) { err = e.getClass().getSimpleName() + (e.getMessage() != null ? " : " + e.getMessage() : ""); }

        LinearLayout col = column();
        TextView title = text(entry, 12, Color.WHITE, true); title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(title, new LinearLayout.LayoutParams(dp(520), -2));
        final Runnable back = () -> showModFiles(m);
        String lower = entry.toLowerCase(Locale.ROOT);
        if (data != null && (lower.endsWith(".png") || lower.endsWith(".jpg"))) {
            Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length);
            if (b != null) {
                int k = Math.max(1, Math.min(dp(220) / Math.max(1, b.getHeight()), dp(400) / Math.max(1, b.getWidth())));
                ImageView iv = new ImageView(this); iv.setImageDrawable(GuiTex.crisp(this, Bitmap.createScaledBitmap(b, b.getWidth() * k, b.getHeight() * k, false)));
                col.addView(text(b.getWidth() + " × " + b.getHeight() + " pixels", 11, 0xFFDDDDDD, false));
                col.addView(iv, new LinearLayout.LayoutParams(-2, 0, 1f));
            } else err = "image illisible";
        } else if (data != null && err == null) {
            String body;
            if (lower.endsWith(".class")) body = ClassDisassembler.disassemble(data);
            else if (looksLikeText(data)) body = new String(data, java.nio.charset.StandardCharsets.UTF_8);
            else body = "Fichier binaire (" + data.length + " octets) : pas de texte à afficher.";
            addPagedText(col, body);
        }
        if (err != null) col.addView(text("Impossible de lire ce fichier : " + err, 13, 0xFFFFAAAA, false));
        col.addView(mcButton("Retour à la liste", false, back), wide());
        FrameLayout f = background(); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, back);
    }
    private static boolean looksLikeText(byte[] d) {
        int n = Math.min(d.length, 2000), bad = 0;
        for (int i = 0; i < n; i++) { int c = d[i] & 0xff; if (c == 0 || (c < 9) || (c > 13 && c < 32)) bad++; }
        return bad == 0;
    }
    /** Texte monospace sélectionnable, découpé en pages de 200 lignes (un gros fichier dans un seul TextView bloquerait l'appli). */
    private void addPagedText(LinearLayout col, String body) {
        final String[] lines = body.split("\n", -1); final int PER = 200, pages = Math.max(1, (lines.length + PER - 1) / PER);
        final int[] page = {0};
        final TextView t = new TextView(this); t.setTypeface(Typeface.MONOSPACE); t.setTextSize(11); t.setTextColor(0xFFE8E8E8); t.setTextIsSelectable(true);
        t.setHorizontallyScrolling(true); t.setPadding(dp(8), dp(6), dp(8), dp(6)); t.setBackgroundColor(0xCC101010);
        final ScrollView vs = new ScrollView(this); HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(t, new HorizontalScrollView.LayoutParams(-2, -2)); vs.addView(hs, new ScrollView.LayoutParams(-1, -2));
        final TextView label = text("", 12, Color.WHITE, false);
        final Runnable show = () -> {
            int from = page[0] * PER, to = Math.min(lines.length, from + PER);
            StringBuilder sb = new StringBuilder();
            for (int i = from; i < to; i++) sb.append(lines[i]).append('\n');
            t.setText(sb); label.setText("Lignes " + (from + 1) + "–" + to + " / " + lines.length + "   ·   page " + (page[0] + 1) + "/" + pages);
            vs.scrollTo(0, 0);
        };
        show.run();
        col.addView(vs, new LinearLayout.LayoutParams(dp(520), 0, 1f));
        if (pages > 1) {
            LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(90), 16 * px1); bp.leftMargin = dp(4); bp.rightMargin = dp(4);
            nav.addView(mcButton("◀", false, () -> { if (page[0] > 0) { page[0]--; show.run(); } }), bp);
            nav.addView(label);
            nav.addView(mcButton("▶", false, () -> { if (page[0] < pages - 1) { page[0]++; show.run(); } }), bp);
            col.addView(nav);
        } else col.addView(label);
    }

    /** Menu pause en jeu. */
    private void showPause() {
        game.renderer.setMovement(0, 0); Arrays.fill(dirs, false);
        LinearLayout col = column(); col.setGravity(Gravity.CENTER);
        col.addView(text("Jeu en pause", 22, Color.WHITE, true));
        col.addView(text(currentName + "  ·  Seed : " + game.renderer.getSeed(), 13, 0xFFDDDDDD, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(10)); col.addView(new View(this), gap);
        col.addView(mcButton("Reprendre", true, this::resume), wide());
        col.addView(mcButton("Sauvegarder", false, () -> Toast.makeText(this, game.renderer.saveWorld() ? "Monde sauvegardé" : "Erreur de sauvegarde", Toast.LENGTH_SHORT).show()), wide());
        col.addView(mcButton("Paramètres", false, () -> showSettings(this::showPause)), wide());
        col.addView(mcButton("Sauvegarder et quitter", false, this::exitToTitle), wide());
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(0xB8000000); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, this::resume);
    }
    private void resume() { setMenu(null, null); if (game != null) applySettings(); }
    private void applySettings() { game.renderer.setMoveSpeed(prefs.getInt("speed", 4) * .018f); }

    // =====================================================================
    //  Jeu
    // =====================================================================
    private void startGame(File file, String name) {
        currentFile = file; currentName = name;
        survival = prefs.getBoolean("survival", true); deathShown = false; mining = false; invPick = -1;
        inv = survival ? Inventory.parse(prefs.getString("inv_" + name, "")) : new Inventory();
        setMenu(null, null);
        gameLayer = buildGame(file, name);
        root.addView(gameLayer, 0, new FrameLayout.LayoutParams(-1, -1));
        inGame = true;
        applySettings();
        hud.removeCallbacks(hudTick); hud.post(hudTick);
    }
    private void exitToTitle() {
        if (inGame) {
            hud.removeCallbacks(hudTick);
            saveInv(); mining = false; game.renderer.saveWorld(); game.onPause();
            root.removeView(gameLayer); gameLayer = null; game = null; inGame = false;
        }
        showTitle();
    }

    private FrameLayout buildGame(File file, String name) {
        FrameLayout g = new FrameLayout(this);
        game = new GameSurface(this, prefs.getInt("dist", 5));
        g.addView(game, new FrameLayout.LayoutParams(-1, -1));
        game.renderer.setSaveFile(file);
        game.renderer.setSurvival(survival);
        SkinManager.Skin skin = SkinManager.load(this, prefs.getString(SkinManager.PREF, ""));
        game.renderer.setSkin(skin.bmp, skin.slim);
        Arrays.fill(dirs, false);
        loadHotbar();
        hotCnt = new TextView[9]; heartFull = new ImageView[10]; heartHalf = new ImageView[10]; foodFull = new ImageView[10]; foodHalf = new ImageView[10];
        hurtFlash = new View(this); hurtFlash.setBackgroundColor(0x77FF0000); hurtFlash.setAlpha(0f);
        g.addView(hurtFlash, new FrameLayout.LayoutParams(-1, -1));

        // Viseur du pack
        ImageView cross = new ImageView(this); cross.setImageDrawable(GuiTex.crisp(this, tex.scaled("crosshair", px1)));
        g.addView(cross, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        mineBar = new FrameLayout(this); mineBar.setBackgroundColor(0x99000000); mineBar.setVisibility(View.GONE);
        mineFill = new View(this); mineFill.setBackgroundColor(0xFFFFFFFF); mineBar.addView(mineFill, new FrameLayout.LayoutParams(0, -1));
        FrameLayout.LayoutParams mbp = new FrameLayout.LayoutParams(dp(60), dp(6), Gravity.CENTER); mbp.topMargin = dp(30);
        g.addView(mineBar, mbp);

        // Infos en haut à gauche
        hud = label("", 11); hud.setPadding(dp(8), dp(4), dp(8), dp(4)); hud.setBackgroundColor(0x66000000); hud.setShadowLayer(1, 1, 1, 0xFF000000);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT); hp.leftMargin = dp(6); hp.topMargin = dp(6);
        g.addView(hud, hp);

        // Croix directionnelle (gauche) : on peut combiner deux directions (diagonales)
        int s = dp(52), gap = dp(4), L = dp(16), B = dp(14);
        addPad(g, "▲", L + s + gap, B + 2 * (s + gap), s, 0);
        addPad(g, "▼", L + s + gap, B, s, 1);
        addPad(g, "◀", L, B + s + gap, s, 2);
        addPad(g, "▶", L + 2 * (s + gap), B + s + gap, s, 3);

        // Actions (droite)
        int bw = dp(62), bh = dp(52), R = dp(16);
        addAction(g, "POSER", 12, Gravity.BOTTOM | Gravity.RIGHT, R, B, bw, bh, () -> usePlace());
        // CASSER : on maintient le doigt (en survie le temps dépend du bloc, comme dans Minecraft)
        TextView mb = addAction(g, "CASSER", 12, Gravity.BOTTOM | Gravity.RIGHT, R + bw + gap, B, bw, bh, () -> {});
        mb.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { v.setPressed(true); mining = true; mineProgress = 0f; mineKey = -1; mineBtn = (TextView) v; v.post(mineTick); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { v.setPressed(false); mining = false; updateMineBar(0f); }
            return true;
        });
        addAction(g, "SAUT", 13, Gravity.BOTTOM | Gravity.RIGHT, R + (bw + gap) / 2, B + bh + gap, bw, bh, () -> game.renderer.jump());

        // Sac et menu (haut droite)
        addAction(g, "MENU", 12, Gravity.TOP | Gravity.RIGHT, dp(6), dp(6), dp(64), dp(34), () -> showPause());
        addAction(g, "SAC", 12, Gravity.TOP | Gravity.RIGHT, dp(6) + dp(64) + gap, dp(6), dp(64), dp(34), () -> showInventory());
        addAction(g, "VUE", 12, Gravity.TOP | Gravity.RIGHT, dp(6) + 2 * (dp(64) + gap), dp(6), dp(64), dp(34), () -> {
            int v = game.renderer.cycleView();
            Toast.makeText(this, v == 0 ? "Vue : 1re personne" : v == 1 ? "Vue : 3e personne (de dos)" : "Vue : 3e personne (de face)", Toast.LENGTH_SHORT).show();
        });

        // Barre d'objets, cœurs et faim : textures du pack, agrandies d'un facteur entier (pixels nets)
        int screenW = getResources().getDisplayMetrics().widthPixels;
        final int gs = Math.max(1, Math.min(5, (screenW - 2 * dp(190)) / 182)); hotGs = gs;
        FrameLayout hb = new FrameLayout(this); hb.setClipChildren(false);
        if (prefs.getBoolean("bars", true) && survival) {
            for (int i = 0; i < 10; i++) {
                int fx = (182 - 9 - i * 8) * gs;
                addTex(hb, "heart_container", gs, i * 8 * gs, 0); heartFull[i] = addTex(hb, "heart_full", gs, i * 8 * gs, 0); heartHalf[i] = addTexPart(hb, "heart_full", 5, gs, i * 8 * gs, 0);
                addTex(hb, "food_empty", gs, fx, 0); foodFull[i] = addTex(hb, "food_full", gs, fx, 0); foodHalf[i] = addTexPart(hb, "food_full", 5, gs, fx, 0);
            }
        }
        addTex(hb, "hotbar", gs, 0, 19 * gs);
        hotSel = addTex(hb, "hotbar_selection", gs, -gs, 18 * gs);
        for (int i = 0; i < 9; i++) {
            ImageView it = new ImageView(this); it.setScaleType(ImageView.ScaleType.FIT_XY);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(16 * gs, 16 * gs); ip.leftMargin = (3 + 20 * i) * gs; ip.topMargin = 22 * gs;
            hb.addView(it, ip); hotItems[i] = it;
            TextView cnt = pxText("", 7 * gs, Color.WHITE); cnt.setShadowLayer(1, gs, gs, 0xFF3F3F3F); cnt.setGravity(Gravity.BOTTOM | Gravity.RIGHT);
            FrameLayout.LayoutParams cp2 = new FrameLayout.LayoutParams(17 * gs, 17 * gs); cp2.leftMargin = (3 + 20 * i) * gs; cp2.topMargin = 22 * gs;
            hb.addView(cnt, cp2); hotCnt[i] = cnt;
        }
        hb.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN || e.getY() < 18f * gs) return false;
            selectSlot(Math.max(0, Math.min(8, (int) ((e.getX() / gs - 1f) / 20f)))); return true;
        });
        FrameLayout.LayoutParams hbp = new FrameLayout.LayoutParams(182 * gs, 41 * gs, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); hbp.bottomMargin = dp(6);
        g.addView(hb, hbp);

        // Nom de l'objet sélectionné (s'efface tout seul, comme dans Minecraft)
        itemName = label("", 14); itemName.setTypeface(Typeface.DEFAULT_BOLD); itemName.setShadowLayer(1, 2, 2, 0xFF000000); itemName.setAlpha(0f);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL); np.bottomMargin = dp(6) + 41 * gs + dp(4);
        g.addView(itemName, np);

        selectSlot(selected);

        game.setOnTouchListener((v, e) -> {
            float x = e.getX(), y = e.getY(), k = prefs.getInt("sens", 6) / 6f;
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { lastX = x; lastY = y; rotating = x > v.getWidth() * .42f; return rotating; }
            if (a == MotionEvent.ACTION_MOVE && rotating) { game.renderer.rotate((x - lastX) * .006f * k, (y - lastY) * .004f * k); lastX = x; lastY = y; return true; }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { rotating = false; return true; }
            return rotating;
        });
        return g;
    }
    /** Ajoute une texture du pack (agrandie de k, pixels nets) à une position en pixels. */
    private ImageView addTex(FrameLayout parent, String name, int k, int x, int y) {
        ImageView iv = new ImageView(this); iv.setImageDrawable(GuiTex.crisp(this, tex.scaled(name, k)));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-2, -2); p.leftMargin = x; p.topMargin = y;
        parent.addView(iv, p); return iv;
    }

    // ---------- Barre d'objets ----------
    private void selectSlot(int i) {
        selected = i;
        game.renderer.selectBlock(hotId(i));
        refreshHotbar();
        if (itemName != null) {
            itemName.animate().cancel();
            itemName.setText(slotLabel(i)); itemName.setAlpha(hotId(i) == 0 ? 0f : 1f);
            itemName.animate().alpha(0f).setStartDelay(1200).setDuration(500).start();
        }
    }
    private void refreshHotbar() {
        if (hotSel != null) hotSel.setTranslationX(20f * selected * hotGs);
        for (int i = 0; i < 9; i++) {
            if (hotItems[i] == null) continue;
            int id = hotId(i);
            hotItems[i].setImageBitmap(id == 0 ? null : icon(id, 16 * hotGs));
            if (hotCnt[i] != null) hotCnt[i].setText(survival && inv.n[i] > 1 ? String.valueOf(inv.n[i]) : "");
        }
    }
    private void saveHotbar() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 9; i++) sb.append(i == 0 ? "" : ",").append(hotbarIds[i]);
        prefs.edit().putString("hotbar", sb.toString()).apply();
    }
    private void loadHotbar() {
        String t = prefs.getString("hotbar", null); if (t == null) return;
        try {
            String[] p = t.split(",");
            int[] tmp = new int[9];
            for (int i = 0; i < 9; i++) { tmp[i] = Integer.parseInt(p[i].trim()); if (tmp[i] != 0 && !ModRegistry.has(tmp[i])) tmp[i] = 0; }
            System.arraycopy(tmp, 0, hotbarIds, 0, 9);
        } catch (Exception ignored) {}
    }
    private String slotLabel(int i) {
        int id = hotId(i);
        if (survival && Items.isTool(id)) return blockName(id) + "  (" + inv.dur[i] + "/" + Items.maxDur(id) + ")";
        return blockName(id);
    }
    private int hotId(int i) { return survival ? inv.id[i] : hotbarIds[i]; }
    private static String blockName(int id) { return Items.isItem(id) ? Items.name(id) : ModRegistry.name(id); }

    // ---------- Inventaire : écran « inventory.png » du pack ----------
    private void showInventory() {
        if (survival) { showSurvivalInventory(); return; }
        if (game != null) game.renderer.setMovement(0, 0);
        Arrays.fill(dirs, false);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        final int k = Math.max(1, Math.min(6, Math.min((int) (dm.heightPixels * .76f / 166), (int) (dm.widthPixels * .9f / 176))));

        FrameLayout panel = new FrameLayout(this); panel.setClickable(true); panel.setClipChildren(false);
        panel.setBackground(GuiTex.crisp(this, tex.region("inventory", 0, 0, 176, 166, k)));

        TextView title = pxText("Inventaire", 8 * k, 0xFF404040); place(panel, title, 97, 7, 72, 10, k);
        TextView hint = pxText("Touche un bloc, puis une case. ✕ vide la case.", 6 * k, 0xFF505050); hint.setGravity(Gravity.TOP | Gravity.LEFT); place(panel, hint, 97, 20, 72, 40, k);

        // Aperçu du bloc de la case sélectionnée (à la place du personnage)
        int cur = hotbarIds[selected];
        if (cur != 0) {
            ImageView big = new ImageView(this); big.setScaleType(ImageView.ScaleType.FIT_XY); big.setImageBitmap(icon(cur, 32 * k));
            place(panel, big, 34, 16, 32, 32, k);
            TextView nm = pxText(blockName(cur), 8 * k, Color.WHITE); nm.setShadowLayer(1, k, k, 0xFF3F3F3F); nm.setGravity(Gravity.CENTER); place(panel, nm, 26, 56, 49, 10, k);
        }

        // Palette de blocs : 3 lignes du sac (26 blocs par page + corbeille en bas à droite)
        final List<Integer> pal = ModRegistry.allIds();
        final int per = 26, pages = Math.max(1, (pal.size() + per - 1) / per);
        if (invPage >= pages) invPage = 0;
        final int[] rowY = {83, 101, 119};
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) {
            final int slotIdx = r * 9 + c, palIdx = invPage * per + slotIdx;
            final boolean isTrash = slotIdx == 26;
            final int bid = (!isTrash && palIdx < pal.size()) ? pal.get(palIdx) : 0;
            FrameLayout slot = slotView(bid, k, isTrash);
            slot.setOnClickListener(v -> {
                if (bid != 0) hotbarIds[selected] = bid; else if (isTrash) hotbarIds[selected] = 0; else return;
                saveHotbar(); selectSlot(selected); showInventory();
            });
            place(panel, slot, 7 + 18 * c, rowY[r], 18, 18, k);
        }
        // Barre d'objets
        for (int c = 0; c < 9; c++) {
            final int idx = c;
            FrameLayout slot = slotView(hotbarIds[c], k, false);
            slot.setOnClickListener(v -> { selectSlot(idx); showInventory(); });
            place(panel, slot, 7 + 18 * c, 141, 18, 18, k);
        }
        ImageView sel = new ImageView(this); sel.setImageDrawable(GuiTex.crisp(this, tex.scaled("hotbar_selection", k)));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2); sp.leftMargin = (7 + 18 * selected - 3) * k; sp.topMargin = (141 - 3) * k;
        panel.addView(sel, sp);

        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(panel, new LinearLayout.LayoutParams(176 * k, 166 * k));
        LinearLayout btns = new LinearLayout(this); btns.setOrientation(LinearLayout.HORIZONTAL); btns.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(pages > 1 ? 150 : 200), 20 * px1); cp.topMargin = dp(6); cp.leftMargin = dp(3); cp.rightMargin = dp(3);
        btns.addView(mcButton("Fermer", true, this::resume), cp);
        if (pages > 1) btns.addView(mcButton("Page " + (invPage + 1) + "/" + pages, false, () -> { invPage = (invPage + 1) % pages; showInventory(); }), cp);
        col.addView(btns);

        FrameLayout overlay = new FrameLayout(this); overlay.setBackgroundColor(0xB8000000);
        overlay.setOnClickListener(v -> resume());
        overlay.addView(col, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setMenu(overlay, this::resume);
    }
    /** Case cliquable de 18x18 pixels de texture ; id 0 = vide, trash = croix rouge. */
    private FrameLayout slotView(int id, int k, boolean trash) {
        FrameLayout f = new FrameLayout(this); f.setClickable(true);
        if (id != 0) {
            ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.FIT_XY); iv.setImageBitmap(icon(id, 16 * k));
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(16 * k, 16 * k); p.leftMargin = k; p.topMargin = k; f.addView(iv, p);
        } else if (trash) {
            TextView x = new TextView(this); x.setText("✕"); x.setTextColor(0xFF8A1F1F); x.setGravity(Gravity.CENTER); x.setTextSize(TypedValue.COMPLEX_UNIT_PX, 12 * k);
            f.addView(x, new FrameLayout.LayoutParams(-1, -1));
        }
        return f;
    }
    private TextView pxText(String s, int px, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(color); t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px); t.setIncludeFontPadding(false); return t;
    }
    /** Place une vue à une position/taille exprimées en pixels de texture (x k). */
    private static void place(FrameLayout parent, View v, int x, int y, int w, int h, int k) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w * k, h * k); p.leftMargin = x * k; p.topMargin = y * k; parent.addView(v, p);
    }

    // ---------- Icônes de blocs : petit cube isométrique dessiné à partir de l'atlas ----------
    private Bitmap tileBmp(int t) { return ModRegistry.tile(t); }
    private Bitmap icon(int id, int px) {
        int key = id * 10000 + px; Bitmap cached = iconCache.get(key); if (cached != null) return cached;
        if (Items.isItem(id)) { Bitmap flat = Bitmap.createScaledBitmap(tileBmp(Items.tile(id)), px, px, false); iconCache.put(key, flat); return flat; }
        int[] f = ModRegistry.faces(id); int top = f[0], side = f[2];
        Bitmap out = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888); Canvas c = new Canvas(out);
        Bitmap tt = tileBmp(top), ts = tileBmp(side);
        float[] src = {0, 0, 16, 0, 16, 16, 0, 16};
        quad(c, tt, src, new float[]{16, 2, 30, 9, 16, 16, 2, 9}, 0xFFFFFFFF);
        quad(c, ts, src, new float[]{2, 9, 16, 16, 16, 30, 2, 23}, 0xFFCCCCCC);
        quad(c, ts, src, new float[]{16, 16, 30, 9, 30, 23, 16, 30}, 0xFF999999);
        Bitmap scaled = Bitmap.createScaledBitmap(out, px, px, false);
        iconCache.put(key, scaled); return scaled;
    }
    private static void quad(Canvas c, Bitmap bmp, float[] src, float[] dst, int shade) {
        Matrix m = new Matrix(); m.setPolyToPoly(src, 0, dst, 0, 4);
        Paint p = new Paint(); p.setFilterBitmap(false); p.setAntiAlias(false); p.setColorFilter(new PorterDuffColorFilter(shade, PorterDuff.Mode.MULTIPLY));
        c.drawBitmap(bmp, m, p);
    }

    // =====================================================================
    //  Survie (0.9) : minage, poser / manger, inventaire à quantités, vie et faim, mort
    // =====================================================================
    private final Runnable mineTick = new Runnable() {
        @Override public void run() {
            if (!mining || !inGame || game == null || mineBtn == null) return;
            doMine(.05f);
            mineBtn.postDelayed(this, 50);
        }
    };
    private void doMine(float dt) {
        if (game.renderer.isDead()) return;
        int[] t = game.renderer.aimTarget();
        if (t == null) { mineProgress = Math.min(mineProgress, 0f); mineKey = -1; updateMineBar(0f); return; }
        long key = ((long) t[0] * 73856093L) ^ ((long) t[1] * 19349663L) ^ ((long) t[2] * 83492791L);
        if (key != mineKey) { mineKey = key; mineProgress = Math.min(mineProgress, 0f); }
        int id = game.renderer.blockAt(t[0], t[1], t[2]);
        int tool = survival ? inv.id[selected] : 0;
        float need = survival ? Items.breakSeconds(id, tool) : .02f;
        mineProgress += dt;
        if (mineProgress >= need) {
            int b = game.renderer.removeBlock(t[0], t[1], t[2]);
            if (b != 0 && survival) {
                int d = Items.drop(b, rnd, tool); if (d != 0) inv.add(d, 1);
                if (inv.useTool(selected)) Toast.makeText(this, "Ton outil s'est brisé !", Toast.LENGTH_SHORT).show();
                afterInvChange();
            }
            mineProgress = -.15f; mineKey = -1; updateMineBar(0f);
        } else updateMineBar(need > .1f && mineProgress > 0f ? mineProgress / need : 0f);
    }
    private void updateMineBar(float frac) {
        if (mineBar == null || mineFill == null) return;
        if (frac <= 0f) { mineBar.setVisibility(View.GONE); return; }
        mineBar.setVisibility(View.VISIBLE);
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) mineFill.getLayoutParams();
        lp.width = Math.round(dp(60) * Math.min(1f, frac)); mineFill.setLayoutParams(lp);
    }
    /** POSER : pose le bloc de la case, ou mange l'objet (pomme) s'il reste de la faim à combler. */
    private void usePlace() {
        if (game == null || game.renderer.isDead()) return;
        int id = hotId(selected);
        if (id == 0) return;
        if (Items.isItem(id)) {
            if (survival && Items.food(id) > 0 && game.renderer.getFood() < 20f) {
                game.renderer.addFood(Items.food(id)); inv.take(selected); afterInvChange();
            }
            return;
        }
        if (game.renderer.placeBlockAtAim(id) && survival) { inv.take(selected); afterInvChange(); }
    }
    private void afterInvChange() { saveInv(); game.renderer.selectBlock(hotId(selected)); refreshHotbar(); }
    private void saveInv() {
        if (survival && currentName != null) prefs.edit().putString("inv_" + currentName, inv.serialize()).apply();
    }
    private void refreshVitals() {
        if (game == null || heartFull[0] == null) return;
        float h = game.renderer.getHealth(), f = game.renderer.getFood();
        for (int i = 0; i < 10; i++) {
            heartFull[i].setVisibility(h >= 2 * i + 2 ? View.VISIBLE : View.INVISIBLE);
            heartHalf[i].setVisibility(h >= 2 * i + 1 && h < 2 * i + 2 ? View.VISIBLE : View.INVISIBLE);
            foodFull[i].setVisibility(f >= 2 * i + 2 ? View.VISIBLE : View.INVISIBLE);
            foodHalf[i].setVisibility(f >= 2 * i + 1 && f < 2 * i + 2 ? View.VISIBLE : View.INVISIBLE);
        }
    }
    private void flashHurt() {
        if (hurtFlash == null) return;
        hurtFlash.animate().cancel(); hurtFlash.setAlpha(1f); hurtFlash.animate().alpha(0f).setDuration(450).start();
    }
    private void showDeath() {
        deathShown = true; mining = false; updateMineBar(0f);
        LinearLayout col = column(); col.setGravity(Gravity.CENTER);
        col.addView(text("Vous êtes mort !", 30, Color.WHITE, true));
        col.addView(text("Tes objets sont conservés.", 13, 0xFFDDDDDD, false));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, dp(14)); col.addView(new View(this), gap);
        col.addView(mcButton("Réapparaître", true, () -> { game.renderer.respawn(); deathShown = false; resume(); }), wide());
        col.addView(mcButton("Menu principal", false, () -> { deathShown = false; exitToTitle(); }), wide());
        FrameLayout f = new FrameLayout(this); f.setBackgroundColor(0xAA500000); f.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setMenu(f, () -> {});
    }

    /** Position (en pixels de texture) d'une case de l'inventaire de survie dans inventory.png. */
    private static int[] slotPos(int slot) {
        final int[] rowY = {83, 101, 119};
        if (slot < 9) return new int[]{7 + 18 * slot, 141};
        int r = (slot - 9) / 9, c = (slot - 9) % 9; return new int[]{7 + 18 * c, rowY[r]};
    }
    private FrameLayout slotViewN(int id, int n, int k) {
        FrameLayout f = slotView(id, k, false);
        if (id != 0 && n > 1) {
            TextView t = pxText(String.valueOf(n), 7 * k, Color.WHITE); t.setShadowLayer(1, k, k, 0xFF3F3F3F); t.setGravity(Gravity.BOTTOM | Gravity.RIGHT);
            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(17 * k, 17 * k); p.leftMargin = k; p.topMargin = k; f.addView(t, p);
        }
        return f;
    }
    /** Inventaire de survie : 27 cases de sac + 9 de barre ; touche une case puis une autre pour déplacer / fusionner / échanger. */
    private void showSurvivalInventory() {
        if (game != null) game.renderer.setMovement(0, 0);
        Arrays.fill(dirs, false); mining = false; updateMineBar(0f);
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        final int k = Math.max(1, Math.min(6, Math.min((int) (dm.heightPixels * .76f / 166), (int) (dm.widthPixels * .9f / 176))));

        FrameLayout panel = new FrameLayout(this); panel.setClickable(true); panel.setClipChildren(false);
        panel.setBackground(GuiTex.crisp(this, tex.region("inventory", 0, 0, 176, 166, k)));
        place(panel, pxText("Inventaire", 8 * k, 0xFF404040), 97, 7, 72, 10, k);
        TextView hint = pxText(invPick < 0 ? "Touche une case, puis une autre pour déplacer." : "Touche la case de destination.", 6 * k, 0xFF505050);
        hint.setGravity(Gravity.TOP | Gravity.LEFT); place(panel, hint, 97, 20, 72, 40, k);

        int cur = inv.id[selected];
        if (cur != 0) {
            ImageView big = new ImageView(this); big.setScaleType(ImageView.ScaleType.FIT_XY); big.setImageBitmap(icon(cur, 32 * k));
            place(panel, big, 34, 16, 32, 32, k);
            TextView nm = pxText(slotLabel(selected), 6 * k, Color.WHITE); nm.setShadowLayer(1, k, k, 0xFF3F3F3F); nm.setGravity(Gravity.CENTER); place(panel, nm, 20, 56, 61, 10, k);
        }
        for (int s = 0; s < Inventory.SIZE; s++) {
            final int slot = s; int[] pos = slotPos(s);
            FrameLayout v = slotViewN(inv.id[s], inv.n[s], k);
            v.setOnClickListener(x -> {
                if (invPick < 0) { if (inv.id[slot] != 0) invPick = slot; }
                else { if (invPick != slot) inv.move(invPick, slot); invPick = -1; afterInvChange(); }
                showSurvivalInventory();
            });
            place(panel, v, pos[0], pos[1], 18, 18, k);
        }
        int[] sp0 = slotPos(selected);
        ImageView sel = new ImageView(this); sel.setImageDrawable(GuiTex.crisp(this, tex.scaled("hotbar_selection", k)));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2); sp.leftMargin = (sp0[0] - 3) * k; sp.topMargin = (sp0[1] - 3) * k; panel.addView(sel, sp);
        if (invPick >= 0) {
            int[] pp = slotPos(invPick);
            ImageView pk = new ImageView(this); pk.setImageDrawable(GuiTex.crisp(this, tex.scaled("hotbar_selection", k))); pk.setColorFilter(0xFFFFFF55, PorterDuff.Mode.MULTIPLY);
            FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(-2, -2); pl.leftMargin = (pp[0] - 3) * k; pl.topMargin = (pp[1] - 3) * k; panel.addView(pk, pl);
        }

        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.addView(panel, new LinearLayout.LayoutParams(176 * k, 166 * k));
        LinearLayout btns = new LinearLayout(this); btns.setOrientation(LinearLayout.HORIZONTAL); btns.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(invPick >= 0 ? 100 : 120), 20 * px1); cp.topMargin = dp(6); cp.leftMargin = dp(3); cp.rightMargin = dp(3);
        btns.addView(mcButton("Fermer", true, () -> { invPick = -1; resume(); }), cp);
        btns.addView(mcButton("Fabriquer", false, this::showCrafting), cp);
        if (invPick >= 0) btns.addView(mcButton("Jeter", false, () -> { inv.clearSlot(invPick); invPick = -1; afterInvChange(); showSurvivalInventory(); }), cp);
        col.addView(btns);

        FrameLayout overlay = new FrameLayout(this); overlay.setBackgroundColor(0xB8000000);
        overlay.setOnClickListener(v -> { invPick = -1; resume(); });
        overlay.addView(col, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        setMenu(overlay, () -> { invPick = -1; resume(); });
    }
    /** Fabrication : les recettes marquées « table » demandent une table de fabrication à moins de 4 blocs. */
    private void showCrafting() {
        final boolean nearTable = game != null && game.renderer.nearBlock(World.TABLE, 4);
        String[] labels = new String[RECIPES.length];
        for (int i = 0; i < RECIPES.length; i++) {
            int[] r = RECIPES[i];
            String need = r[3] > 0 && r[5] > 0 ? r[4] + " " + blockName(r[3]) + " + " + r[6] + " " + blockName(r[5]) : r[4] + " " + blockName(r[3]);
            String state = "";
            if (r[0] == 1 && !nearTable) state = "   (table requise)";
            else if (inv.count(r[3]) < r[4] || (r[5] > 0 && inv.count(r[5]) < r[6])) state = "   (il t'en manque)";
            labels[i] = (r[0] == 1 ? "🔨 " : "") + r[2] + " " + blockName(r[1]) + "  ←  " + need + state;
        }
        new AlertDialog.Builder(this).setTitle(nearTable ? "Fabrication (table à proximité)" : "Fabrication").setItems(labels, (d, w) -> {
            int[] r = RECIPES[w];
            if (r[0] == 1 && !nearTable) { Toast.makeText(this, "Place une table de fabrication près de toi", Toast.LENGTH_SHORT).show(); return; }
            if (inv.count(r[3]) < r[4] || (r[5] > 0 && inv.count(r[5]) < r[6])) { Toast.makeText(this, "Il te manque des objets", Toast.LENGTH_SHORT).show(); return; }
            Inventory test = Inventory.parse(inv.serialize()); test.remove(r[3], r[4]); if (r[5] > 0) test.remove(r[5], r[6]);
            if (!test.canAdd(r[1], r[2])) { Toast.makeText(this, "Inventaire plein", Toast.LENGTH_SHORT).show(); return; }
            inv.remove(r[3], r[4]); if (r[5] > 0) inv.remove(r[5], r[6]);
            inv.add(r[1], r[2]); afterInvChange(); showSurvivalInventory();
        }).setNegativeButton("Fermer", null).show();
    }
    /** Comme addTex mais ne garde que les w premiers pixels de large (demi-cœur, demi-cuisse). */
    private ImageView addTexPart(FrameLayout parent, String name, int w, int k, int x, int y) {
        ImageView iv = new ImageView(this); iv.setImageDrawable(GuiTex.crisp(this, tex.region(name, 0, 0, w, 9, k)));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(-2, -2); p.leftMargin = x; p.topMargin = y;
        parent.addView(iv, p); return iv;
    }

    // ---------- Boutons tactiles ----------
    private void addPad(FrameLayout parent, String glyph, int left, int bottom, int size, final int dir) {
        final TextView b = ctrl(glyph, 22);
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(size, size, Gravity.BOTTOM | Gravity.LEFT);
        p.leftMargin = left; p.bottomMargin = bottom; parent.addView(b, p);
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { v.setPressed(true); setDir(dir, true); }
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { v.setPressed(false); setDir(dir, false); }
            return true;
        });
    }
    private void setDir(int i, boolean on) {
        dirs[i] = on;
        if (game != null) game.renderer.setMovement((dirs[0] ? 1 : 0) - (dirs[1] ? 1 : 0), (dirs[3] ? 1 : 0) - (dirs[2] ? 1 : 0));
    }
    private TextView addAction(FrameLayout parent, String s, int sp, int gravity, int x, int y, int w, int h, Runnable action) {
        TextView b = ctrl(s, sp); FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, h, gravity);
        if ((gravity & Gravity.RIGHT) == Gravity.RIGHT) p.rightMargin = x;
        if ((gravity & Gravity.TOP) == Gravity.TOP) p.topMargin = y; else p.bottomMargin = y;
        parent.addView(b, p); b.setOnClickListener(v -> action.run());
        return b;
    }
    /** Bouton tactile : texture « button » du pack, légèrement translucide, verte quand on appuie. */
    private TextView ctrl(String s, int sp) {
        TextView t = label(s, sp); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER); t.setShadowLayer(1, 2, 2, 0xFF3F3F3F);
        Drawable d = tex.button(px1); d.setAlpha(215);
        t.setBackground(d); t.setClickable(true); return t;
    }
    private TextView label(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); return t; }

    /** Curseur de réglage Minecraft (textures slider + slider_handle). */
    static class McSlider extends View {
        private final GuiTex tex; private final int px, min, max; private final String label, unit; private final IntConsumer cb;
        private final Drawable track; private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG), crisp = new Paint();
        private int value; private boolean drag;
        McSlider(Activity c, GuiTex tex, int px, String label, String unit, int min, int max, int value, IntConsumer cb) {
            super(c); this.tex = tex; this.px = px; this.label = label; this.unit = unit; this.min = min; this.max = max; this.value = value; this.cb = cb;
            track = tex.nine("slider", 1, px); crisp.setFilterBitmap(false);
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setTextSize(15f * c.getResources().getDisplayMetrics().scaledDensity); text.setShadowLayer(1, 2, 2, 0xFF3F3F3F);
            setClickable(true);
        }
        @Override protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight(), hw = 8 * px;
            track.setBounds(0, 0, w, h); track.draw(c);
            float x = (w - hw) * (value - min) / (float) Math.max(1, max - min);
            c.drawBitmap(tex.get(drag ? "slider_handle_highlighted" : "slider_handle"), null, new RectF(x, 0, x + hw, h), crisp);
            c.drawText(label + " : " + value + unit, w / 2f, h / 2f - (text.ascent() + text.descent()) / 2f, text);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked(), hw = 8 * px;
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
                drag = true; if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                float f = Math.max(0f, Math.min(1f, (e.getX() - hw / 2f) / Math.max(1f, getWidth() - hw)));
                int v = min + Math.round(f * (max - min));
                if (v != value) { value = v; cb.accept(v); }
                invalidate(); return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) { drag = false; invalidate(); return true; }
            return super.onTouchEvent(e);
        }
    }

    // =====================================================================
    //  Mondes (fichiers)
    // =====================================================================
    private File worldsDir() { File d = new File(getFilesDir(), "worlds"); d.mkdirs(); return d; }
    private void migrateLegacySave() {
        File old = new File(getFilesDir(), "ractex_world.dat");
        if (old.exists() && World.peekSeed(old) != null) old.renameTo(freeFile("Monde 1"));
    }
    private File freeFile(String base) {
        File f = new File(worldsDir(), base + ".dat"); int n = 2;
        while (f.exists()) f = new File(worldsDir(), base + " (" + n++ + ").dat");
        return f;
    }
    private static String sanitize(String s) {
        s = s.trim().replaceAll("[\\\\/:*?\"<>|]", "_");
        if (s.length() > 40) s = s.substring(0, 40);
        return s.isEmpty() ? "Nouveau monde" : s;
    }
    private static long parseSeed(String t) {
        t = t.trim(); if (t.isEmpty()) return System.nanoTime();
        try { return Long.parseLong(t); } catch (NumberFormatException e) { return t.hashCode(); }
    }

    // =====================================================================
    //  Style « Minecraft »
    // =====================================================================
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams wide() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(300), 20 * px1); p.topMargin = dp(3); p.bottomMargin = dp(3); return p; }
    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(12), dp(10), dp(12), dp(10)); return c;
    }
    private TextView text(String s, int sp, int color, boolean shadow) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER);
        if (shadow) { t.setShadowLayer(1, 2, 2, 0xFF3F3F3F); t.setTypeface(Typeface.DEFAULT_BOLD); }
        t.setPadding(0, dp(3), 0, dp(3)); return t;
    }
    private EditText field(String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF888888);
        e.setInputType(InputType.TYPE_CLASS_TEXT); e.setPadding(dp(10), dp(8), dp(10), dp(8));
        e.setBackground(tex.nine("text_field", 1, px1)); return e;
    }
    /** Bouton Minecraft du pack de textures : gris, vert quand on appuie. */
    private TextView mcButton(String label, boolean primary, Runnable action) {
        TextView b = new TextView(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER); b.setShadowLayer(1, 2, 2, 0xFF3F3F3F); b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(tex.button(px1)); b.setClickable(true); b.setOnClickListener(v -> action.run()); return b;
    }
    /** Fond : texture de terre en pixels nets, assombrie (comme les menus Minecraft). */
    private FrameLayout background() {
        FrameLayout f = new FrameLayout(this);
        try (InputStream in = getAssets().open("atlas.png")) {
            Bitmap atlas = BitmapFactory.decodeStream(in);
            Bitmap tile = Bitmap.createScaledBitmap(Bitmap.createBitmap(atlas, 32, 0, 16, 16), dp(64), dp(64), false);
            BitmapDrawable d = new BitmapDrawable(getResources(), tile);
            d.setTileModeXY(Shader.TileMode.REPEAT, Shader.TileMode.REPEAT); d.setFilterBitmap(false);
            d.setColorFilter(0xFF606060, PorterDuff.Mode.MULTIPLY);
            f.setBackground(d);
        } catch (Exception e) { f.setBackgroundColor(0xFF3A2A1A); }
        return f;
    }

    @Override public void onBackPressed() {
        if (onBack != null) onBack.run();
        else if (inGame) showPause();
        else super.onBackPressed();
    }
    @Override protected void onPause() { super.onPause(); if (inGame && game != null) { Arrays.fill(dirs, false); game.renderer.setMovement(0, 0); saveInv(); mining = false; game.renderer.saveWorld(); game.onPause(); } }
    @Override protected void onResume() { super.onResume(); if (inGame && game != null) game.onResume(); }

    static class GameSurface extends GLSurfaceView {
        final WorldRenderer renderer;
        GameSurface(Activity c, int renderDist) { super(c); setEGLContextClientVersion(2); renderer = new WorldRenderer(c, renderDist); setRenderer(renderer); setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY); }
    }
}
