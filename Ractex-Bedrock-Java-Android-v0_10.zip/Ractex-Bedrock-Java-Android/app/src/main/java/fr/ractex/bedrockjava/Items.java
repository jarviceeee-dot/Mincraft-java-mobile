package fr.ractex.bedrockjava;

import java.util.Random;

/** Objets (ids >= 128, non posables), outils et règles de survie : minage, butins, nourriture. */
final class Items {
    static final int APPLE = 128, STICK = 129,
        WOOD_PICK = 130, STONE_PICK = 131, WOOD_AXE = 132, STONE_AXE = 133, WOOD_SHOVEL = 134, STONE_SHOVEL = 135;
    static final int PICK = 1, AXE = 2, SHOVEL = 3;
    private Items() {}

    static boolean isItem(int id) { return id >= 128; }
    static boolean isTool(int id) { return id >= WOOD_PICK && id <= STONE_SHOVEL; }
    /** 1 = pioche, 2 = hache, 3 = pelle (0 = pas un outil). */
    static int toolType(int id) { return isTool(id) ? (id - WOOD_PICK) / 2 + 1 : 0; }
    /** 1 = bois, 2 = pierre. */
    static int toolTier(int id) { return isTool(id) ? (id - WOOD_PICK) % 2 + 1 : 0; }
    static int maxDur(int id) { return !isTool(id) ? 0 : toolTier(id) == 1 ? 59 : 131; }
    static int stackMax(int id) { return isTool(id) ? 1 : Inventory.MAX_STACK; }

    static String name(int id) {
        switch (id) {
            case APPLE: return "Pomme";
            case STICK: return "Bâton";
            case WOOD_PICK: return "Pioche en bois";
            case STONE_PICK: return "Pioche en pierre";
            case WOOD_AXE: return "Hache en bois";
            case STONE_AXE: return "Hache en pierre";
            case WOOD_SHOVEL: return "Pelle en bois";
            case STONE_SHOVEL: return "Pelle en pierre";
            default: return "Objet";
        }
    }
    static int tile(int id) {
        if (id == APPLE) return 10;
        if (id == STICK) return 18;
        if (isTool(id)) return 19 + (id - WOOD_PICK);
        return ModRegistry.MISSING_TILE;
    }
    /** Points de faim rendus (20 = barre pleine). */
    static int food(int id) { return id == APPLE ? 4 : 0; }

    /** Dureté du bloc (comme Minecraft). */
    static float hardness(int id) {
        switch (id) {
            case World.LEAVES: return .2f;
            case World.DIRT: case World.SAND: return .5f;
            case World.GRASS: return .6f;
            case World.STONE: return 1.5f;
            case World.COBBLE: case World.WOOD: case World.PLANKS: return 2f;
            case World.TABLE: return 2.5f;
            default: return 1f;
        }
    }
    /** Outil qui accélère ce bloc (0 = aucun). */
    static int preferredTool(int id) {
        switch (id) {
            case World.STONE: case World.COBBLE: return PICK;
            case World.WOOD: case World.PLANKS: case World.TABLE: return AXE;
            case World.DIRT: case World.GRASS: case World.SAND: return SHOVEL;
            default: return 0;
        }
    }
    /** La pierre ne donne rien sans pioche. */
    static boolean needsPick(int id) { return id == World.STONE || id == World.COBBLE; }

    /** Secondes pour casser le bloc avec cet objet en main (0 = mains nues). Mains nues : stone 7,5 s, bois 3 s, terre 0,75 s. */
    static float breakSeconds(int id, int tool) {
        int type = toolType(tool);
        float speed = (type != 0 && type == preferredTool(id)) ? (toolTier(tool) == 1 ? 2f : 4f) : 1f;
        boolean harvest = !needsPick(id) || type == PICK;
        return (harvest ? 1.5f : 5f) * hardness(id) / speed;
    }
    /** Ce que laisse un bloc cassé (0 = rien). */
    static int drop(int id, Random r, int tool) {
        if (needsPick(id) && toolType(tool) != PICK) return 0;
        switch (id) {
            case World.GRASS: return World.DIRT;
            case World.STONE: return World.COBBLE;
            case World.LEAVES: return r.nextInt(10) == 0 ? APPLE : 0;
            default: return id;
        }
    }
}
